<?php
/**
 * CLI launcher for creating/resetting the Superadmin account.
 * Usage: php create_admin.php
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not available over HTTP. Run this script from CLI/Terminal.\n");
}
$target = __DIR__ . '/database/create_admin.php';
if (!is_file($target)) {
    fwrite(STDERR, "ERROR: database/create_admin.php tidak ditemukan. Pastikan Anda berada di root aplikasi v13.\n");
    exit(1);
}
require $target;
