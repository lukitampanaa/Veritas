<?php
declare(strict_types=1);

// Majalah Sekolah Online - Production V5.5 Flash Warning Fix
// Compatible with PHP 7.4+ (recommended PHP 8.1+).
if (PHP_VERSION_ID < 70400) {
    http_response_code(500);
    exit('Majalah Sekolah Online membutuhkan PHP 7.4 atau lebih baru. PHP aktif: ' . PHP_VERSION);
}

$config = require __DIR__ . '/../config/config.php';
// Use an installation/host-specific session cookie name. This prevents stale
// cookies from older deployments on the same hostname from colliding with the
// current application after an upgrade.
$baseSessionName = isset($config['session_name']) ? (string)$config['session_name'] : 'MSO_SESSION';
$hostKey = strtolower((string)($_SERVER['HTTP_HOST'] ?? 'localhost')) . '|' . str_replace('\\','/',dirname(__DIR__));
$hostSuffix = strtoupper(substr(hash('sha256', $hostKey), 0, 10));
$sessionName = preg_replace('/[^A-Za-z0-9_]/', '_', $baseSessionName . '_' . $hostSuffix);
session_name($sessionName ?: 'MSO_SESSION');
// Harden PHP sessions before starting them and prevent intermediary/browser
// caching of pages that contain per-session CSRF tokens.
ini_set('session.use_only_cookies', '1');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_trans_sid', '0');
ini_set('session.cache_limiter', 'nocache');
$https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off');
$cookiePath = '/';
session_set_cookie_params(array('lifetime'=>0,'path'=>$cookiePath,'secure'=>$https,'httponly'=>true,'samesite'=>'Lax'));
session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// Baseline HTTP hardening. Do not emit HSTS on plain HTTP/local development.
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
if ($https) { header('Strict-Transport-Security: max-age=31536000; includeSubDomains'); }

$options = array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false
);
$dsn = 'mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['name'] . ';charset=' . $config['db']['charset'];
try {
    $pdo = new PDO($dsn, $config['db']['user'], $config['db']['pass'], $options);
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection failed. Check config/config.php.');
}

// First-run/hosting database bootstrap. If the database connection works but the
// required settings table is missing (common after uploading a fresh ZIP without
// importing SQL), install the bundled schema into the already-selected database.
// The hosting schema intentionally omits CREATE DATABASE/USE so it works with
// hosting database users that do not have CREATE DATABASE privileges.
try {
    $hasSettings = (bool)$pdo->query("SHOW TABLES LIKE 'settings'")->fetchColumn();
    if (!$hasSettings) {
        $schemaFile = __DIR__ . '/../database/schema_hosting.sql';
        if (!is_file($schemaFile) || !is_readable($schemaFile)) {
            throw new RuntimeException('Database schema file is missing.');
        }
        $schema = file_get_contents($schemaFile);
        if ($schema === false || trim($schema) === '') {
            throw new RuntimeException('Database schema file is empty.');
        }
        $pdo->exec($schema);
        $hasSettings = (bool)$pdo->query("SHOW TABLES LIKE 'settings'")->fetchColumn();
    }
    if (!$hasSettings) {
        throw new RuntimeException('Required database table settings could not be created.');
    }
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database is connected, but the application schema is not installed. Import database/schema_hosting.sql (or database/schema.sql) into the configured database, then reload this page.');
}


// Gallery playlist schema is upgraded lazily so existing installations do not
// require a manual SQL migration before using Momen & Kreativitas playlists.
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS gallery_playlists (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,title VARCHAR(180) NOT NULL,slug VARCHAR(200) NOT NULL,media_type ENUM('image','video') NOT NULL DEFAULT 'image',is_active TINYINT(1) NOT NULL DEFAULT 1,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uq_gallery_playlist_slug(slug),INDEX(media_type,is_active),INDEX(created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    if (!(bool)$pdo->query("SHOW COLUMNS FROM gallery_items LIKE 'playlist_id'")->fetchColumn()) { $pdo->exec("ALTER TABLE gallery_items ADD COLUMN playlist_id BIGINT UNSIGNED NULL AFTER media_type"); }
    if (!(bool)$pdo->query("SHOW INDEX FROM gallery_items WHERE Key_name='idx_gallery_playlist'")->fetchColumn()) { $pdo->exec("ALTER TABLE gallery_items ADD INDEX idx_gallery_playlist(playlist_id,is_active,created_at)"); }
} catch (Throwable $e) {}

// Core tag tables are required by the Rubrik & Tag editor. Create them for older installs.
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS tags (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(80) NOT NULL UNIQUE,slug VARCHAR(100) NOT NULL UNIQUE,is_active TINYINT(1) NOT NULL DEFAULT 1,INDEX idx_tags_active(is_active)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS article_tags (article_id BIGINT UNSIGNED NOT NULL,tag_id INT UNSIGNED NOT NULL,PRIMARY KEY(article_id,tag_id),FOREIGN KEY(article_id) REFERENCES articles(id) ON DELETE CASCADE,FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Throwable $e) {}

// Rubrik & Tag / Menu visibility migration for existing installations.
// Existing records stay active by default; admins can turn them off from the dashboard.
try {
    if ((bool)$pdo->query("SHOW TABLES LIKE 'tags'")->fetchColumn()) {
        if (!(bool)$pdo->query("SHOW COLUMNS FROM tags LIKE 'is_active'")->fetchColumn()) {
            $pdo->exec("ALTER TABLE tags ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER slug");
        }
    }
    if ((bool)$pdo->query("SHOW TABLES LIKE 'menus'")->fetchColumn()) {
        if (!(bool)$pdo->query("SHOW COLUMNS FROM menus LIKE 'is_active'")->fetchColumn()) {
            $pdo->exec("ALTER TABLE menus ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER sort_order");
        }
    }
    if ((bool)$pdo->query("SHOW TABLES LIKE 'categories'")->fetchColumn()) {
        if (!(bool)$pdo->query("SHOW COLUMNS FROM categories LIKE 'is_active'")->fetchColumn()) {
            $pdo->exec("ALTER TABLE categories ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER sort_order");
        }
    }
} catch (Throwable $e) {}

// Member engagement / favorites migration. Older databases may not have
// article_favorites because the SQL migration is optional. Create it lazily so
// Anggota and Penulis can safely use "Artikel Disukai" after an upgrade.
try {
    $hasArticles = (bool)$pdo->query("SHOW TABLES LIKE 'articles'")->fetchColumn();
    $hasUsers = (bool)$pdo->query("SHOW TABLES LIKE 'users'")->fetchColumn();
    if ($hasArticles && $hasUsers && !(bool)$pdo->query("SHOW TABLES LIKE 'article_favorites'")->fetchColumn()) {
        $pdo->exec("CREATE TABLE article_favorites (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            article_id BIGINT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_article_user (article_id,user_id),
            INDEX idx_user_created (user_id,created_at),
            CONSTRAINT fk_favorite_article FOREIGN KEY (article_id) REFERENCES articles(id) ON DELETE CASCADE,
            CONSTRAINT fk_favorite_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
} catch (Throwable $e) {
    // Do not break the site during a partial/legacy database upgrade.
}

// Member / Writer registration workflow. Existing accounts remain active; new self-registrations use pending approval.
try {
    if ((bool)$pdo->query("SHOW TABLES LIKE 'users'")->fetchColumn()) {
        $col = $pdo->query("SHOW COLUMNS FROM users LIKE 'status'")->fetch();
        if ($col && stripos((string)$col['Type'], "enum('active','inactive')") !== false) {
            $pdo->exec("ALTER TABLE users MODIFY status ENUM('pending','active','inactive','rejected') NOT NULL DEFAULT 'pending'");
            $pdo->exec("UPDATE users SET status='active' WHERE status='inactive' AND role IN ('superadmin','admin')");
        }
    }
} catch (Throwable $e) {}

// Login throttling: stores only a one-way key, not the source IP itself.
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS auth_login_attempts (
        attempt_key CHAR(64) NOT NULL PRIMARY KEY,
        attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
        window_started DATETIME NOT NULL,
        blocked_until DATETIME NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Throwable $e) {}

// Production hardening: never auto-create an administrator or ship a default password.
// Administrators are created during installation or explicitly by an existing admin.

function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function setting(string $key, string $default = ''): string {
    global $pdo;
    static $cache = array();
    if (array_key_exists($key, $cache)) return $cache[$key];
    $q = $pdo->prepare('SELECT value FROM settings WHERE `key`=? LIMIT 1');
    $q->execute(array($key));
    $value = $q->fetchColumn();
    return $cache[$key] = ($value !== false && $value !== null && $value !== '') ? (string)$value : $default;
}
function app_base_path(): string {
    static $base = null;
    if ($base !== null) return $base;
    $root = realpath(dirname(__DIR__));
    $doc = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false;
    if ($root && $doc) {
        $rootNorm = str_replace('\\', '/', $root);
        $docNorm = rtrim(str_replace('\\', '/', $doc), '/');
        if (stripos($rootNorm, $docNorm) === 0) {
            $rel = substr($rootNorm, strlen($docNorm));
            $base = '/' . trim(str_replace('\\', '/', $rel), '/');
            return $base === '/' ? '' : $base;
        }
    }
    $base = '';
    return $base;
}
function url(string $path = ''): string {
    global $config;

    $configured = trim((string)setting('site_url', isset($config['base_url']) ? $config['base_url'] : ''));
    $projectPath = app_base_path();

    // The application can be opened in two ways:
    //   /v54/        -> root .htaccess rewrites to /public
    //   /v54/public/ -> direct public-folder access (common on XAMPP/localhost)
    // When the latter is used, generated asset URLs must also include /public.
    $requestPath = (string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
    $publicPath = $projectPath;
    $publicMarker = rtrim($projectPath, '/') . '/public';
    if ($projectPath !== '' && ($requestPath === $publicMarker || strpos($requestPath, $publicMarker . '/') === 0)) {
        $publicPath = $publicMarker;
    }

    $requestHost = isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\\d+$/', '', (string)$_SERVER['HTTP_HOST']) : '';
    $isLocalHost = $requestHost === '' || (bool)preg_match('/^(localhost|127(?:\\.\\d{1,3}){3}|::1)$/i', $requestHost)
        || (bool)preg_match('/\\.(?:local|test|localhost)$/i', $requestHost);

    $origin = '';
    $basePath = $publicPath;

    // Never send a local XAMPP request to a production site_url stored in the
    // database. This is especially important after saving Branding settings:
    // the saved production URL must not break localhost previews/assets.
    if (!$isLocalHost && $configured !== '') {
        $parts = parse_url($configured);
        if ($parts && isset($parts['scheme']) && isset($parts['host'])) {
            $origin = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
            $cfgPath = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';
            $sameHost = ($requestHost !== '' && strcasecmp($requestHost, (string)$parts['host']) === 0);
            if ($sameHost && $projectPath !== '') {
                // On a local/subfolder installation keep the real project path.
                $cfgPath = $publicPath;
            } elseif ($cfgPath === '' && $projectPath !== '') {
                $cfgPath = $projectPath;
            }
            $basePath = $cfgPath;
        } else {
            $basePath = rtrim($configured, '/');
        }
    } else {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] !== '' ? $_SERVER['HTTP_HOST'] : 'localhost';
        $origin = $scheme . '://' . $host;
    }

    return rtrim($origin . $basePath, '/') . '/' . ltrim($path, '/');
}

function root_url(string $path = ''): string {
    global $config;
    $configured = trim((string)setting('site_url', isset($config['base_url']) ? $config['base_url'] : ''));
    $projectPath = app_base_path();
    $requestHost = isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\d+$/', '', (string)$_SERVER['HTTP_HOST']) : '';
    $isLocalHost = $requestHost === '' || (bool)preg_match('/^(localhost|127(?:\.\d{1,3}){3}|::1)$/i', $requestHost)
        || (bool)preg_match('/\.(?:local|test|localhost)$/i', $requestHost);

    if (!$isLocalHost && $configured !== '') {
        $parts = parse_url($configured);
        if ($parts && isset($parts['scheme']) && isset($parts['host'])) {
            $origin = $parts['scheme'] . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');
            $cfgPath = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';
            if ($cfgPath === '' && $projectPath !== '') $cfgPath = $projectPath;
            return rtrim($origin . $cfgPath, '/') . '/' . ltrim($path, '/');
        }
    }

    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] !== '' ? $_SERVER['HTTP_HOST'] : 'localhost';
    return rtrim($scheme . '://' . $host . $projectPath, '/') . '/' . ltrim($path, '/');
}

function app_file_url(string $path = ''): string {
    $path = trim(str_replace('\\', '/', $path));
    if ($path === '') return '';
    if (preg_match('#^https?://#i', $path)) return $path;
    $path = preg_replace('#^/+#', '', $path);
    $path = preg_replace('#^(?:\./)?public/#i', '', $path);
    $root = realpath(dirname(__DIR__));
    if ($root && preg_match('#^uploads/(.+)$#i', $path, $m)) {
        $candidate = $root . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $m[1]);
        if (is_file($candidate)) return root_url('uploads/' . $m[1]);
    }
    return url($path);
}

function theme_key(): string { return setting('theme', 'sunday'); }
function theme_class(): string {
    $allowed = array('sunday','school','glass','midnight','minimal');
    $t = theme_key();
    return in_array($t, $allowed, true) ? 'theme-' . $t : 'theme-sunday';
}
function redirect(string $to) {
    // Normalize common relative targets so redirects work when the app is
    // installed in a subfolder such as /v54/ as well as at a domain root.
    // IMPORTANT: /admin lives beside /public, not inside /public. When the
    // login page is opened directly at /public/login.php, url('admin/...')
    // would otherwise become /public/admin/... and Apache returns 404.
    $to = trim($to);
    if ($to === '' || $to === './' || $to === '../' || $to === '../public/' || $to === '../public/index.php') {
        $to = '';
        header('Location: ' . url($to));
        exit;
    }

    if (strpos($to, '../admin') === 0) {
        $to = 'admin' . substr($to, strlen('../admin'));
    } elseif (strpos($to, '../') === 0) {
        $to = ltrim(substr($to, 3), '/');
    }

    // Admin is a sibling of public/ in the project structure. Always use the
    // project-root URL for admin redirects, including redirects originating
    // from public/login.php on localhost.
    if ($to === 'admin' || strpos($to, 'admin/') === 0) {
        header('Location: ' . root_url($to));
        exit;
    }

    header('Location: ' . url($to));
    exit;
}
function csrf(): string {
    $token = isset($_SESSION['_csrf']) ? (string)$_SESSION['_csrf'] : '';
    if ($token === '') {
        $token = bin2hex(random_bytes(32));
        $_SESSION['_csrf'] = $token;
    }
    // The CSRF cookie is deliberately issued from bootstrap before templates
    // can emit HTML. This avoids PHP 7.4/LiteSpeed rejecting setcookie() after
    // output has started. It is HttpOnly and SameSite=Lax; the form token is
    // still checked against the server-side session token first.
    return $token;
}
function csrf_cookie_sync(): void {
    $token = isset($_SESSION['_csrf']) ? (string)$_SESSION['_csrf'] : '';
    if ($token === '') {
        $token = bin2hex(random_bytes(32));
        $_SESSION['_csrf'] = $token;
    }
    $https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off');
    setcookie('MSO_CSRF', $token, array('expires'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax'));
}
function check_csrf() {
    $sessionToken = isset($_SESSION['_csrf']) ? (string)$_SESSION['_csrf'] : '';
    $cookieToken = isset($_COOKIE['MSO_CSRF']) ? (string)$_COOKIE['MSO_CSRF'] : '';
    $postToken = isset($_POST['_csrf']) ? (string)$_POST['_csrf'] : '';
    $valid = false;
    if ($postToken !== '' && $sessionToken !== '' && hash_equals($sessionToken, $postToken)) {
        $valid = true;
    } elseif ($postToken !== '' && $cookieToken !== '' && hash_equals($cookieToken, $postToken)) {
        // Recover the server-side token only when the independent HttpOnly
        // double-submit cookie also matches the submitted token.
        $_SESSION['_csrf'] = $postToken;
        $valid = true;
    }
    if (!$valid) {
        http_response_code(419);
        exit('Sesi formulir telah kedaluwarsa. Muat ulang halaman lalu coba lagi.');
    }
}
// Create/sync the CSRF token while headers are still writable.
csrf_cookie_sync();
function auth() { return isset($_SESSION['user']) ? $_SESSION['user'] : null; }
function auth_rate_key(string $username): string {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : 'unknown';
    return hash('sha256', strtolower(trim($username)) . '|' . $ip . '|' . session_name());
}
function auth_rate_status(string $key): array {
    global $pdo;
    try {
        $q=$pdo->prepare('SELECT attempts,window_started,blocked_until FROM auth_login_attempts WHERE attempt_key=? LIMIT 1');
        $q->execute(array($key)); $r=$q->fetch();
        if(!$r) return array('blocked'=>false,'attempts'=>0);
        if(!empty($r['blocked_until']) && strtotime($r['blocked_until']) > time()) return array('blocked'=>true,'attempts'=>(int)$r['attempts']);
        if(strtotime($r['window_started']) < time()-900){ $pdo->prepare('DELETE FROM auth_login_attempts WHERE attempt_key=?')->execute(array($key)); return array('blocked'=>false,'attempts'=>0); }
        return array('blocked'=>false,'attempts'=>(int)$r['attempts']);
    } catch(Throwable $e) { return array('blocked'=>false,'attempts'=>0); }
}
function auth_rate_fail(string $key): void {
    global $pdo;
    try {
        $q=$pdo->prepare("INSERT INTO auth_login_attempts(attempt_key,attempts,window_started,blocked_until) VALUES(?,1,NOW(),NULL) ON DUPLICATE KEY UPDATE attempts=attempts+1,blocked_until=IF(attempts+1>=8,DATE_ADD(NOW(),INTERVAL 15 MINUTE),blocked_until),window_started=IF(window_started < DATE_SUB(NOW(),INTERVAL 15 MINUTE),NOW(),window_started)");
        $q->execute(array($key));
    } catch(Throwable $e) {}
}
function auth_rate_clear(string $key): void {
    global $pdo;
    try { $pdo->prepare('DELETE FROM auth_login_attempts WHERE attempt_key=?')->execute(array($key)); } catch(Throwable $e) {}
}
function refresh_auth_user(): ?array {
    global $pdo;
    if (empty($_SESSION['user']['id'])) return null;
    try {
        $q=$pdo->prepare('SELECT id,name,username,email,phone,role,status,avatar,created_at FROM users WHERE id=? LIMIT 1');
        $q->execute(array((int)$_SESSION['user']['id'])); $u=$q->fetch();
        if(!$u || ($u['status'] ?? '') !== 'active'){ $_SESSION=[]; return null; }
        $_SESSION['user']=$u; return $u;
    } catch(Throwable $e) { return isset($_SESSION['user']) ? $_SESSION['user'] : null; }
}
function require_login(array $roles = array()) {
    $u = refresh_auth_user();
    if (!$u) redirect('login.php');
    if ($roles && !in_array($u['role'], $roles, true)) {
        http_response_code(403);
        exit('Forbidden');
    }
}
function flash($set = null) {
    if ($set !== null) {
        $_SESSION['_flash'] = $set;
        return null;
    }
    $x = isset($_SESSION['_flash']) ? $_SESSION['_flash'] : null;
    unset($_SESSION['_flash']);

    // Older versions stored flash data as an array (type/message).
    // Normalize it to a printable message so e() never receives an array.
    if (is_array($x)) {
        if (isset($x['message'])) return (string)$x['message'];
        if (isset($x['text'])) return (string)$x['text'];
        return '';
    }
    if ($x === null) return null;
    return is_scalar($x) ? (string)$x : '';
}
function slugify(string $s): string {
    $s = strtolower(trim($s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim($s, '-') ?: 'artikel';
}
function excerpt(string $html, int $n = 180): string {
    $t = trim(preg_replace('/\s+/', ' ', strip_tags($html)));
    return function_exists('mb_strimwidth') ? mb_strimwidth($t, 0, $n, '…', 'UTF-8') : substr($t, 0, $n);
}
function is_admin(): bool { return in_array(isset(auth()['role']) ? auth()['role'] : '', array('superadmin','admin'), true); }
function can_edit_article(array $a): bool { return is_admin() || ((isset($a['author_id']) ? $a['author_id'] : 0) == (isset(auth()['id']) ? auth()['id'] : -1)); }
function notify_new_submission(string $title) {
    global $config;
    if (!empty($config['mail']['enabled'])) {
        @mail($config['mail']['to'], 'Naskah baru: ' . $title, 'Ada naskah baru menunggu moderasi: ' . $title, 'From: ' . $config['mail']['from']);
    }
}
function media_url(string $path = ''): string {
    $path = trim($path);
    if ($path === '') return '';
    if (preg_match('#^https?://#i', $path)) return $path;
    $path = str_replace('\\', '/', $path);
    $path = preg_replace('#^/+#', '', $path);
    // Normalize legacy values saved as public/uploads/... or ./uploads/...
    $path = preg_replace('#^(?:\./)?public/#i', '', $path);

    // Master article media is /uploads. Keep legacy public/uploads files
    // readable when the old physical file still exists.
    if (preg_match('#^uploads/(.+)$#i', $path, $m)) {
        $root = realpath(dirname(__DIR__));
        $newFile = $root ? $root . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $m[1]) : '';
        $legacyFile = $root ? $root . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $m[1]) : '';
        if ($newFile !== '' && is_file($newFile)) return app_file_url('uploads/' . $m[1]);
        if ($legacyFile !== '' && is_file($legacyFile)) return url('uploads/' . $m[1]);
    }

    return url($path);
}

/**
 * Normalize local image URLs inside article HTML.
 * External http(s) URLs are left untouched.
 */
function article_is_public_http_url($url): bool {
    $p = @parse_url($url);
    if (!$p || empty($p['scheme']) || !in_array(strtolower($p['scheme']), array('http','https'), true) || empty($p['host'])) return false;
    $host = strtolower($p['host']);
    if ($host === 'localhost' || substr($host, -10) === '.localhost' || $host === '127.0.0.1' || $host === '::1') return false;
    $ips = @gethostbynamel($host);
    if ($ips) {
        foreach ($ips as $ip) {
            if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return false;
        }
    }
    return true;
}

function article_remote_image_download($url) {
    global $config;
    if (!article_is_public_http_url($url)) return null;

    $maxBytes = ((int)$config['upload_max_mb']) * 1024 * 1024;
    $body = false; $contentType = '';

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_MAXREDIRS => 0,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_USERAGENT => 'MajalahSekolahOnline/5.17.9 ImageImporter',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HEADER => false
        ));
        $body = curl_exec($ch);
        $contentType = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($http < 200 || $http >= 400) $body = false;
    } else {
        $ctx = stream_context_create(array('http'=>array(
            'method'=>'GET','timeout'=>20,'follow_location'=>0,'max_redirects'=>0,
            'header'=>"User-Agent: MajalahSekolahOnline/5.17.9 ImageImporter\r\n"
        )));
        $body = @file_get_contents($url, false, $ctx);
        if (isset($http_response_header)) {
            foreach ($http_response_header as $h) {
                if (stripos($h, 'Content-Type:') === 0) $contentType = trim(substr($h, 13));
            }
        }
    }

    if ($body === false || $body === '' || strlen($body) > $maxBytes) return null;

    $tmp = tempnam(sys_get_temp_dir(), 'mso_');
    if (!$tmp) return null;
    file_put_contents($tmp, $body);
    $mime = '';
    if (class_exists('finfo')) $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    @unlink($tmp);

    $allowed = array(
        'image/jpeg'=>'jpg',
        'image/png'=>'png',
        'image/webp'=>'webp',
        'image/gif'=>'gif'
    );
    if (!isset($allowed[$mime])) {
        $ct = strtolower(trim(explode(';', $contentType)[0]));
        if (isset($allowed[$ct])) $mime = $ct;
    }
    if (!isset($allowed[$mime])) return null;

    $root = dirname(__DIR__);
    $dir = $root . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR;
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) return null;
    $name = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
    if (@file_put_contents($dir . $name, $body) === false) return null;
    return 'uploads/' . $name;
}

function article_make_image_tags_from_plain_urls(string $html): string {
    $pattern = "#(?<![=\"'A-Za-z0-9_])(https?://[^\\s<>\"']+)#i";
    return preg_replace_callback($pattern, function ($m) {
        $url = trim($m[1], " \t\r\n.,;:!?)]}");
        $isShareGoogle = (bool)preg_match('#^https?://(?:www\\.)?share\\.google/#i', $url);
        $isImageExt = (bool)preg_match('~\\.(?:jpe?g|png|webp|gif)(?:[?#].*)?$~i', $url);
        if (!$isShareGoogle && !$isImageExt) return $m[0];
        return '<img src="' . e($url) . '" alt="Gambar artikel" loading="lazy" decoding="async">';
    }, $html);
}

function normalize_article_content_media(string $html): string {
    $html = article_make_image_tags_from_plain_urls($html);

    return preg_replace_callback(
        "#(<(?:img|source)\\b[^>]*\\b(?:src|srcset)\\s*=\\s*[\"'])([^\"']+)([\"'])#i",
        function ($m) {
            $value = trim(html_entity_decode($m[2], ENT_QUOTES, 'UTF-8'));
            if ($value === '' || preg_match('#^(?:data:|blob:|mailto:|javascript:)#i', $value)) return $m[0];

            if (preg_match('#^https?://#i', $value)) {
                $local = article_remote_image_download($value);
                if ($local) return $m[1] . e(url($local)) . $m[3];
                return $m[0];
            }

            $clean = str_replace('\\', '/', $value);
            $clean = preg_replace('#^\\./+#', '', $clean);
            $clean = preg_replace('#^/+#', '', $clean);
            if (preg_match('#^(?:public/)?uploads/(.+)$#i', $clean, $mm)) {
                return $m[1] . e(url('uploads/' . $mm[1])) . $m[3];
            }
            return $m[0];
        },
        $html
    );
}
function upload_article_cover(string $field) {
    global $config;
    if (empty($_FILES[$field]['name'])) return null;
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Upload foto gagal. Kode error: ' . (int)$f['error']);
    $maxBytes = ((int)$config['upload_max_mb']) * 1024 * 1024;
    if ($f['size'] > $maxBytes) throw new RuntimeException('Foto terlalu besar. Maksimal ' . (int)$config['upload_max_mb'] . ' MB.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $allowed = array('image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp');
    if (!isset($allowed[$mime])) throw new RuntimeException('Format foto tidak didukung. Gunakan JPG, PNG, atau WebP.');
    $info = @getimagesize($f['tmp_name']);
    if (!$info || empty($info[0]) || empty($info[1])) throw new RuntimeException('File bukan gambar yang valid.');
    $w = (int)$info[0]; $h = (int)$info[1];
    if ($w < 800 || $h < 450) throw new RuntimeException('Resolusi foto terlalu kecil. Minimal 800 × 450 px; disarankan 1600 × 900 px (rasio 16:9).');
    $name = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
    $dir = __DIR__ . '/../uploads/';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) throw new RuntimeException('Gagal membuat folder uploads utama.');
    if (!move_uploaded_file($f['tmp_name'], $dir . $name)) throw new RuntimeException('Gagal menyimpan foto ke folder uploads utama.');
    return 'uploads/' . $name;
}
function upload_image(string $field) {
    global $config;
    if (empty($_FILES[$field]['name'])) return null;
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Upload gagal.');
    if ($f['size'] > $config['upload_max_mb'] * 1024 * 1024) throw new RuntimeException('File terlalu besar.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $allowed = array('image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif');
    if (!isset($allowed[$mime])) throw new RuntimeException('Format gambar tidak didukung.');
    $info=@getimagesize($f['tmp_name']);
    if(!$info || empty($info[0]) || empty($info[1])) throw new RuntimeException('File gambar tidak valid.');
    $name = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
    $dir = __DIR__ . '/../uploads/';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) throw new RuntimeException('Gagal membuat folder uploads utama.');
    if (!move_uploaded_file($f['tmp_name'], $dir . $name)) throw new RuntimeException('Gagal menyimpan upload ke folder uploads utama.');
    return 'uploads/' . $name;
}
function unique_slug(string $title, int $ignore = 0): string {
    global $pdo;
    $base = slugify($title); $slug = $base; $i = 2;
    while (true) {
        $q = $pdo->prepare('SELECT id FROM articles WHERE slug=? AND id<>? LIMIT 1');
        $q->execute(array($slug, $ignore));
        if (!$q->fetch()) return $slug;
        $slug = $base . '-' . $i++;
    }
}
function make_thumbnail(string $file, string $name) {
    if (!function_exists('imagecreatefromjpeg')) return null;
    $info = @getimagesize($file);
    if (!$info) return null;
    $w = (int)$info[0]; $h = (int)$info[1];
    $scale = min(1, 640 / max($w, $h));
    $nw = max(1, (int)($w * $scale)); $nh = max(1, (int)($h * $scale));
    $src = null;
    switch ($info['mime']) {
        case 'image/jpeg': $src = @imagecreatefromjpeg($file); break;
        case 'image/png': $src = @imagecreatefrompng($file); break;
        case 'image/webp': $src = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($file) : null; break;
        case 'image/gif': $src = @imagecreatefromgif($file); break;
    }
    if (!$src) return null;
    $dst = imagecreatetruecolor($nw, $nh);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    $tn = 'thumb-' . $name;
    $path = __DIR__ . '/../public/media/thumbs/' . $tn;
    @mkdir(dirname($path), 0755, true);
    $ok = function_exists('imagewebp') ? @imagewebp($dst, $path, 82) : @imagejpeg($dst, $path, 82);
    imagedestroy($src); imagedestroy($dst);
    return $ok ? 'media/thumbs/' . $tn : null;
}
function upload_media(string $field, string $kind = 'image') {
    global $config, $pdo;
    if (empty($_FILES[$field]['name'])) return null;
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Upload gagal.');
    if ($f['size'] > $config['upload_max_mb'] * 1024 * 1024) throw new RuntimeException('File terlalu besar.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $allowed = $kind === 'pdf' ? array('application/pdf'=>'pdf') : array('image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif');
    if (!isset($allowed[$mime])) throw new RuntimeException('Format file tidak didukung.');
    $name = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
    $dir = __DIR__ . '/../public/media/originals/'; @mkdir($dir, 0755, true);
    if (!move_uploaded_file($f['tmp_name'], $dir . $name)) throw new RuntimeException('Gagal menyimpan file.');
    $rel = 'media/originals/' . $name;
    $thumb = $kind === 'image' ? make_thumbnail($dir . $name, $name) : null;
    $q = $pdo->prepare('INSERT INTO media_library(title,image,thumb,mime,size_bytes) VALUES(?,?,?,?,?)');
    $q->execute(array(pathinfo($f['name'], PATHINFO_FILENAME), $rel, $thumb, $mime, $f['size']));
    return array('path'=>$rel, 'thumb'=>$thumb);
}
function track_view() {
    global $pdo;
    try { $pdo->exec("INSERT INTO analytics_daily(metric_date,views,visitors) VALUES(CURDATE(),1,1) ON DUPLICATE KEY UPDATE views=views+1"); } catch (Throwable $e) {}
}
