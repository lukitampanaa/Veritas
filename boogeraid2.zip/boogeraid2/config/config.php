<?php
// Production configuration. Keep database credentials private.
return [
 'app_name'=>'Majalah Sekolah Online',
 'base_url'=>'', // Optional: https://domain.tld/subfolder
 'db'=>[
   'host'=>'localhost',
   'name'=>'majalah_sekolah',
   'user'=>'CHANGE_DB_USER',
   'pass'=>'CHANGE_DB_PASSWORD',
   'charset'=>'utf8mb4'
 ],
 'upload_max_mb'=>8,
 'mail'=>['enabled'=>false,'from'=>'redaksi@example.sch.id','to'=>'redaksi@example.sch.id'],
 'whatsapp'=>['enabled'=>false,'number'=>'628xxxxxxxxxx'],
 'session_name'=>'MSO_SESSION'
];
