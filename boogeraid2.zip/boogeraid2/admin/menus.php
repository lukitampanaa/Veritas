<?php
require '_top.php';
require_login(['superadmin','admin']);

$editId = (int)($_GET['edit'] ?? 0);
$err = '';
$notice = '';

function menu_normalize_url($url, $linkType) {
    $url = trim((string)$url);
    if ($url === '') return '';
    if ($linkType === 'external') {
        return $url;
    }
    // Internal links are stored without the application base path so they remain portable.
    return ltrim($url, '/');
}

function menu_display_href($url) {
    $url = trim((string)$url);
    if ($url === '') return url('index.php');
    if (preg_match('~^(https?:)?//|^mailto:|^tel:|^#~i', $url)) return $url;
    return url($url);
}

function menu_is_external($url) {
    return (bool)preg_match('~^(https?:)?//|^mailto:|^tel:~i', trim((string)$url));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = $_POST['action'] ?? 'save';
    try {
        if ($action === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) throw new RuntimeException('Menu tidak valid.');
            $pdo->prepare('UPDATE menus SET is_active=IF(is_active=1,0,1) WHERE id=?')->execute([$id]);
            $notice = 'Status menu berhasil diubah.';
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) throw new RuntimeException('Menu tidak valid.');
            $q = $pdo->prepare('SELECT label FROM menus WHERE id=? LIMIT 1');
            $q->execute([$id]);
            $row = $q->fetch();
            if (!$row) throw new RuntimeException('Menu tidak ditemukan.');
            $pdo->prepare('DELETE FROM menus WHERE id=?')->execute([$id]);
            $notice = 'Menu "'.$row['label'].'" berhasil dihapus.';
        } elseif ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $label = trim((string)($_POST['label'] ?? ''));
            $linkType = ($_POST['link_type'] ?? 'internal') === 'external' ? 'external' : 'internal';
            $urlValue = menu_normalize_url($_POST['url'] ?? '', $linkType);
            $target = ($_POST['target'] ?? '_self') === '_blank' ? '_blank' : '_self';
            $sortOrder = (int)($_POST['sort_order'] ?? 10);
            $isActive = isset($_POST['is_active']) ? 1 : 0;

            if ($label === '') throw new RuntimeException('Label menu wajib diisi.');
            if ($urlValue === '') throw new RuntimeException('Link/URL wajib diisi.');
            if ($linkType === 'external' && !preg_match('~^(https?://|mailto:|tel:)~i', $urlValue)) {
                throw new RuntimeException('URL eksternal harus diawali http://, https://, mailto:, atau tel:.');
            }

            if ($id) {
                $q = $pdo->prepare('UPDATE menus SET label=?,url=?,target=?,sort_order=?,is_active=? WHERE id=?');
                $q->execute([$label,$urlValue,$target,$sortOrder,$isActive,$id]);
                $notice = 'Menu berhasil diperbarui.';
            } else {
                $q = $pdo->prepare('INSERT INTO menus(label,url,target,sort_order,is_active) VALUES(?,?,?,?,?)');
                $q->execute([$label,$urlValue,$target,$sortOrder,$isActive]);
                $notice = 'Menu berhasil ditambahkan.';
            }
            $editId = 0;
        }
    } catch (Throwable $e) {
        $err = $e->getMessage();
        if ($action === 'save') $editId = (int)($_POST['id'] ?? 0);
    }
}

$editing = null;
if ($editId) {
    $q = $pdo->prepare('SELECT * FROM menus WHERE id=? LIMIT 1');
    $q->execute([$editId]);
    $editing = $q->fetch();
}

$rows = $pdo->query('SELECT * FROM menus ORDER BY sort_order,id')->fetchAll();
?>
<style>
.menu-actions{display:flex;gap:6px;flex-wrap:wrap;align-items:center}.menu-actions a,.menu-actions button{font-size:12px;padding:6px 9px;border-radius:8px;border:1px solid #d9deea;background:#fff;color:#1e40af;text-decoration:none;cursor:pointer}.menu-actions .danger{color:#b91c1c;border-color:#fecaca}.menu-meta{display:block;color:#64748b;font-size:12px;margin-top:3px}.menu-form{display:grid;gap:10px}.menu-form .inline{display:grid;grid-template-columns:1fr 1fr;gap:10px}.menu-help{font-size:12px;color:#64748b;margin-top:-4px}.menu-badge{display:inline-block;padding:3px 7px;border-radius:999px;background:#eef2ff;color:#3730a3;font-size:11px;margin-left:5px}.menu-badge.off{background:#f1f5f9;color:#64748b}.menu-url{word-break:break-all}@media(max-width:800px){.menu-form .inline{grid-template-columns:1fr}}
</style>
<div class="twocol">
<section class="panel">
    <div class="panel-head"><h2><?= $editing ? 'Edit Menu' : 'Tambah menu' ?></h2><?php if($editing): ?><a class="btn" href="menus.php">+ Menu Baru</a><?php endif; ?></div>
    <?php if($err): ?><div class="alert"><?=e($err)?></div><?php endif; ?>
    <?php if($notice): ?><div class="alert" style="background:#dcfce7;color:#166534"><?=e($notice)?></div><?php endif; ?>
    <form method="post" class="menu-form">
        <input type="hidden" name="_csrf" value="<?=csrf()?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?=e($editing['id'] ?? '')?>">
        <input name="label" required placeholder="Label menu" value="<?=e($editing['label'] ?? '')?>">
        <div class="inline">
            <?php $editExternal = !empty($editing['url']) && menu_is_external($editing['url']); ?>
            <select name="link_type" id="linkType">
                <option value="internal" <?=!$editExternal?'selected':''?>>Link ke halaman situs</option>
                <option value="external" <?=$editExternal?'selected':''?>>Link ke website/URL eksternal</option>
            </select>
            <select name="target">
                <option value="_self" <?=($editing['target'] ?? '_self')==='_self'?'selected':''?>>Buka di tab yang sama</option>
                <option value="_blank" <?=($editing['target'] ?? '')==='_blank'?'selected':''?>>Buka di tab baru</option>
            </select>
        </div>
        <input name="url" id="menuUrl" required placeholder="URL / halaman" value="<?=e($editing['url'] ?? '')?>">
        <div class="menu-help" id="urlHelp">Contoh internal: articles.php?category=warta-sekolah atau gallery.php. Jangan tulis domain agar tetap portabel.</div>
        <div class="inline">
            <input type="number" name="sort_order" value="<?=e($editing['sort_order'] ?? 10)?>" min="0" placeholder="Urutan">
            <label style="display:flex;align-items:center;gap:8px"><input type="checkbox" name="is_active" value="1" <?=(!$editing || !empty($editing['is_active']))?'checked':''?>> Aktif ditampilkan di situs</label>
        </div>
        <button class="btn" type="submit"><?= $editing ? 'Simpan Perubahan' : 'Tambah Menu' ?></button>
    </form>
</section>
<section class="panel">
    <div class="panel-head"><h2>Menu Navigasi</h2><span class="menu-badge"><?=count(array_filter($rows, fn($x)=>(int)$x['is_active']===1))?> aktif · <?=count($rows)?> total</span></div>
    <?php foreach($rows as $r): ?>
        <div class="row">
            <div>
                <strong><?=e($r['label'])?></strong>
                <?php if(empty($r['is_active'])): ?><span class="menu-badge off">nonaktif</span><?php endif; ?>
                <span class="menu-meta"><span class="menu-url"><?=e($r['url'])?></span> · <?=$r['target']==='_blank'?'tab baru':'tab sama'?> · urutan <?=$r['sort_order']?></span>
            </div>
            <div class="menu-actions">
                <a href="<?=e(menu_display_href($r['url']))?>" target="_blank" rel="noopener">Lihat Situs ↗</a>
                <a href="menus.php?edit=<?=$r['id']?>">Edit</a>
                <form method="post">
                    <input type="hidden" name="_csrf" value="<?=csrf()?>">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="id" value="<?=$r['id']?>">
                    <button type="submit"><?=!empty($r['is_active'])?'Nonaktifkan':'Aktifkan'?></button>
                </form>
                <form method="post" onsubmit="return confirm('Hapus menu <?=e($r['label'])?>?');">
                    <input type="hidden" name="_csrf" value="<?=csrf()?>">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?=$r['id']?>">
                    <button type="submit" class="danger">Hapus</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
</section>
</div>
<script>
(function(){
  var type=document.getElementById('linkType'), url=document.getElementById('menuUrl'), help=document.getElementById('urlHelp');
  function update(){
    if(!type||!url||!help)return;
    if(type.value==='external'){
      url.placeholder='https://contoh.com/halaman';
      help.textContent='Contoh: https://www.youtube.com/@sekolah, https://instagram.com/sekolah, mailto:redaksi@sekolah.sch.id';
    }else{
      url.placeholder='articles.php?category=warta-sekolah';
      help.textContent='Contoh internal: articles.php?category=warta-sekolah, gallery.php, agenda.php, epaper.php atau submit.php.';
    }
  }
  if(type)type.addEventListener('change',update); update();
})();
</script>
<?php require '_bottom.php';
