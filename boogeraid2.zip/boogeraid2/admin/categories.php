<?php
require '_top.php';
require_login(['superadmin','admin']);

$editId = (int)($_GET['edit'] ?? 0);
$tagEditId = (int)($_GET['tag_edit'] ?? 0);
$err = '';
$notice = '';

function category_slug_unique($slug, $excludeId = 0) {
    global $pdo;
    $q = $pdo->prepare('SELECT id FROM categories WHERE slug=? AND id<>? LIMIT 1');
    $q->execute([$slug, (int)$excludeId]);
    return !$q->fetchColumn();
}

function valid_parent_category($parentId, $excludeId = 0) {
    global $pdo;
    if (!$parentId) return null;
    $q = $pdo->prepare('SELECT id, parent_id FROM categories WHERE id=? AND is_active=1 LIMIT 1');
    $q->execute([(int)$parentId]);
    $row = $q->fetch();
    if (!$row) return null;
    if ((int)$row['id'] === (int)$excludeId) return false;
    // Only one sub-rubrik level: a sub-rubrik cannot become a parent of another sub-rubrik.
    if ($row['parent_id'] !== null) return false;
    return (int)$row['id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = $_POST['action'] ?? 'create';
    try {
        if ($action === 'tag_save') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['name'] ?? ''));
            $isActive = isset($_POST['is_active']) ? 1 : 0;
            if ($name === '') throw new RuntimeException('Nama tag wajib diisi.');
            $slug = slugify($name);
            if ($id) {
                $q = $pdo->prepare('SELECT id FROM tags WHERE id=? LIMIT 1'); $q->execute([$id]);
                if (!$q->fetchColumn()) throw new RuntimeException('Tag tidak ditemukan.');
                $q = $pdo->prepare('SELECT id FROM tags WHERE (name=? OR slug=?) AND id<>? LIMIT 1'); $q->execute([$name,$slug,$id]);
                if ($q->fetchColumn()) throw new RuntimeException('Nama/slug tag sudah digunakan.');
                $pdo->prepare('UPDATE tags SET name=?,slug=?,is_active=? WHERE id=?')->execute([$name,$slug,$isActive,$id]);
                $notice = 'Tag berhasil diperbarui.';
            } else {
                $q = $pdo->prepare('SELECT id FROM tags WHERE name=? OR slug=? LIMIT 1'); $q->execute([$name,$slug]);
                if ($q->fetchColumn()) throw new RuntimeException('Nama/slug tag sudah digunakan.');
                $pdo->prepare('INSERT INTO tags(name,slug,is_active) VALUES(?,?,?)')->execute([$name,$slug,$isActive]);
                $notice = 'Tag berhasil ditambahkan.';
            }
            $tagEditId = 0;
        } elseif ($action === 'tag_toggle') {
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) throw new RuntimeException('Tag tidak valid.');
            $q = $pdo->prepare('UPDATE tags SET is_active=IF(is_active=1,0,1) WHERE id=?'); $q->execute([$id]);
            $notice = 'Status tag berhasil diubah.';
        } elseif ($action === 'tag_delete') {
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) throw new RuntimeException('Tag tidak valid.');
            $q = $pdo->prepare('SELECT name FROM tags WHERE id=? LIMIT 1'); $q->execute([$id]);
            $tag = $q->fetch();
            if (!$tag) throw new RuntimeException('Tag tidak ditemukan.');
            $q = $pdo->prepare('SELECT COUNT(*) FROM article_tags WHERE tag_id=?'); $q->execute([$id]);
            if ((int)$q->fetchColumn() > 0) throw new RuntimeException('Tag masih digunakan oleh artikel. Nonaktifkan tag jika tidak ingin tampil, atau lepaskan tag dari artikel terlebih dahulu.');
            $pdo->prepare('DELETE FROM tags WHERE id=?')->execute([$id]);
            $notice = 'Tag berhasil dihapus.';
        } elseif ($action === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) throw new RuntimeException('Rubrik tidak valid.');
            $pdo->prepare('UPDATE categories SET is_active=IF(is_active=1,0,1) WHERE id=?')->execute([$id]);
            $notice = 'Status rubrik berhasil diubah.';
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            if (!$id) throw new RuntimeException('Rubrik tidak valid.');
            $q = $pdo->prepare('SELECT id,name,parent_id FROM categories WHERE id=? LIMIT 1');
            $q->execute([$id]);
            $cat = $q->fetch();
            if (!$cat) throw new RuntimeException('Rubrik tidak ditemukan.');

            $q = $pdo->prepare('SELECT COUNT(*) FROM categories WHERE parent_id=?');
            $q->execute([$id]);
            if ((int)$q->fetchColumn() > 0) throw new RuntimeException('Rubrik ini masih memiliki sub-rubrik. Hapus/pindahkan sub-rubrik terlebih dahulu.');

            $q = $pdo->prepare('SELECT COUNT(*) FROM articles WHERE category_id=?');
            $q->execute([$id]);
            if ((int)$q->fetchColumn() > 0) throw new RuntimeException('Rubrik masih digunakan oleh artikel. Pindahkan artikel terlebih dahulu sebelum menghapus rubrik.');

            $pdo->prepare('DELETE FROM categories WHERE id=?')->execute([$id]);
            $notice = 'Rubrik berhasil dihapus.';
        } elseif ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['name'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));
            $slug = slugify($name);
            $parentRaw = $_POST['parent_id'] ?? '';
            $parentId = $parentRaw === '' ? null : (int)$parentRaw;
            $isActive = isset($_POST['is_active']) ? 1 : 0;

            if ($name === '') throw new RuntimeException('Nama rubrik wajib diisi.');
            if ($slug === '') throw new RuntimeException('Slug rubrik tidak dapat dibuat.');
            if (!category_slug_unique($slug, $id)) throw new RuntimeException('Slug rubrik sudah digunakan.');

            if ($parentId !== null) {
                $validParent = valid_parent_category($parentId, $id);
                if ($validParent === false) throw new RuntimeException('Sub-rubrik tidak boleh menjadi induk dari sub-rubrik lain atau menjadi induknya sendiri.');
                if ($validParent === null) throw new RuntimeException('Rubrik induk tidak valid.');
                $parentId = $validParent;
            }

            if ($id) {
                $q = $pdo->prepare('SELECT id FROM categories WHERE id=? LIMIT 1');
                $q->execute([$id]);
                if (!$q->fetchColumn()) throw new RuntimeException('Rubrik yang akan diedit tidak ditemukan.');
                $q = $pdo->prepare('UPDATE categories SET name=?,slug=?,description=?,parent_id=?,is_active=? WHERE id=?');
                $q->execute([$name,$slug,$description,$parentId,$isActive,$id]);
                $notice = 'Rubrik berhasil diperbarui.';
            } else {
                $max = (int)$pdo->query('SELECT COALESCE(MAX(sort_order),0) FROM categories')->fetchColumn();
                $q = $pdo->prepare('INSERT INTO categories(name,slug,description,parent_id,sort_order,is_active) VALUES(?,?,?,?,?,?)');
                $q->execute([$name,$slug,$description,$parentId,$max+1,$isActive]);
                $notice = $parentId ? 'Sub-rubrik berhasil ditambahkan.' : 'Rubrik utama berhasil ditambahkan.';
            }
            $editId = 0;
        }
    } catch (Throwable $e) {
        $err = $e->getMessage();
        if ($action === 'save') $editId = (int)($_POST['id'] ?? 0);
    }
}

$tagEditing = null;
if ($tagEditId) {
    $q = $pdo->prepare('SELECT * FROM tags WHERE id=? LIMIT 1'); $q->execute([$tagEditId]); $tagEditing = $q->fetch();
}

$editing = null;
if ($editId) {
    $q = $pdo->prepare('SELECT * FROM categories WHERE id=? LIMIT 1');
    $q->execute([$editId]);
    $editing = $q->fetch();
}

$parents = $pdo->query('SELECT id,name FROM categories WHERE parent_id IS NULL AND is_active=1 ORDER BY sort_order,name')->fetchAll();
$cs = $pdo->query("SELECT c.*, p.name AS parent_name,
    (SELECT COUNT(*) FROM categories sc WHERE sc.parent_id=c.id) AS child_count,
    (SELECT COUNT(*) FROM articles a WHERE a.category_id=c.id) AS article_count
    FROM categories c LEFT JOIN categories p ON p.id=c.parent_id
    ORDER BY CASE WHEN c.parent_id IS NULL THEN c.sort_order ELSE p.sort_order END, c.parent_id IS NOT NULL, c.sort_order, c.name")->fetchAll();
$ts = $pdo->query('SELECT * FROM tags ORDER BY name')->fetchAll();
?>
<style>
.cat-actions{display:flex;gap:6px;flex-wrap:wrap;align-items:center}.cat-actions a,.cat-actions button{font-size:12px;padding:6px 9px;border-radius:8px;border:1px solid #d9deea;background:#fff;color:#1e40af;text-decoration:none;cursor:pointer}.cat-actions .danger{color:#b91c1c;border-color:#fecaca}.cat-main{font-weight:700}.cat-sub{padding-left:28px;color:#334155}.cat-sub::before{content:'↳ ';color:#94a3b8}.cat-meta{display:block;color:#64748b;font-size:12px}.cat-form{display:grid;gap:10px}.cat-form .inline{display:grid;grid-template-columns:1fr 1fr;gap:10px}.cat-actions form{margin:0}.hint{font-size:12px;color:#64748b;margin-top:-5px}
@media(max-width:800px){.cat-form .inline{grid-template-columns:1fr}}
</style>
<div class="twocol">
<section class="panel">
    <div class="panel-head"><h2><?= $editing ? 'Edit Rubrik' : 'Rubrik' ?></h2><?php if($editing): ?><a class="btn" href="categories.php">+ Rubrik Baru</a><?php endif; ?></div>
    <?php if($err): ?><div class="alert"><?=e($err)?></div><?php endif; ?>
    <?php if($notice): ?><div class="alert" style="background:#dcfce7;color:#166534"><?=e($notice)?></div><?php endif; ?>
    <form method="post" class="cat-form">
        <input type="hidden" name="_csrf" value="<?=csrf()?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?=e($editing['id'] ?? '')?>">
        <div class="inline">
            <input name="name" required placeholder="Nama rubrik" value="<?=e($editing['name'] ?? '')?>">
            <select name="parent_id">
                <option value="">Rubrik utama</option>
                <?php foreach($parents as $p): if($editing && (int)$p['id']===(int)$editing['id']) continue; ?>
                    <option value="<?=$p['id']?>" <?=((string)($editing['parent_id'] ?? '')===(string)$p['id']?'selected':'')?>>Sub-rubrik: <?=e($p['name'])?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <input name="description" placeholder="Deskripsi" value="<?=e($editing['description'] ?? '')?>">
        <label><input type="checkbox" name="is_active" value="1" <?=(!$editing || !empty($editing['is_active']))?'checked':''?>> Aktif ditampilkan di situs</label>
        <div class="hint">Pilih “Rubrik utama” untuk kategori utama. Jika memilih rubrik induk, rubrik ini menjadi sub-rubrik.</div>
        <button class="btn" type="submit"><?= $editing ? 'Simpan Perubahan' : 'Tambah Rubrik' ?></button>
    </form>

    <div style="margin-top:18px">
    <?php foreach($cs as $c): ?>
        <div class="row">
            <div class="<?=empty($c['parent_id'])?'cat-main':'cat-sub'?>">
                <?=e($c['name'])?>
                <span class="cat-meta"><?= $c['parent_name'] ? 'Bagian dari: '.e($c['parent_name']) : 'Rubrik utama' ?> · <?=$c['article_count']?> artikel · <?=$c['child_count']?> sub-rubrik<?=empty($c['is_active'])?' · nonaktif':''?></span>
            </div>
            <div class="cat-actions">
                <a href="<?=e(url('articles.php?category='.rawurlencode($c['slug'])))?>" target="_blank" rel="noopener">Lihat Situs ↗</a>
                <a href="categories.php?edit=<?=$c['id']?>">Edit</a>
                <form method="post">
                    <input type="hidden" name="_csrf" value="<?=csrf()?>">
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="id" value="<?=$c['id']?>">
                    <button type="submit" title="Ubah status rubrik"><?=!empty($c['is_active'])?'Nonaktifkan':'Aktifkan'?></button>
                </form>
                <form method="post" onsubmit="return confirm('Hapus rubrik <?=e($c['name'])?>? Pastikan rubrik tidak memiliki artikel atau sub-rubrik.');">
                    <input type="hidden" name="_csrf" value="<?=csrf()?>">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?=$c['id']?>">
                    <button type="submit" class="danger">Hapus</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</section>
<section class="panel">
    <div class="panel-head"><h2><?= $tagEditing ? 'Edit Tag' : 'Tag' ?></h2><?php if($tagEditing): ?><a class="btn" href="categories.php">+ Tag Baru</a><?php endif; ?></div>
    <form method="post" class="cat-form">
        <input type="hidden" name="_csrf" value="<?=csrf()?>">
        <input type="hidden" name="action" value="tag_save">
        <input type="hidden" name="id" value="<?=e($tagEditing['id'] ?? '')?>">
        <input name="name" required placeholder="Nama tag" value="<?=e($tagEditing['name'] ?? '')?>">
        <label><input type="checkbox" name="is_active" value="1" <?=(!$tagEditing || !empty($tagEditing['is_active']))?'checked':''?>> Aktif ditampilkan di situs</label>
        <button class="btn"><?= $tagEditing ? 'Simpan Tag' : 'Tambah Tag' ?></button>
    </form>
    <div style="margin-top:18px">
    <?php foreach($ts as $t): ?>
        <div class="row">
            <div><strong>#<?=e($t['name'])?></strong><?php if(empty($t['is_active'])):?><span class="menu-badge off">nonaktif</span><?php endif;?></div>
            <div class="cat-actions">
                <a href="categories.php?tag_edit=<?=$t['id']?>">Edit</a>
                <form method="post"><input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="action" value="tag_toggle"><input type="hidden" name="id" value="<?=$t['id']?>"><button type="submit"><?=!empty($t['is_active'])?'Nonaktifkan':'Aktifkan'?></button></form>
                <form method="post" onsubmit="return confirm('Hapus tag <?=e($t['name'])?>?');"><input type="hidden" name="_csrf" value="<?=csrf()?>"><input type="hidden" name="action" value="tag_delete"><input type="hidden" name="id" value="<?=$t['id']?>"><button type="submit" class="danger">Hapus</button></form>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</section>
</div>
<?php require '_bottom.php';
