<?php require '_top.php';require_login(['superadmin','admin']);

$uiDefaults = [
  'header_bg'=>'#ffffff','header_text'=>'#172033','header_nav_bg'=>'#ffffff','header_nav_text'=>'#172033','header_nav_hover'=>'#1e40af',
  'header_height'=>'78','header_logo_width'=>'48','header_nav_padding'=>'14','header_border'=>'#f0f2f5',
  'header_show_tagline'=>'1','header_show_search'=>'1','header_sticky'=>'1',
  'header_ticker_enabled'=>'1','header_ticker_label'=>'TERKINI','header_ticker_speed'=>'34','header_ticker_bg'=>'#0b132b','header_ticker_label_bg'=>'#f2c500','header_ticker_text'=>'#ffffff','header_ticker_height'=>'46','header_ticker_direction'=>'left','header_ticker_pause'=>'1',
  'home_news_slider_enabled'=>'1','home_news_slider_autoplay'=>'1','home_news_slider_interval'=>'5','home_news_slider_count'=>'6','home_news_slider_transition'=>'slide','home_news_slider_transition_duration'=>'700','home_news_slider_transition_easing'=>'smooth','home_news_slider_thumbnails'=>'1','home_news_slider_show_excerpt'=>'1','home_news_slider_show_date'=>'1',
  'home_creative_enabled'=>'1','home_creative_title'=>'MOMEN & KREATIVITAS','home_creative_subtitle'=>'Kumpulan momen, album kegiatan, dan karya video warga sekolah.','home_creative_bg_start'=>'#8fd3ff','home_creative_bg_end'=>'#fff09a','home_quote_enabled'=>'1','home_quote_text'=>'Jangan biarkan hari kemarin merampas terlalu banyak hari ini.','home_quote_author'=>'WILL ROGERS',
  'home_creative_album_0_label'=>'ALBUM','home_creative_album_0_title'=>'','home_creative_album_0_image'=>'','home_creative_album_0_link'=>'',
  'home_creative_album_1_label'=>'ALBUM','home_creative_album_1_title'=>'','home_creative_album_1_image'=>'','home_creative_album_1_link'=>'',
  'home_creative_album_2_label'=>'ALBUM','home_creative_album_2_title'=>'','home_creative_album_2_image'=>'','home_creative_album_2_link'=>'',
  'home_creative_album_3_label'=>'ALBUM','home_creative_album_3_title'=>'','home_creative_album_3_image'=>'','home_creative_album_3_link'=>'',
  'home_creative_video_0_title'=>'','home_creative_video_0_thumbnail'=>'','home_creative_video_0_link'=>'',
  'home_creative_video_1_title'=>'','home_creative_video_1_thumbnail'=>'','home_creative_video_1_link'=>'',
  'home_creative_image_playlist_0'=>'','home_creative_image_playlist_1'=>'','home_creative_image_playlist_2'=>'','home_creative_image_playlist_3'=>'',
  'home_creative_video_playlist_0'=>'','home_creative_video_playlist_1'=>'',
  'footer_bg'=>'#ffffff','footer_text_color'=>'#374151','footer_heading_color'=>'#080808','footer_border_color'=>'#173b8f','footer_border_width'=>'2',
  'footer_top_padding'=>'28','footer_column_gap'=>'30','footer_columns'=>'4','footer_show_about'=>'1','footer_show_categories'=>'1','footer_show_collab'=>'1','footer_show_contact'=>'1','footer_show_social'=>'1','footer_show_whatsapp'=>'1',
  'footer_about_title'=>'Tentang Kami','footer_categories_title'=>'Kategori','footer_collab_title'=>'Kolaborasi, Yuk!','footer_contact_title'=>'Kontak Kami',
  'footer_bottom_left'=>'© {year} {school_name}','footer_bottom_right'=>'{site_name} · Media literasi, kreativitas, dan informasi sekolah',
  'footer_category_count'=>'8','footer_collab_count'=>'6','footer_category_items'=>'[]','footer_collab_items'=>'[]'
];

$loadFooterCategories=function()use($pdo){
  $rows=[];
  try{
    $rows=$pdo->query("SELECT id,name,slug,parent_id,is_active FROM categories WHERE is_active=1 ORDER BY parent_id IS NOT NULL, parent_id, name")->fetchAll();
  }catch(Throwable $e){
    try{$rows=$pdo->query("SELECT id,name,slug FROM categories ORDER BY name")->fetchAll();}catch(Throwable $ignore){}
  }
  return $rows;
};
$footerCategoryOptions=$loadFooterCategories();
$footerMenusForEditor=[];
try{$footerMenusForEditor=$pdo->query("SELECT id,label,url,target,is_active FROM menus WHERE is_active=1 ORDER BY sort_order,id")->fetchAll();}catch(Throwable $e){}
$decodeFooterItems=function($raw){
  $data=json_decode((string)$raw,true);
  if(!is_array($data))return [];
  $out=[];
  foreach($data as $item){
    if(!is_array($item))continue;
    $type=in_array(($item['type']??''),['category','external','menu'],true)?$item['type']:'category';
    $out[]=[
      'type'=>$type,
      'id'=>isset($item['id'])?(string)$item['id']:'',
      'label'=>isset($item['label'])?trim((string)$item['label']):'',
      'url'=>isset($item['url'])?trim((string)$item['url']):'',
      'target'=>($item['target']??'_self')==='_blank'?'_blank':'_self'
    ];
  }
  return array_slice($out,0,10);
};
$encodeFooterItems=function($items)use($decodeFooterItems){
  $clean=[];
  if(is_array($items)){
    foreach(array_slice($items,0,10) as $item){
      if(!is_array($item))continue;
      $type=in_array(($item['type']??''),['category','external','menu'],true)?$item['type']:'category';
      $id=trim((string)($item['id']??''));$label=trim((string)($item['label']??''));$url=trim((string)($item['url']??''));
      if(($type==='category'||$type==='menu') && $id==='')continue;
      if($type==='external' && ($label===''||$url===''))continue;
      if($type==='external' && !preg_match('#^(https?://|mailto:|tel:)#i',$url))continue;
      $clean[]=[
        'type'=>$type,'id'=>$id,'label'=>$label,'url'=>$url,
        'target'=>($item['target']??'_self')==='_blank'?'_blank':'_self'
      ];
    }
  }
  return json_encode($clean,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
};
$creativeImagePlaylists=[]; $creativeVideoPlaylists=[];
try { $allCreativePlaylists=$pdo->query("SELECT id,title,media_type FROM gallery_playlists WHERE is_active=1 ORDER BY media_type,title,id")->fetchAll(); foreach($allCreativePlaylists as $pl){ if(($pl['media_type']??'image')==='image') $creativeImagePlaylists[]=$pl; else $creativeVideoPlaylists[]=$pl; } } catch(Throwable $e) {}
$creativeImageSources=[]; $creativeVideoSources=[];
try {
  $creativeGalleryItems=$pdo->query("SELECT media_type,media_url,thumbnail_url,title FROM gallery_items WHERE is_active=1 ORDER BY created_at DESC,id DESC LIMIT 50")->fetchAll();
  foreach($creativeGalleryItems as $gi){
    $u=trim((string)($gi['media_url']??'')); if($u==='') continue;
    if(($gi['media_type']??'')==='image') $creativeImageSources[]=$u;
    else $creativeVideoSources[]=['url'=>$u,'thumb'=>trim((string)($gi['thumbnail_url']??'')),'title'=>trim((string)($gi['title']??''))];
  }
  // Media Library uploads are local files, not gallery_items. Expose them as
  // selectable sources for Momen & Kreativitas as well.
  $creativeLibraryItems=$pdo->query("SELECT image,thumb,title FROM media_library ORDER BY created_at DESC,id DESC LIMIT 50")->fetchAll();
  foreach($creativeLibraryItems as $mi){
    $u=trim((string)($mi['image']??''));
    if($u!=='') $creativeImageSources[]=app_file_url($u);
  }
  $creativeImageSources=array_values(array_unique($creativeImageSources));
} catch(Throwable $e) {}

if($_SERVER['REQUEST_METHOD']==='POST'){
  try{
    check_csrf();
    if(isset($pdo) && $pdo instanceof PDO){$pdo->beginTransaction();}

    $fields=['site_name','school_name','tagline','site_url','school_address','editor_in_chief','editorial_email','facebook','instagram','youtube','tiktok','x','whatsapp','primary_color','accent_color','footer_text','about_text'];
    $save=function($k,$v)use($pdo){
      $pdo->prepare('INSERT INTO settings(`key`,value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)')->execute([$k,(string)$v]);
    };
    foreach($fields as $k){
      if(array_key_exists($k,$_POST)) $save($k,trim((string)$_POST[$k]));
    }

    // Theme is a dedicated setting: changing it must not alter article/category,
    // navigation, header/footer, or other content data.
    if(array_key_exists('theme',$_POST)){
      $selectedTheme=trim((string)$_POST['theme']);
      $allowedThemes=['sunday','school','glass','midnight','minimal'];
      if(in_array($selectedTheme,$allowedThemes,true)) $save('theme',$selectedTheme);
    }

    foreach($uiDefaults as $k=>$default){
      $checkboxes=['header_show_tagline','header_show_search','header_sticky','header_ticker_enabled','header_ticker_pause','home_news_slider_enabled','home_news_slider_autoplay','home_news_slider_thumbnails','home_news_slider_show_excerpt','home_news_slider_show_date','home_creative_enabled','home_quote_enabled','footer_show_about','footer_show_categories','footer_show_collab','footer_show_contact','footer_show_social','footer_show_whatsapp'];
      if(in_array($k,['footer_category_items','footer_collab_items'],true)){
        $v=isset($_POST[$k])&&is_array($_POST[$k])?$encodeFooterItems($_POST[$k]):setting($k,$default);
      }elseif(in_array($k,$checkboxes,true)){
        // The form sends an explicit 0 for an unchecked checkbox and 1 when checked.
        // Never preserve the old value here: an unchecked setting is an intentional change.
        $v=(string)($_POST[$k]??'0')==='1'?'1':'0';
      }elseif(array_key_exists($k,$_POST)){
        $v=trim((string)$_POST[$k]);
      }else{
        // Never overwrite an existing setting with a UI default merely because a field is absent.
        $v=setting($k,$default);
      }
      if(in_array($k,['header_height','header_logo_width','header_nav_padding','header_ticker_speed','header_ticker_height','home_news_slider_interval','home_news_slider_count','home_news_slider_transition_duration','footer_border_width','footer_top_padding','footer_column_gap','footer_columns'],true)){
        $v=(string)max(0,min(120,(int)$v));
      }
      if(in_array($k,['footer_category_count','footer_collab_count'],true)) $v=(string)max(1,min(10,(int)$v));
      if(in_array($k,['footer_category_items','footer_collab_items'],true) && $v==='') $v='[]';
      $save($k,$v);
    }

    // Momen & Kreativitas: only site presentation settings are stored here.
    // Existing articles, categories, tags, menus and media records are never modified.
    $creativeTextKeys=['home_creative_title','home_creative_subtitle','home_creative_bg_start','home_creative_bg_end','home_quote_text','home_quote_author'];
    foreach($creativeTextKeys as $k){ if(array_key_exists($k,$_POST)) $save($k,trim((string)$_POST[$k])); }
    for($i=0;$i<4;$i++){ $k='home_creative_image_playlist_'.$i; if(array_key_exists($k,$_POST)) $save($k,trim((string)$_POST[$k])); }
    for($i=0;$i<2;$i++){ $k='home_creative_video_playlist_'.$i; if(array_key_exists($k,$_POST)) $save($k,trim((string)$_POST[$k])); }
    for($i=0;$i<4;$i++){
      foreach(['label','title','image','link'] as $suffix){
        $k='home_creative_album_'.$i.'_'.$suffix;
        if(array_key_exists($k,$_POST)) $save($k,trim((string)$_POST[$k]));
      }
    }
    for($i=0;$i<2;$i++){
      foreach(['title','thumbnail','link'] as $suffix){
        $k='home_creative_video_'.$i.'_'.$suffix;
        if(array_key_exists($k,$_POST)) $save($k,trim((string)$_POST[$k]));
      }
    }

    if(!empty($_FILES['logo']['name'])){
      $r=upload_media('logo','image');
      if($r && !empty($r['path'])) $save('logo',$r['path']);
    }
    if(!empty($_FILES['favicon']['name'])){
      $r=upload_media('favicon','image');
      if($r && !empty($r['path'])) $save('favicon',$r['path']);
    }

    if(isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->commit();
    flash('Pengaturan situs, identitas sekolah, tema, header, dan footer tersimpan.');
    header('Location: '.url('admin/settings.php'));
    exit;
  }catch(Throwable $e){
    if(isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    flash('Gagal menyimpan pengaturan: '.$e->getMessage());
    header('Location: '.url('admin/settings.php'));
    exit;
  }
}
$themes=['sunday'=>'Sunday Editorial','school'=>'School Classic','glass'=>'Glassmorphism','midnight'=>'Midnight','minimal'=>'Minimal'];
$keys=['site_name','school_name','tagline','site_url','school_address','editor_in_chief','editorial_email','facebook','instagram','youtube','tiktok','x','whatsapp','primary_color','accent_color','footer_text','about_text'];
$val=function($k)use($uiDefaults){return setting($k,$uiDefaults[$k]??'');};
$editorCategoryItems=$decodeFooterItems(setting('footer_category_items','[]'));
$editorCollabItems=$decodeFooterItems(setting('footer_collab_items','[]'));
$editorCategoryCount=max(1,min(10,(int)$val('footer_category_count')));
$editorCollabCount=max(1,min(10,(int)$val('footer_collab_count')));
?>
<style>
#saveAllSettings{transition:all .2s ease}
#saveAllSettings.save-off{opacity:.62;cursor:not-allowed;filter:grayscale(.18)}
#saveAllSettings.save-on{opacity:1;cursor:pointer;box-shadow:0 8px 22px rgba(30,64,175,.22)}
.settings-save-status{display:inline-flex;align-items:center;gap:8px;margin-left:10px;padding:9px 13px;border-radius:999px;font-size:12px;font-weight:800;border:1px solid #cbd5e1;background:#f8fafc;color:#64748b;vertical-align:middle}
.settings-save-status .dot{width:9px;height:9px;border-radius:50%;background:#94a3b8;box-shadow:0 0 0 3px rgba(148,163,184,.15)}
.settings-save-status.on{border-color:#93c5fd;background:#eff6ff;color:#1d4ed8}
.settings-save-status.on .dot{background:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.15)}
.settings-save-status.saving{border-color:#fde68a;background:#fffbeb;color:#92400e}
.settings-save-status.saving .dot{background:#f59e0b;box-shadow:0 0 0 3px rgba(245,158,11,.15);animation:settingsPulse 1s infinite}
@keyframes settingsPulse{50%{opacity:.35;transform:scale(.8)}}
.hf-editor{grid-column:1/-1;background:#f8fafc;border:1px solid #e5e7eb;border-radius:16px;padding:18px;margin-top:6px}
.hf-editor-head{display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap}.hf-editor h2{margin:0}.hf-editor p{margin:4px 0 0;color:#64748b}.hf-tabs{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}.hf-tab{border:1px solid #dbe3ef;background:#fff;color:#172033;border-radius:10px;padding:9px 14px;font-weight:800;cursor:pointer}.hf-tab.active{background:#1e40af;color:#fff;border-color:#1e40af}.hf-panel{display:none;background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:16px}.hf-panel.active{display:block}.hf-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.hf-grid.three{grid-template-columns:repeat(3,minmax(0,1fr))}.hf-grid.two{grid-template-columns:repeat(2,minmax(0,1fr))}.hf-creative-card-editor{display:grid;gap:9px;padding:14px;border:1px solid #e5e7eb;border-radius:13px;background:#fbfdff}.hf-creative-card-editor>strong{font-size:14px;color:#172033}.hf-field{display:grid;gap:6px}.hf-field small{color:#64748b;font-weight:400}.hf-field input[type=text],.hf-field input[type=number],.hf-field input[type=color],.hf-field select,.hf-field textarea{width:100%;box-sizing:border-box}.hf-field input[type=color]{height:43px;padding:4px}.hf-checks{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.hf-check{display:flex;align-items:center;gap:8px;padding:10px;border:1px solid #e5e7eb;border-radius:10px;background:#fafafa}.hf-check input{width:auto}.hf-note{padding:10px 12px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;color:#1e3a8a;margin-bottom:14px}.hf-preview{margin-top:14px;border:1px dashed #cbd5e1;border-radius:12px;padding:12px;background:#fff} .hf-preview b{display:block;margin-bottom:4px}.hf-full{grid-column:1/-1}.hf-linkbuilder{margin-top:16px;padding:14px;border:1px solid #e5e7eb;border-radius:14px;background:#fff}.hf-builder-head{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;flex-wrap:wrap}.hf-builder-head h3{margin:0}.hf-builder-head p{margin:4px 0 0;color:#64748b}.hf-inline-field{display:flex;align-items:center;gap:8px;font-weight:800}.hf-inline-field select{width:auto;min-width:70px}.hf-linkrows{display:grid;gap:8px}.hf-linkrow{display:grid;grid-template-columns:34px 170px minmax(180px,1fr) minmax(150px,1fr) minmax(170px,1fr) 120px;gap:8px;align-items:center;padding:9px;border:1px solid #e5e7eb;border-radius:10px;background:#f8fafc}.hf-linkrow select,.hf-linkrow input{min-width:0;width:100%;box-sizing:border-box}.hf-rowno{display:grid;place-items:center;width:30px;height:30px;border-radius:8px;background:#e2e8f0;font-weight:800;color:#334155}.hf-item-label{display:block}.hf-menu-select{background:#fff}@media(max-width:1050px){.hf-linkrow{grid-template-columns:34px 1fr 1fr}.hf-linkrow .hf-item-label,.hf-linkrow .hf-item-url,.hf-linkrow .hf-item-target{grid-column:span 1}}@media(max-width:800px){.hf-linkrow{grid-template-columns:34px 1fr}.hf-linkrow .hf-item-type,.hf-linkrow .hf-item-select,.hf-linkrow .hf-menu-select,.hf-linkrow .hf-item-label,.hf-linkrow .hf-item-url,.hf-linkrow .hf-item-target{grid-column:2}}@media(max-width:800px){.hf-grid,.hf-grid.three,.hf-checks{grid-template-columns:1fr}.hf-editor{padding:14px}}
</style>
<div class="titleline"><h1>Pengaturan & Branding</h1><a class="btn" href="<?=e(url(''))?>" target="_blank">Preview Situs ↗</a></div>
<?php if($m=flash()):?><div class="alert success"><?=e($m)?></div><?php endif;?>
<form id="siteSettingsForm" class="formcard settings-grid" method="post" action="settings.php" enctype="multipart/form-data" novalidate><input type="hidden" name="_csrf" value="<?=csrf()?>">
<h2>Identitas Majalah & Sekolah</h2><?php foreach($keys as $k):?><label><?=e(ucwords(str_replace('_',' ',$k)))?><?php if(in_array($k,['footer_text','about_text','school_address'])):?><textarea name="<?=e($k)?>"><?=e(setting($k))?></textarea><?php else:?><input name="<?=e($k)?>" value="<?=e(setting($k))?>"><?php endif;?></label><?php endforeach;?>
<h2>Tema Website</h2><div class="theme-picker"><?php $activeTheme=setting('theme','sunday'); foreach($themes as $k=>$label): ?><label class="theme-option"><input type="radio" name="theme" value="<?=e($k)?>" <?=($activeTheme===$k)?'checked':''?>><span class="swatch swatch-<?=e($k)?>"><b><?=e($label)?></b><small><?=e($k==='sunday'?'Editorial magazine':($k==='school'?'Formal sekolah':($k==='glass'?'Modern glass':($k==='midnight'?'Visual Midnight':'Visual Minimal'))))?></small></span></label><?php endforeach;?></div><div class="hf-note" style="margin-top:12px"><strong>Tema Saat Ini: <?=e($themes[$activeTheme]??'Sunday Editorial')?></strong><br>Pilih salah satu tema, lalu tekan <strong>ON — Simpan Semua Pengaturan</strong>. Hanya pengaturan tema yang berubah; artikel, rubrik, tag, menu, gambar, dan konten lainnya tetap dipertahankan.</div>

<div class="hf-editor">
  <div class="hf-editor-head"><div><h2>Editor Header & Footer</h2><p>Atur tampilan secara spesifik tanpa mengubah artikel, pengguna, rubrik, menu, atau data database yang sudah ada.</p></div><a class="btn" href="<?=e(url(''))?>" target="_blank">Lihat Perubahan ↗</a></div>
  <div class="hf-tabs"><button type="button" class="hf-tab active" data-tab="header">Header Website</button><button type="button" class="hf-tab" data-tab="home">Beranda Publik</button><button type="button" class="hf-tab" data-tab="creative">Momen & Kreativitas</button><button type="button" class="hf-tab" data-tab="footer">Footer Website</button></div>
  <section id="hf-header" class="hf-panel active">
    <div class="hf-note">Pengaturan header memengaruhi bagian logo, nama situs, tagline, pencarian, dan navigasi di seluruh halaman publik.</div>
    <div class="hf-grid three">
      <label class="hf-field">Warna latar header<input type="color" name="header_bg" value="<?=e($val('header_bg'))?>"></label>
      <label class="hf-field">Warna teks header<input type="color" name="header_text" value="<?=e($val('header_text'))?>"></label>
      <label class="hf-field">Warna garis navigasi<input type="color" name="header_border" value="<?=e($val('header_border'))?>"></label>
      <label class="hf-field">Tinggi header <small>60–120 px</small><input type="number" name="header_height" min="60" max="120" value="<?=e($val('header_height'))?>"></label>
      <label class="hf-field">Lebar logo <small>32–100 px</small><input type="number" name="header_logo_width" min="32" max="100" value="<?=e($val('header_logo_width'))?>"></label>
      <label class="hf-field">Padding menu <small>6–22 px</small><input type="number" name="header_nav_padding" min="6" max="22" value="<?=e($val('header_nav_padding'))?>"></label>
      <label class="hf-field">Warna latar navigasi<input type="color" name="header_nav_bg" value="<?=e($val('header_nav_bg'))?>"></label>
      <label class="hf-field">Warna teks navigasi<input type="color" name="header_nav_text" value="<?=e($val('header_nav_text'))?>"></label>
      <label class="hf-field">Warna hover menu<input type="color" name="header_nav_hover" value="<?=e($val('header_nav_hover'))?>"></label>
    </div>
    <div class="hf-note" style="margin-top:16px"><strong>Running Text / Ticker TERKINI</strong><br>Atur ticker berita yang berjalan horizontal. Sumber judul tetap berasal dari artikel yang sudah ada dan tidak mengubah isi/database.</div>
    <div class="hf-grid three">
      <label class="hf-field">Label ticker<input type="text" name="header_ticker_label" maxlength="30" value="<?=e($val('header_ticker_label'))?>"></label>
      <label class="hf-field">Kecepatan <small>10–120 detik/siklus</small><input type="number" name="header_ticker_speed" min="10" max="120" value="<?=e($val('header_ticker_speed'))?>"></label>
      <label class="hf-field">Tinggi ticker <small>32–70 px</small><input type="number" name="header_ticker_height" min="32" max="70" value="<?=e($val('header_ticker_height'))?>"></label>
      <label class="hf-field">Warna latar ticker<input type="color" name="header_ticker_bg" value="<?=e($val('header_ticker_bg'))?>"></label>
      <label class="hf-field">Warna label ticker<input type="color" name="header_ticker_label_bg" value="<?=e($val('header_ticker_label_bg'))?>"></label>
      <label class="hf-field">Warna teks ticker<input type="color" name="header_ticker_text" value="<?=e($val('header_ticker_text'))?>"></label>
      <label class="hf-field">Arah running text<select name="header_ticker_direction"><option value="left" <?=($val('header_ticker_direction')==='right'?'':'selected')?>>Kanan → kiri</option><option value="right" <?=($val('header_ticker_direction')==='right'?'selected':'')?>>Kiri → kanan</option></select></label>
    </div>
    <div class="hf-checks" style="margin-top:14px">
      <label class="hf-check"><input type="hidden" name="header_ticker_enabled" value="0"><input type="checkbox" name="header_ticker_enabled" value="1" <?=($val('header_ticker_enabled')==='1'?'checked':'')?>> Tampilkan running text</label>
      <label class="hf-check"><input type="hidden" name="header_ticker_pause" value="0"><input type="checkbox" name="header_ticker_pause" value="1" <?=($val('header_ticker_pause')==='1'?'checked':'')?>> Berhenti sementara saat mouse diarahkan</label>
    </div>
    <div class="hf-checks" style="margin-top:14px">
      <label class="hf-check"><input type="hidden" name="header_show_tagline" value="0"><input type="checkbox" name="header_show_tagline" value="1" <?=($val('header_show_tagline')==='1'?'checked':'')?>> Tampilkan tagline</label>
      <label class="hf-check"><input type="hidden" name="header_show_search" value="0"><input type="checkbox" name="header_show_search" value="1" <?=($val('header_show_search')==='1'?'checked':'')?>> Tampilkan pencarian</label>
      <label class="hf-check"><input type="hidden" name="header_sticky" value="0"><input type="checkbox" name="header_sticky" value="1" <?=($val('header_sticky')==='1'?'checked':'')?>> Header sticky saat scroll</label>
    </div>
  </section>
  <section id="hf-home" class="hf-panel">
    <div class="hf-note"><strong>Slide Thumbnail — Warta & Kabar Terkini</strong><br>Bagian berita publik menggunakan artikel yang sudah dipublikasikan. Konten, judul, rubrik, gambar, dan tautan tetap berasal dari data artikel yang sudah ada.</div>
    <div class="hf-grid three">
      <label class="hf-field">Jumlah artikel slide <small>3–10 artikel terbaru</small><input type="number" name="home_news_slider_count" min="3" max="10" value="<?=e($val('home_news_slider_count'))?>"></label>
      <label class="hf-field">Interval autoplay <small>2–15 detik</small><input type="number" name="home_news_slider_interval" min="2" max="15" value="<?=e($val('home_news_slider_interval'))?>"></label>
      <label class="hf-field">Transisi<select name="home_news_slider_transition"><option value="slide" <?=($val('home_news_slider_transition')==='fade'?'':'selected')?>>Slide</option><option value="fade" <?=($val('home_news_slider_transition')==='fade'?'selected':'')?>>Fade</option></select></label>
      <label class="hf-field">Durasi transisi <small>300–1500 ms • semakin besar semakin lembut</small><input type="number" name="home_news_slider_transition_duration" min="300" max="1500" step="50" value="<?=e($val('home_news_slider_transition_duration'))?>"></label>
      <label class="hf-field">Efek gerak <small>Kurva animasi</small><select name="home_news_slider_transition_easing"><option value="smooth" <?=($val('home_news_slider_transition_easing')==='smooth'?'selected':'')?>>Smooth / Natural</option><option value="soft" <?=($val('home_news_slider_transition_easing')==='soft'?'selected':'')?>>Soft / Gentle</option><option value="linear" <?=($val('home_news_slider_transition_easing')==='linear'?'selected':'')?>>Linear</option></select></label>
    </div>
    <div class="hf-checks" style="margin-top:14px">
      <label class="hf-check"><input type="hidden" name="home_news_slider_enabled" value="0"><input type="checkbox" name="home_news_slider_enabled" value="1" <?=($val('home_news_slider_enabled')==='1'?'checked':'')?>> Tampilkan slide artikel</label>
      <label class="hf-check"><input type="hidden" name="home_news_slider_autoplay" value="0"><input type="checkbox" name="home_news_slider_autoplay" value="1" <?=($val('home_news_slider_autoplay')==='1'?'checked':'')?>> Putar otomatis</label>
      <label class="hf-check"><input type="hidden" name="home_news_slider_thumbnails" value="0"><input type="checkbox" name="home_news_slider_thumbnails" value="1" <?=($val('home_news_slider_thumbnails')==='1'?'checked':'')?>> Tampilkan thumbnail</label>
      <label class="hf-check"><input type="hidden" name="home_news_slider_show_excerpt" value="0"><input type="checkbox" name="home_news_slider_show_excerpt" value="1" <?=($val('home_news_slider_show_excerpt')==='1'?'checked':'')?>> Tampilkan ringkasan</label>
      <label class="hf-check"><input type="hidden" name="home_news_slider_show_date" value="0"><input type="checkbox" name="home_news_slider_show_date" value="1" <?=($val('home_news_slider_show_date')==='1'?'checked':'')?>> Tampilkan tanggal</label>
    </div>
  </section>
  <section id="hf-creative" class="hf-panel">
    <div class="hf-note"><strong>Momen & Kreativitas</strong><br>Kelola bagian visual Beranda seperti contoh: 4 kartu album di sisi kiri, sampai 2 kartu video di sisi kanan, serta kutipan motivasi di bawahnya. Semua isinya tersimpan sebagai pengaturan tampilan saja; data artikel, rubrik, tag, menu, dan media tidak diubah.</div>
    <div class="hf-checks">
      <label class="hf-check"><input type="hidden" name="home_creative_enabled" value="0"><input type="checkbox" name="home_creative_enabled" value="1" <?=($val('home_creative_enabled')==='1'?'checked':'')?>> Tampilkan Momen & Kreativitas</label>
      <label class="hf-check"><input type="hidden" name="home_quote_enabled" value="0"><input type="checkbox" name="home_quote_enabled" value="1" <?=($val('home_quote_enabled')==='1'?'checked':'')?>> Tampilkan kutipan motivasi</label>
    </div>
    <div class="hf-grid three" style="margin-top:14px">
      <label class="hf-field">Judul section<input type="text" name="home_creative_title" value="<?=e($val('home_creative_title'))?>"></label>
      <label class="hf-field">Subjudul <small>opsional</small><input type="text" name="home_creative_subtitle" value="<?=e($val('home_creative_subtitle'))?>"></label>
      <label class="hf-field">Warna gradient 1<input type="color" name="home_creative_bg_start" value="<?=e($val('home_creative_bg_start'))?>"></label>
      <label class="hf-field">Warna gradient 2<input type="color" name="home_creative_bg_end" value="<?=e($val('home_creative_bg_end'))?>"></label>
    </div>
    <datalist id="creativeImageSources"><?php foreach($creativeImageSources as $src): ?><option value="<?=e($src)?>"><?php endforeach; ?></datalist>
    <datalist id="creativeVideoSources"><?php foreach($creativeVideoSources as $src): ?><option value="<?=e($src['url'])?>" label="<?=e($src['title'])?>"><?php endforeach; ?></datalist>
    <div class="hf-linkbuilder">
      <div class="hf-builder-head"><div><h3>4 Playlist Galeri Gambar</h3><p>Momen &amp; Kreativitas mengambil data langsung dari playlist <b>Galeri Gambar</b>.</p></div></div>
      <div class="hf-grid two">
      <?php for($i=0;$i<4;$i++): $selected=(string)$val('home_creative_image_playlist_'.$i); ?>
        <div class="hf-creative-card-editor">
          <strong>Momen <?=($i+1)?></strong>
          <label class="hf-field">Playlist Gambar<select name="home_creative_image_playlist_<?=$i?>"><option value="">— Tidak dipilih —</option><?php foreach($creativeImagePlaylists as $pl): ?><option value="<?=e($pl['id'])?>" <?=($selected===(string)$pl['id']?'selected':'')?>><?=e($pl['title'])?></option><?php endforeach; ?></select></label>
          <small class="muted">Hanya playlist bertipe Galeri Gambar.</small>
        </div>
      <?php endfor; ?>
      </div>
    </div>
    <div class="hf-linkbuilder">
      <div class="hf-builder-head"><div><h3>2 Playlist Galeri Video</h3><p>Momen &amp; Kreativitas mengambil data langsung dari playlist <b>Galeri Video</b>.</p></div></div>
      <div class="hf-grid two">
      <?php for($i=0;$i<2;$i++): $selected=(string)$val('home_creative_video_playlist_'.$i); ?>
        <div class="hf-creative-card-editor">
          <strong>Video <?=($i+1)?></strong>
          <label class="hf-field">Playlist Video<select name="home_creative_video_playlist_<?=$i?>"><option value="">— Tidak dipilih —</option><?php foreach($creativeVideoPlaylists as $pl): ?><option value="<?=e($pl['id'])?>" <?=($selected===(string)$pl['id']?'selected':'')?>><?=e($pl['title'])?></option><?php endforeach; ?></select></label>
          <small class="muted">Hanya playlist bertipe Galeri Video.</small>
        </div>
      <?php endfor; ?>
      </div>
    </div>
    <div class="hf-linkbuilder">
      <div class="hf-builder-head"><div><h3>Kutipan Motivasi</h3><p>Bagian gelap di bawah Momen & Kreativitas.</p></div></div>
      <div class="hf-grid two">
        <label class="hf-field">Teks kutipan<textarea name="home_quote_text" rows=3><?=e($val('home_quote_text'))?></textarea></label>
        <label class="hf-field">Nama penulis<input type="text" name="home_quote_author" value="<?=e($val('home_quote_author'))?>" placeholder="Nama penulis"></label>
      </div>
    </div>
  </section>
  <section id="hf-footer" class="hf-panel">
    <div class="hf-note">Editor footer dibuat mengikuti pola footer horizontal 4 kolom. Anda dapat menentukan warna, jarak, jumlah kolom, judul, dan bagian yang ditampilkan.</div>
    <div class="hf-linkbuilder">
      <div class="hf-builder-head"><div><h3>Isi Kolom Kategori</h3><p>Pilih rubrik atau subrubrik yang sudah ada. Kategori juga dapat diisi tautan pihak ketiga.</p></div>
        <label class="hf-inline-field">Jumlah tampil <select name="footer_category_count"><?php for($i=1;$i<=10;$i++):?><option value="<?=$i?>" <?=($editorCategoryCount===$i?'selected':'')?>><?=$i?></option><?php endfor;?></select></label>
      </div>
      <div class="hf-linkrows" data-builder="category">
      <?php for($i=0;$i<10;$i++): $item=$editorCategoryItems[$i]??['type'=>'category','id'=>'','label'=>'','url'=>'','target'=>'_self']; ?>
        <div class="hf-linkrow" data-row="<?=$i?>">
          <span class="hf-rowno"><?=($i+1)?></span>
          <select class="hf-item-type" name="footer_category_items[<?=$i?>][type]"><option value="category" <?=($item['type']==='category'?'selected':'')?>>Rubrik / Subrubrik</option><option value="external" <?=($item['type']==='external'?'selected':'')?>>Tautan pihak ketiga</option><option value="menu" <?=($item['type']==='menu'?'selected':'')?>>Menu</option></select>
          <select class="hf-item-select" name="footer_category_items[<?=$i?>][id]" <?=($item['type']!=='category'?'disabled':'')?>><option value="">— Pilih rubrik / subrubrik —</option><?php foreach($footerCategoryOptions as $co): $isSub=isset($co['parent_id']) && (int)$co['parent_id']>0; ?><option value="<?=e($co['id'])?>" <?=((string)$item['id']===(string)$co['id']?'selected':'')?>><?=($isSub?'↳ Subrubrik: ':'Rubrik: '),e($co['name'])?></option><?php endforeach;?></select>
          <select class="hf-menu-select" name="footer_category_items[<?=$i?>][id]" <?=($item['type']!=='menu'?'disabled':'')?> style="display:none"><option value="">— Pilih menu —</option><?php foreach($footerMenusForEditor as $mo): ?><option value="<?=e($mo['id'])?>" <?=($item['type']==='menu' && (string)$item['id']===(string)$mo['id']?'selected':'')?>><?=e($mo['label'])?></option><?php endforeach;?></select>
          <input class="hf-item-label" type="text" name="footer_category_items[<?=$i?>][label]" value="<?=e($item['label'])?>" placeholder="Label tautan">
          <input class="hf-item-url" type="url" name="footer_category_items[<?=$i?>][url]" value="<?=e($item['url'])?>" placeholder="https://contoh.com" style="display:none">
          <select class="hf-item-target" name="footer_category_items[<?=$i?>][target]"><option value="_self" <?=($item['target']!=='_blank'?'selected':'')?>>Tab yang sama</option><option value="_blank" <?=($item['target']==='_blank'?'selected':'')?>>Tab baru</option></select>
        </div>
      <?php endfor;?>
      </div>
    </div>

    <div class="hf-linkbuilder">
      <div class="hf-builder-head"><div><h3>Isi Kolom Kolaborasi</h3><p>Dapat memilih rubrik, subrubrik, menu yang sudah tersedia, atau tautan khusus.</p></div>
        <label class="hf-inline-field">Jumlah tampil <select name="footer_collab_count"><?php for($i=1;$i<=10;$i++):?><option value="<?=$i?>" <?=($editorCollabCount===$i?'selected':'')?>><?=$i?></option><?php endfor;?></select></label>
      </div>
      <div class="hf-linkrows" data-builder="collab">
      <?php for($i=0;$i<10;$i++): $item=$editorCollabItems[$i]??['type'=>'menu','id'=>'','label'=>'','url'=>'','target'=>'_self']; ?>
        <div class="hf-linkrow" data-row="<?=$i?>">
          <span class="hf-rowno"><?=($i+1)?></span>
          <select class="hf-item-type" name="footer_collab_items[<?=$i?>][type]"><option value="category" <?=($item['type']==='category'?'selected':'')?>>Rubrik / Subrubrik</option><option value="menu" <?=($item['type']==='menu'?'selected':'')?>>Menu Kolaborasi</option><option value="external" <?=($item['type']==='external'?'selected':'')?>>Tautan pihak ketiga</option></select>
          <select class="hf-item-select" name="footer_collab_items[<?=$i?>][id]" <?=($item['type']!=='category'?'disabled':'')?>><option value="">— Pilih rubrik / subrubrik —</option><?php foreach($footerCategoryOptions as $co): $isSub=isset($co['parent_id']) && (int)$co['parent_id']>0; ?><option value="<?=e($co['id'])?>" <?=($item['type']==='category' && (string)$item['id']===(string)$co['id']?'selected':'')?>><?=($isSub?'↳ Subrubrik: ':'Rubrik: '),e($co['name'])?></option><?php endforeach;?></select>
          <select class="hf-menu-select" name="footer_collab_items[<?=$i?>][id]" <?=($item['type']!=='menu'?'disabled':'')?>><option value="">— Pilih menu —</option><?php foreach($footerMenusForEditor as $mo): ?><option value="<?=e($mo['id'])?>" <?=($item['type']==='menu' && (string)$item['id']===(string)$mo['id']?'selected':'')?>><?=e($mo['label'])?></option><?php endforeach;?></select>
          <input class="hf-item-label" type="text" name="footer_collab_items[<?=$i?>][label]" value="<?=e($item['label'])?>" placeholder="Label tautan">
          <input class="hf-item-url" type="url" name="footer_collab_items[<?=$i?>][url]" value="<?=e($item['url'])?>" placeholder="https://contoh.com">
          <select class="hf-item-target" name="footer_collab_items[<?=$i?>][target]"><option value="_self" <?=($item['target']!=='_blank'?'selected':'')?>>Tab yang sama</option><option value="_blank" <?=($item['target']==='_blank'?'selected':'')?>>Tab baru</option></select>
        </div>
      <?php endfor;?>
      </div>
    </div>
    <div class="hf-grid three">
      <label class="hf-field">Warna latar footer<input type="color" name="footer_bg" value="<?=e($val('footer_bg'))?>"></label>
      <label class="hf-field">Warna teks footer<input type="color" name="footer_text_color" value="<?=e($val('footer_text_color'))?>"></label>
      <label class="hf-field">Warna judul footer<input type="color" name="footer_heading_color" value="<?=e($val('footer_heading_color'))?>"></label>
      <label class="hf-field">Warna garis atas<input type="color" name="footer_border_color" value="<?=e($val('footer_border_color'))?>"></label>
      <label class="hf-field">Ketebalan garis <small>0–10 px</small><input type="number" name="footer_border_width" min="0" max="10" value="<?=e($val('footer_border_width'))?>"></label>
      <label class="hf-field">Padding atas <small>0–120 px</small><input type="number" name="footer_top_padding" min="0" max="120" value="<?=e($val('footer_top_padding'))?>"></label>
      <label class="hf-field">Jarak antar kolom <small>10–80 px</small><input type="number" name="footer_column_gap" min="10" max="80" value="<?=e($val('footer_column_gap'))?>"></label>
      <label class="hf-field">Jumlah kolom <select name="footer_columns"><option value="4" <?=($val('footer_columns')==='4'?'selected':'')?>>4 kolom</option><option value="3" <?=($val('footer_columns')==='3'?'selected':'')?>>3 kolom</option><option value="2" <?=($val('footer_columns')==='2'?'selected':'')?>>2 kolom</option></select></label>
      <label class="hf-field">Judul Tentang Kami<input type="text" name="footer_about_title" value="<?=e($val('footer_about_title'))?>"></label>
      <label class="hf-field">Judul Kategori<input type="text" name="footer_categories_title" value="<?=e($val('footer_categories_title'))?>"></label>
      <label class="hf-field">Judul Kolaborasi<input type="text" name="footer_collab_title" value="<?=e($val('footer_collab_title'))?>"></label>
      <label class="hf-field">Judul Kontak<input type="text" name="footer_contact_title" value="<?=e($val('footer_contact_title'))?>"></label>
      <label class="hf-field hf-full">Teks bagian bawah kiri <small>Token yang tersedia: {year}, {school_name}, {site_name}</small><input type="text" name="footer_bottom_left" value="<?=e($val('footer_bottom_left'))?>"></label>
      <label class="hf-field hf-full">Teks bagian bawah kanan <small>Token yang tersedia: {year}, {school_name}, {site_name}</small><input type="text" name="footer_bottom_right" value="<?=e($val('footer_bottom_right'))?>"></label>
    </div>
    <div class="hf-checks" style="margin-top:14px">
      <label class="hf-check"><input type="hidden" name="footer_show_about" value="0"><input type="checkbox" name="footer_show_about" value="1" <?=($val('footer_show_about')==='1'?'checked':'')?>> Tampilkan Tentang Kami</label>
      <label class="hf-check"><input type="hidden" name="footer_show_categories" value="0"><input type="checkbox" name="footer_show_categories" value="1" <?=($val('footer_show_categories')==='1'?'checked':'')?>> Tampilkan Kategori</label>
      <label class="hf-check"><input type="hidden" name="footer_show_collab" value="0"><input type="checkbox" name="footer_show_collab" value="1" <?=($val('footer_show_collab')==='1'?'checked':'')?>> Tampilkan Kolaborasi</label>
      <label class="hf-check"><input type="hidden" name="footer_show_contact" value="0"><input type="checkbox" name="footer_show_contact" value="1" <?=($val('footer_show_contact')==='1'?'checked':'')?>> Tampilkan Kontak</label>
      <label class="hf-check"><input type="hidden" name="footer_show_social" value="0"><input type="checkbox" name="footer_show_social" value="1" <?=($val('footer_show_social')==='1'?'checked':'')?>> Tampilkan Media Sosial</label>
      <label class="hf-check"><input type="hidden" name="footer_show_whatsapp" value="0"><input type="checkbox" name="footer_show_whatsapp" value="1" <?=($val('footer_show_whatsapp')==='1'?'checked':'')?>> Tampilkan tombol WhatsApp melayang</label>
    </div>
  </section>
</div>

<div class="upload-grid"><label>Logo Website<input type="file" name="logo" accept="image/*"><?php if(setting('logo')):?><img class="settings-logo" src="<?=e(app_file_url(setting('logo')))?>" alt="Logo"></label><?php endif;?><label>Favicon<input type="file" name="favicon" accept="image/*"></label></div>
<div class="settings-save-wrap" style="display:flex;align-items:center;justify-content:flex-end;gap:10px;flex-wrap:wrap;margin-top:8px">
<button type="submit" id="saveAllSettings" class="btn save-off" disabled aria-disabled="true">OFF — Belum ada perubahan</button>
<span id="settingsSaveStatus" class="settings-save-status" role="status" aria-live="polite"><span class="dot"></span>Belum ada data pengaturan baru</span>
</div></form>
<script>
(function(){
 function syncRow(row){
   var type=row.querySelector('.hf-item-type'); if(!type)return;
   var t=type.value, cat=row.querySelector('.hf-item-select'), menu=row.querySelector('.hf-menu-select'), url=row.querySelector('.hf-item-url'), label=row.querySelector('.hf-item-label'), target=row.querySelector('.hf-item-target');
   if(cat){cat.style.display=t==='category'?'block':'none';cat.disabled=t!=='category';}
   if(menu){menu.style.display=t==='menu'?'block':'none';menu.disabled=t!=='menu';}
   if(url){url.style.display=t==='external'?'block':'none';url.disabled=t!=='external';}
   if(label){label.style.display=t==='external'?'block':'none';label.disabled=t!=='external';}
   if(target){target.style.display=t==='category'?'none':'block';target.disabled=t==='category';}
   var count=0;
   var builder=row.closest('.hf-linkrows');
   if(builder){var sel=builder.previousElementSibling&&builder.previousElementSibling.querySelector('select'); count=sel?parseInt(sel.value||'10',10):10; row.style.display=parseInt(row.getAttribute('data-row'),10)<count?'grid':'none';}
 }
 document.querySelectorAll('.hf-linkrow').forEach(function(row){var t=row.querySelector('.hf-item-type');if(t)t.addEventListener('change',function(){syncRow(row)});syncRow(row)});
 document.querySelectorAll('select[name="footer_category_count"],select[name="footer_collab_count"]').forEach(function(sel){sel.addEventListener('change',function(){var builder=sel.closest('.hf-builder-head').nextElementSibling;if(builder)builder.querySelectorAll('.hf-linkrow').forEach(syncRow)})});
})();

var settingsForm=document.getElementById('siteSettingsForm');
(function(){
  if(!settingsForm)return;
  var saveBtn=document.getElementById('saveAllSettings');
  var status=document.getElementById('settingsSaveStatus');
  var initialSnapshot='';
  var saving=false;

  function controlSnapshot(){
    var rows=[];
    settingsForm.querySelectorAll('input,select,textarea').forEach(function(el){
      if(el.name==='_csrf' || el.id==='saveAllSettings' || el.disabled)return;
      if(el.type==='file'){
        rows.push([el.name, Array.prototype.map.call(el.files||[],function(f){return f.name+'|'+f.size+'|'+f.lastModified;}).join(',')]);
        return;
      }
      if(el.type==='checkbox' || el.type==='radio'){
        rows.push([el.name, el.checked ? String(el.value||'1') : '']);
      }else{
        rows.push([el.name, String(el.value==null?'':el.value)]);
      }
    });
    rows.sort(function(a,b){var x=a[0]+'\u0000'+a[1],y=b[0]+'\u0000'+b[1];return x<y?-1:x>y?1:0;});
    return JSON.stringify(rows);
  }

  function setState(on){
    if(!saveBtn || saving)return;
    if(on){
      saveBtn.disabled=false;
      saveBtn.classList.remove('save-off');
      saveBtn.classList.add('save-on');
      saveBtn.setAttribute('aria-disabled','false');
      saveBtn.textContent='ON — Simpan Semua Pengaturan';
      if(status){status.classList.add('on');status.classList.remove('saving');status.innerHTML='<span class="dot"></span>Ada perubahan yang siap disimpan';}
    }else{
      saveBtn.disabled=true;
      saveBtn.classList.remove('save-on');
      saveBtn.classList.add('save-off');
      saveBtn.setAttribute('aria-disabled','true');
      saveBtn.textContent='OFF — Belum ada perubahan';
      if(status){status.classList.remove('on','saving');status.innerHTML='<span class="dot"></span>Belum ada data pengaturan baru';}
    }
  }

  function refreshState(){
    if(saving)return;
    setState(controlSnapshot()!==initialSnapshot);
  }

  // Jalankan sinkronisasi baris footer lebih dulu, lalu ambil snapshot nilai awal.
  setTimeout(function(){
    initialSnapshot=controlSnapshot();
    setState(false);
  },0);

  settingsForm.addEventListener('input',refreshState);
  settingsForm.addEventListener('change',refreshState);

  settingsForm.addEventListener('submit',function(ev){
    if(saving)return;
    // The button is enabled only after a detected change. Do not block the
    // native form submission here: this keeps saving reliable even when a
    // browser normalizes a form control value differently from our snapshot.
    saving=true;
    if(saveBtn){
      saveBtn.disabled=true;
      saveBtn.classList.remove('save-on');
      saveBtn.classList.add('save-off');
      saveBtn.setAttribute('aria-disabled','true');
      saveBtn.textContent='Menyimpan Pengaturan...';
    }
    if(status){
      status.classList.remove('on');
      status.classList.add('saving');
      status.innerHTML='<span class="dot"></span>Pengaturan sedang disimpan...';
    }
  });
})();

document.querySelectorAll('.hf-tab').forEach(function(btn){btn.addEventListener('click',function(){document.querySelectorAll('.hf-tab').forEach(function(x){x.classList.remove('active')});document.querySelectorAll('.hf-panel').forEach(function(x){x.classList.remove('active')});btn.classList.add('active');var panel=document.getElementById('hf-'+btn.getAttribute('data-tab'));if(panel)panel.classList.add('active');});});
</script>
<?php require '_bottom.php';
