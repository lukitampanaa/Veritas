<?php
// V5.12.2 — Comment moderation routing/redeclare hotfix.
// IMPORTANT: _top.php already loads app/bootstrap.php. Do not require bootstrap.php here,
// otherwise helper functions such as e() are declared twice.
require '_top.php';

$role = (string)auth()['role'];
if (!in_array($role, array('superadmin', 'admin'), true)) {
    http_response_code(403);
    exit('Akses ditolak. Moderasi komentar hanya untuk Superadmin dan Admin.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $id = (int)($_POST['id'] ?? 0);
    $action = (string)($_POST['action'] ?? '');

    if ($id <= 0 || !in_array($action, array('approve', 'reject', 'delete'), true)) {
        flash('Permintaan moderasi tidak valid.');
        redirect('admin/comments.php');
    }

    $find = $pdo->prepare('SELECT id FROM comments WHERE id=? LIMIT 1');
    $find->execute(array($id));
    if (!$find->fetchColumn()) {
        flash('Komentar tidak ditemukan.');
        redirect('admin/comments.php');
    }

    if ($action === 'delete') {
        $q = $pdo->prepare('DELETE FROM comments WHERE id=?');
        $q->execute(array($id));
        flash('Komentar dihapus.');
    } else {
        $status = $action === 'approve' ? 'approved' : 'rejected';
        $q = $pdo->prepare('UPDATE comments SET status=? WHERE id=?');
        $q->execute(array($status, $id));
        flash($status === 'approved'
            ? 'Komentar disetujui dan ditampilkan.'
            : 'Komentar ditolak dan tidak ditampilkan.');
    }
    redirect('admin/comments.php');
}

$filter = (string)($_GET['status'] ?? 'pending');
$allowed = array('pending', 'approved', 'rejected', 'all');
if (!in_array($filter, $allowed, true)) {
    $filter = 'pending';
}

$counts = array('pending' => 0, 'approved' => 0, 'rejected' => 0);
$st = $pdo->query("SELECT status, COUNT(*) total FROM comments GROUP BY status");
foreach ($st as $row) {
    if (isset($counts[$row['status']])) {
        $counts[$row['status']] = (int)$row['total'];
    }
}

$sql = "SELECT c.*, a.title article_title, a.slug article_slug, u.username
        FROM comments c
        LEFT JOIN articles a ON a.id=c.article_id
        LEFT JOIN users u ON u.id=c.user_id";
$params = array();
if ($filter !== 'all') {
    $sql .= ' WHERE c.status=?';
    $params[] = $filter;
}
$sql .= ' ORDER BY c.created_at DESC';
$q = $pdo->prepare($sql);
$q->execute($params);
$comments = $q->fetchAll();
?>
<section class="adminsection">
    <div style="display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap">
        <div>
            <h1>Komentar</h1>
            <p class="muted">Persetujuan komentar hanya dapat dilakukan oleh Superadmin dan Admin.</p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a class="btn" href="comments.php?status=pending">Menunggu (<?= $counts['pending'] ?>)</a>
            <a class="btn" href="comments.php?status=approved">Disetujui (<?= $counts['approved'] ?>)</a>
            <a class="btn" href="comments.php?status=rejected">Ditolak (<?= $counts['rejected'] ?>)</a>
            <a class="btn" href="comments.php?status=all">Semua</a>
        </div>
    </div>

    <?php if (!$comments): ?>
        <div class="card"><p>Tidak ada komentar pada filter ini.</p></div>
    <?php else: ?>
        <div class="card" style="overflow:auto">
            <table style="width:100%;border-collapse:collapse">
                <thead>
                    <tr>
                        <th style="text-align:left;padding:12px">Komentar</th>
                        <th style="text-align:left;padding:12px">Artikel</th>
                        <th style="text-align:left;padding:12px">Pengguna</th>
                        <th style="text-align:left;padding:12px">Status</th>
                        <th style="text-align:left;padding:12px">Tanggal</th>
                        <th style="padding:12px">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($comments as $cm): ?>
                    <tr style="border-top:1px solid #e5e7eb;vertical-align:top">
                        <td style="padding:12px;min-width:280px">
                            <strong><?= e($cm['name']) ?></strong>
                            <?php if (!empty($cm['email'])): ?><small style="display:block"><?= e($cm['email']) ?></small><?php endif; ?>
                            <p style="margin:8px 0 0;white-space:pre-wrap"><?= e($cm['content']) ?></p>
                        </td>
                        <td style="padding:12px;min-width:180px">
                            <?php if (!empty($cm['article_slug'])): ?>
                                <a href="<?= e(url('article.php?slug='.urlencode($cm['article_slug']))) ?>" target="_blank" rel="noopener noreferrer"><?= e($cm['article_title']) ?></a>
                            <?php else: ?>
                                <span>Artikel tidak tersedia</span>
                            <?php endif; ?>
                        </td>
                        <td style="padding:12px"><?= e($cm['username'] ?: 'Tamu/akun lama') ?></td>
                        <td style="padding:12px"><strong><?= e($cm['status']) ?></strong></td>
                        <td style="padding:12px;white-space:nowrap"><?= e(date('d M Y H:i', strtotime($cm['created_at']))) ?></td>
                        <td style="padding:12px;min-width:250px">
                            <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end">
                                <?php if ($cm['status'] !== 'approved'): ?>
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="_csrf" value="<?= e(csrf()) ?>">
                                    <input type="hidden" name="id" value="<?= (int)$cm['id'] ?>">
                                    <input type="hidden" name="action" value="approve">
                                    <button class="btn" type="submit">✓ Setujui</button>
                                </form>
                                <?php endif; ?>
                                <?php if ($cm['status'] !== 'rejected'): ?>
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="_csrf" value="<?= e(csrf()) ?>">
                                    <input type="hidden" name="id" value="<?= (int)$cm['id'] ?>">
                                    <input type="hidden" name="action" value="reject">
                                    <button class="btn" type="submit">✕ Tolak</button>
                                </form>
                                <?php endif; ?>
                                <form method="post" style="display:inline" onsubmit="return confirm('Hapus komentar ini secara permanen?')">
                                    <input type="hidden" name="_csrf" value="<?= e(csrf()) ?>">
                                    <input type="hidden" name="id" value="<?= (int)$cm['id'] ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <button class="btn" type="submit">🗑 Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
<?php require '_bottom.php'; ?>
