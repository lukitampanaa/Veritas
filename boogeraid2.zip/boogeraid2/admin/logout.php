<?php
require __DIR__.'/../app/bootstrap.php';
require_login(array('superadmin','admin'));
if($_SERVER['REQUEST_METHOD']!=='POST'){ http_response_code(405); header('Allow: POST'); exit('Method Not Allowed'); }
check_csrf();
$_SESSION=array();
if(ini_get('session.use_cookies')){ $params=session_get_cookie_params(); setcookie(session_name(),'',time()-42000,$params['path'],$params['domain'],$params['secure'],$params['httponly']); }
session_destroy();
header('Location: '.url('login.php'));
exit;
