<?php
require '_top.php';
require_login(array('superadmin','admin'));

/* V5.30 compatibility fallback: keep Gallery functional even when an older
 * bootstrap.php does not yet expose the gallery helper functions. Existing
 * helpers are never redeclared. */
if (!function_exists('gallery_type_label')) {
    function gallery_type_label($type) {
        $labels = array('image'=>'Foto','youtube'=>'YouTube','facebook_reel'=>'Facebook Reels','instagram_reel'=>'Instagram Reels','tiktok'=>'TikTok');
        return isset($labels[$type]) ? $labels[$type] : 'Media';
    }
}
if (!function_exists('gallery_drive_id')) {
    function gallery_drive_id($url) {
        $p = parse_url($url);
        if (!$p) return '';
        $path = isset($p['path']) ? $p['path'] : '';
        if (preg_match('~/file/d/([a-zA-Z0-9_-]+)~', $path, $m)) return $m[1];
        if (!empty($p['query'])) {
            parse_str($p['query'], $q);
            if (!empty($q['id'])) return preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$q['id']);
        }
        return '';
    }
}
if (!function_exists('gallery_normalize_url')) {
    function gallery_normalize_url($url, $type = 'image') {
        $url = trim((string)$url);
        if ($url === '') return '';
        /* Local files selected from Admin > Media Library are stored as
         * media/originals/... or media/thumbs/.... Keep them relative so
         * the public app can resolve them through app_file_url()/url(). */
        if ($type === 'image' && preg_match('~^(?:/?)(?:media|uploads)/[^\s?#]+\.(?:jpg|jpeg|png|gif|webp|avif)(?:[?#].*)?$~i', $url)) {
            return ltrim($url, '/');
        }
        if (!preg_match('~^https?://~i', $url)) return '';
        $p = parse_url($url);
        $host = strtolower(isset($p['host']) ? $p['host'] : '');
        $path = isset($p['path']) ? $p['path'] : '';
            if ($type === 'image') {
            /* Local files uploaded by Admin > Media Library. */
            if (!preg_match('~^https?://~i', $url) && preg_match('~^(?:/?media/)[^\s?#]+\.(?:jpg|jpeg|png|gif|webp|avif)(?:[?#].*)?$~i', $url)) {
                return ltrim($url, '/');
            }
            if ($host === 'drive.google.com' || $host === 'docs.google.com') {
                $id = gallery_drive_id($url);
                return $id ? 'https://drive.google.com/thumbnail?id=' . rawurlencode($id) . '&sz=w1600' : '';
            }
            $allowed = array('images.unsplash.com','drive.googleusercontent.com','lh3.googleusercontent.com','lh4.googleusercontent.com','lh5.googleusercontent.com','lh6.googleusercontent.com','googleusercontent.com');
            $isLikelyImage = (bool)preg_match('/\.(jpg|jpeg|png|gif|webp|avif)(?:$|[?#])/i', $url);
            $isAllowedHost = in_array($host, $allowed, true) || substr($host, -16) === '.googleusercontent.com';
            return ($isLikelyImage || $isAllowedHost) ? $url : '';
        }
        if ($type === 'youtube') {
            $id = '';
            if ($host === 'youtu.be') $id = trim($path, '/');
            elseif (strpos($host, 'youtube.com') !== false) {
                parse_str(isset($p['query']) ? $p['query'] : '', $q);
                if (!empty($q['v'])) $id = (string)$q['v'];
                if (!$id && preg_match('~/(?:shorts|embed)/([A-Za-z0-9_-]{6,})~', $path, $m)) $id = $m[1];
            }
            return preg_match('/^[A-Za-z0-9_-]{6,20}$/', $id) ? 'https://www.youtube.com/watch?v=' . $id : '';
        }
        if ($type === 'tiktok') {
            if (strpos($host, 'tiktok.com') === false) return '';
            if (preg_match('~/video/(\d+)~', $path, $m)) return 'https://www.tiktok.com/@embed/video/' . $m[1];
            if (preg_match('~/player/v1/(\d+)~', $path, $m)) return 'https://www.tiktok.com/player/v1/' . $m[1];
            return '';
        }
        if ($type === 'instagram_reel') {
            if (strpos($host, 'instagram.com') === false) return '';
            if (preg_match('~/(?:reel|reels|p)/([A-Za-z0-9_-]+)~', $path, $m)) return 'https://www.instagram.com/reel/' . $m[1] . '/';
            return '';
        }
        if ($type === 'facebook_reel') {
            if (strpos($host, 'facebook.com') === false && strpos($host, 'fb.watch') === false) return '';
            return $url;
        }
        return '';
    }
}
if (!function_exists('gallery_youtube_id')) {
    function gallery_youtube_id($url) {
        $p = parse_url($url); if (!$p) return '';
        $host = strtolower(isset($p['host']) ? $p['host'] : '');
        if ($host === 'youtu.be') return trim(isset($p['path']) ? $p['path'] : '', '/');
        parse_str(isset($p['query']) ? $p['query'] : '', $q);
        if (!empty($q['v'])) return (string)$q['v'];
        if (preg_match('~/(?:shorts|embed)/([A-Za-z0-9_-]{6,})~', isset($p['path']) ? $p['path'] : '', $m)) return $m[1];
        return '';
    }
}
if (!function_exists('gallery_tiktok_id')) {
    function gallery_tiktok_id($url) {
        if (preg_match('~/video/(\d+)~', $url, $m)) return $m[1];
        if (preg_match('~/player/v1/(\d+)~', $url, $m)) return $m[1];
        return '';
    }
}
if (!function_exists('gallery_render_embed')) {
    function gallery_render_embed($g, $admin = false) {
        $type = isset($g['media_type']) ? $g['media_type'] : 'image';
        $src = isset($g['media_url']) ? (string)$g['media_url'] : '';
        if ($type === 'image') return '<img loading="lazy" decoding="async" src="'.e($src).'" alt="'.e(isset($g['title']) ? $g['title'] : 'Foto').'">';
        if ($type === 'youtube') {
            $id = gallery_youtube_id($src); if (!$id) return '<div class="media-placeholder">URL YouTube tidak valid.</div>';
            return '<iframe loading="lazy" src="'.e('https://www.youtube.com/embed/'.rawurlencode($id).'?rel=0').'" title="'.e(isset($g['title']) ? $g['title'] : 'YouTube').'" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>';
        }
        if ($type === 'tiktok') {
            $id = gallery_tiktok_id($src); if (!$id) return '<div class="media-placeholder">URL TikTok tidak valid.</div>';
            return '<iframe class="portrait-embed" loading="lazy" src="'.e('https://www.tiktok.com/player/v1/'.rawurlencode($id).'?description=1&music_info=1').'" title="'.e(isset($g['title']) ? $g['title'] : 'TikTok').'" allow="fullscreen"></iframe>';
        }
        if ($type === 'instagram_reel') {
            $p = parse_url($src); $path = isset($p['path']) ? $p['path'] : '';
            if (!preg_match('~/reel/([A-Za-z0-9_-]+)~', $path, $m)) return '<div class="media-placeholder">URL Instagram Reel tidak valid.</div>';
            return '<iframe loading="lazy" src="'.e('https://www.instagram.com/reel/'.rawurlencode($m[1]).'/embed/').'" title="'.e(isset($g['title']) ? $g['title'] : 'Instagram Reel').'" allowtransparency="true" scrolling="no" allow="encrypted-media; fullscreen"></iframe>';
        }
        if ($type === 'facebook_reel') {
            return '<iframe loading="lazy" src="'.e('https://www.facebook.com/plugins/video.php?href='.rawurlencode($src).'&show_text=false&width=500').'" title="'.e(isset($g['title']) ? $g['title'] : 'Facebook Reel').'" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share" allowfullscreen></iframe>';
        }
        return '<div class="media-placeholder">Media tidak dapat disematkan.</div>';
    }
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        check_csrf();
        $action = isset($_POST['action']) ? $_POST['action'] : 'add';
        if ($action === 'create_playlist') {
            $ptitle = trim((string)($_POST['playlist_title'] ?? ''));
            $ptype = (string)($_POST['playlist_type'] ?? 'image');
            if ($ptitle === '' || !in_array($ptype, array('image','video'), true)) throw new RuntimeException('Nama playlist dan jenis galeri wajib diisi.');
            $base = slugify($ptitle); $slug = $base; $n = 2;
            while (true) { $chk=$pdo->prepare('SELECT id FROM gallery_playlists WHERE slug=? LIMIT 1'); $chk->execute(array($slug)); if (!$chk->fetchColumn()) break; $slug=$base.'-'.$n++; }
            $q=$pdo->prepare('INSERT INTO gallery_playlists(title,slug,media_type,is_active,created_at) VALUES(?,?,?,1,NOW())'); $q->execute(array($ptitle,$slug,$ptype));
            flash('Playlist galeri berhasil dibuat.'); redirect('admin/gallery.php?tab='.($ptype==='image'?'images':'videos'));
        }
        if ($action === 'set_playlist') {
            $id=(int)($_POST['id']??0); $playlistId=(int)($_POST['playlist_id']??0);
            $typeRow=$pdo->prepare('SELECT media_type FROM gallery_items WHERE id=? LIMIT 1'); $typeRow->execute(array($id)); $mediaType=$typeRow->fetchColumn();
            if (!$mediaType) throw new RuntimeException('Media galeri tidak ditemukan.');
            if ($playlistId>0) {
                $pq=$pdo->prepare('SELECT id FROM gallery_playlists WHERE id=? AND media_type=? AND is_active=1 LIMIT 1'); $pq->execute(array($playlistId,$mediaType==='image'?'image':'video'));
                if (!$pq->fetchColumn()) throw new RuntimeException('Playlist tidak sesuai dengan jenis galeri media.');
            }
            $q=$pdo->prepare('UPDATE gallery_items SET playlist_id=? WHERE id=?'); $q->execute(array($playlistId>0?$playlistId:null,$id));
            flash($playlistId>0?'Media berhasil dimasukkan ke playlist.':'Media dilepas dari playlist.');
            redirect('admin/gallery.php?tab='.($mediaType==='image'?'images':'videos'));
        }
        if ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $q = $pdo->prepare('DELETE FROM gallery_items WHERE id=?');
            $q->execute(array($id));
            flash('Item galeri berhasil dihapus.');
            redirect('admin/gallery.php?tab=images');
        }

        $title = trim((string)($_POST['title'] ?? ''));
        $description = trim((string)($_POST['description'] ?? ''));
        $type = (string)($_POST['media_type'] ?? 'image');
        $mediaUrl = trim((string)($_POST['media_url'] ?? ''));
        $thumbUrl = trim((string)($_POST['thumbnail_url'] ?? ''));
        $allowed = array('image','youtube','facebook_reel','instagram_reel','tiktok');
        if ($title === '' || $mediaUrl === '' || !in_array($type, $allowed, true)) {
            throw new RuntimeException('Judul, jenis media, dan link media wajib diisi.');
        }
        /* Google Drive folder links are valid as a media/source link, but they are
         * not themselves an image. When a thumbnail is supplied, use that image
         * as the gallery preview while preserving the original folder URL in
         * source_url so visitors can still open the Drive folder. */
        $thumbNormalized = '';
        if ($thumbUrl !== '') {
            $thumbNormalized = gallery_normalize_url($thumbUrl, 'image');
            if ($thumbNormalized === '') throw new RuntimeException('Link thumbnail gambar tidak valid.');
        }

        $isDriveFolder = false;
        $mp = parse_url($mediaUrl);
        if ($mp && strtolower(isset($mp['host']) ? $mp['host'] : '') === 'drive.google.com') {
            $mpath = isset($mp['path']) ? $mp['path'] : '';
            $isDriveFolder = (bool)preg_match('~/drive/folders/[A-Za-z0-9_-]+~', $mpath);
        }

        $normalized = gallery_normalize_url($mediaUrl, $type);
        if ($normalized === '' && $type === 'image' && $isDriveFolder && $thumbNormalized !== '') {
            $normalized = $thumbNormalized;
        }
        if ($normalized === '') {
            if ($type === 'image' && $isDriveFolder) {
                throw new RuntimeException('Link Google Drive yang digunakan adalah folder. Untuk folder, isi Link Thumbnail dengan link file gambar yang dapat diakses publik.');
            }
            throw new RuntimeException('Link media tidak valid atau domain belum didukung.');
        }
        $thumbUrl = $thumbNormalized;
        $playlistId = (int)($_POST['playlist_id'] ?? 0);
        if ($playlistId > 0) {
            $pq=$pdo->prepare('SELECT id FROM gallery_playlists WHERE id=? AND media_type=? AND is_active=1 LIMIT 1');
            $pq->execute(array($playlistId, $type==='image'?'image':'video'));
            if (!$pq->fetchColumn()) $playlistId=0;
        }
        $q = $pdo->prepare('INSERT INTO gallery_items(title,description,media_type,playlist_id,media_url,thumbnail_url,source_url,is_active,created_at) VALUES(?,?,?,?,?,?,?,1,NOW())');
        $q->execute(array($title,$description,$type,$playlistId ?: null,$normalized,$thumbUrl,$mediaUrl));
        flash('Media galeri berhasil ditambahkan.');
        redirect('admin/gallery.php?tab=' . ($type === 'image' ? 'images' : 'videos'));
    } catch (Throwable $e) {
        $msg = $e->getMessage();
    }
}

$tab = isset($_GET['tab']) && $_GET['tab'] === 'videos' ? 'videos' : 'images';
$rows = $pdo->query('SELECT * FROM gallery_items ORDER BY created_at DESC,id DESC')->fetchAll();
$rowsImages = array_values(array_filter($rows, function($r){ return ($r['media_type'] ?? 'image') === 'image'; }));
$rowsVideos = array_values(array_filter($rows, function($r){ return ($r['media_type'] ?? 'image') !== 'image'; }));
$libraryMedia = [];
try { $libraryMedia = $pdo->query('SELECT id,title,image,thumb,mime FROM media_library ORDER BY created_at DESC,id DESC LIMIT 100')->fetchAll(); } catch (Throwable $e) {}
$playlists=[]; try { $playlists=$pdo->query("SELECT id,title,media_type FROM gallery_playlists WHERE is_active=1 ORDER BY media_type,title,id")->fetchAll(); } catch(Throwable $e) {}
$imagePlaylists=array_values(array_filter($playlists,function($p){return ($p['media_type']??'image')==='image';}));
$videoPlaylists=array_values(array_filter($playlists,function($p){return ($p['media_type']??'video')==='video';}));
$legacy = $pdo->query('SELECT * FROM galleries ORDER BY created_at DESC,id DESC')->fetchAll();
$activeRows = $tab === 'videos' ? $rowsVideos : $rowsImages;
$playlistNames=[]; foreach($playlists as $pl){ $playlistNames[(int)$pl['id']]=$pl['title']; }
?>
<style>
.gallery-tabs{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 18px}.gallery-tabs a{display:inline-flex;align-items:center;gap:7px;padding:10px 15px;border:1px solid #dbe3ef;border-radius:999px;text-decoration:none;color:#334155;background:#fff;font-weight:700}.gallery-tabs a.active{background:#1e40af;color:#fff;border-color:#1e40af}.gallery-count{font-size:12px;opacity:.8}.gallery-section-title{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px}.gallery-section-title h2{margin:0}.gallery-empty-box{padding:24px;border:1px dashed #cbd5e1;border-radius:14px;color:#64748b;background:#f8fafc}.gallery-admin-note{margin:0 0 18px;padding:12px 14px;border-radius:12px;background:#eff6ff;border:1px solid #bfdbfe;color:#1e3a8a}.admin-media-grid{grid-template-columns:repeat(2,minmax(0,1fr))}@media(max-width:900px){.admin-media-grid{grid-template-columns:1fr}}
</style>
<div class="page-title"><h1>Galeri Media</h1><p class="muted">Kelola galeri gambar dan galeri video secara terpisah. Setelah menambahkan media, Anda tetap berada di halaman Galeri Media Admin.</p></div>
<?php if ($msg): ?><div class="alert"><?=e($msg)?></div><?php endif; ?>
<section class="panel playlist-manager" style="margin-bottom:18px">
<h2>Daftar Playlist</h2>
<p class="muted">Playlist menjadi sumber data untuk <b>Momen &amp; Kreativitas</b>. Playlist Gambar hanya berisi gambar; Playlist Video hanya berisi video.</p>
<form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end">
<input type="hidden" name="_csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="create_playlist">
<label style="min-width:260px">Nama playlist<input name="playlist_title" required placeholder="Contoh: Pentas Seni 2026"></label>
<label>Jenis<select name="playlist_type"><option value="image">🖼️ Galeri Gambar</option><option value="video">▶️ Galeri Video</option></select></label>
<button class="btn" type="submit">＋ Buat Playlist</button>
</form>
<?php if($playlists): ?><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><?php foreach($playlists as $pl): ?><span class="pill"><?=($pl['media_type']==='image'?'🖼️':'▶️')?> <?=e($pl['title'])?></span><?php endforeach; ?></div><?php endif; ?>
</section>
<div class="gallery-tabs">
<a href="<?=e(root_url('admin/gallery.php?tab=images'))?>" class="<?= $tab==='images'?'active':'' ?>">🖼️ Galeri Gambar <span class="gallery-count">(<?=count($rowsImages)?>)</span></a>
<a href="<?=e(root_url('admin/gallery.php?tab=videos'))?>" class="<?= $tab==='videos'?'active':'' ?>">▶️ Galeri Video <span class="gallery-count">(<?=count($rowsVideos)?>)</span></a>
</div>
<div class="gallery-admin-note"><b><?= $tab==='images'?'Galeri Gambar':'Galeri Video' ?></b> sedang dipilih. <?= $tab==='images'?'Pilih foto dari Media Library atau gunakan URL gambar publik.':'Tambahkan YouTube, Facebook Reels, Instagram Reels, atau TikTok. Thumbnail opsional dapat digunakan untuk pratinjau.' ?></div>
<div class="twocol gallery-admin-grid">
<section class="panel">
<h2>Tambah <?= $tab==='images'?'Gambar':'Video' ?></h2>
<form method="post" class="media-form">
<input type="hidden" name="_csrf" value="<?=e(csrf())?>">
<input type="hidden" name="action" value="add">
<label>Judul<input name="title" required placeholder="<?= $tab==='images'?'Contoh: Pentas Seni 2026':'Contoh: Video Pentas Seni 2026' ?>"></label>
<?php if ($tab === 'images'): ?>
<input type="hidden" name="media_type" value="image">
<?php if ($libraryMedia): ?>
<label>Ambil dari Media Library <small>(opsional)</small><select id="libraryMediaPicker">
<option value="">— Pilih gambar yang sudah di-upload —</option>
<?php foreach ($libraryMedia as $lm): ?>
<option value="<?=e((string)$lm['id'])?>" data-title="<?=e($lm['title'])?>" data-image="<?=e($lm['image'])?>" data-thumb="<?=e($lm['thumb'] ?: $lm['image'])?>"><?=e($lm['title'])?></option>
<?php endforeach; ?>
</select></label>
<?php endif; ?>
<label>Link Gambar<input name="media_url" id="mediaUrl" required placeholder="URL gambar atau file Media Library"></label>
<?php if($imagePlaylists): ?><label>Playlist Gambar <small>(opsional, dipakai Momen &amp; Kreativitas)</small><select name="playlist_id"><option value="0">— Tanpa playlist —</option><?php foreach($imagePlaylists as $pl): ?><option value="<?=e($pl['id'])?>"><?=e($pl['title'])?></option><?php endforeach; ?></select></label><?php endif; ?>
<?php else: ?>
<label>Jenis Video<select name="media_type" id="mediaType" required>
<option value="youtube">▶️ YouTube</option>
<option value="facebook_reel">📘 Facebook Reels</option>
<option value="instagram_reel">📸 Instagram Reels</option>
<option value="tiktok">🎵 TikTok</option>
</select></label>
<label>Link Video<input name="media_url" id="mediaUrl" required placeholder="https://..."></label>
<label>Link Thumbnail <small>(opsional)</small><input name="thumbnail_url" placeholder="URL gambar thumbnail"></label>
<?php if($videoPlaylists): ?><label>Playlist Video <small>(opsional, dipakai Momen &amp; Kreativitas)</small><select name="playlist_id"><option value="0">— Tanpa playlist —</option><?php foreach($videoPlaylists as $pl): ?><option value="<?=e($pl['id'])?>"><?=e($pl['title'])?></option><?php endforeach; ?></select></label><?php endif; ?>
<?php endif; ?>
<label>Deskripsi<textarea name="description" rows="4" placeholder="Deskripsi singkat media"></textarea></label>
<div class="media-help" id="mediaHelp">Untuk foto, gunakan URL gambar publik atau pilih dari Media Library.</div>
<button class="btn" type="submit">＋ Tambahkan ke Galeri <?= $tab==='images'?'Gambar':'Video' ?></button>
</form>
<?php if ($tab === 'images'): ?><div class="notice-box"><b>Media Library:</b> pilih gambar yang sudah di-upload. Setelah tombol ditekan, Anda tetap berada di <b>Galeri Media → Galeri Gambar</b>.</div><?php else: ?><div class="notice-box"><b>Galeri Video:</b> gunakan URL publik dari platform video. Setelah tombol ditekan, Anda tetap berada di <b>Galeri Media → Galeri Video</b>.</div><?php endif; ?>
</section>
<section class="panel">
<div class="gallery-section-title"><h2><?= $tab==='images'?'Galeri Gambar':'Galeri Video' ?></h2><span class="pill"><?=count($activeRows)?> item</span></div>
<div class="admin-media-grid">
<?php foreach ($activeRows as $r): ?>
<article class="admin-media-card">
<div class="admin-media-preview">
<?=gallery_render_embed($r, true)?>
</div>
<div class="pad"><span class="pill"><?=e(gallery_type_label($r['media_type']))?></span><h3><?=e($r['title'])?></h3><small><?=e($r['created_at'])?></small><?php if(!empty($r['playlist_id']) && isset($playlistNames[(int)$r['playlist_id']])): ?><div class="muted" style="margin-top:5px">Playlist: <b><?=e($playlistNames[(int)$r['playlist_id']])?></b></div><?php endif; ?>
<form method="post" style="margin-top:10px"><input type="hidden" name="_csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="set_playlist"><input type="hidden" name="id" value="<?=e($r['id'])?>"><label style="font-size:12px">Playlist<select name="playlist_id" onchange="this.form.submit()"><option value="0">— Tanpa playlist —</option><?php foreach(($r['media_type']==='image'?$imagePlaylists:$videoPlaylists) as $pl): ?><option value="<?=e($pl['id'])?>" <?=((int)($r['playlist_id']??0)===(int)$pl['id']?'selected':'')?>><?=e($pl['title'])?></option><?php endforeach; ?></select></label></form>
<form method="post" onsubmit="return confirm('Hapus media ini?')" class="delete-inline"><input type="hidden" name="_csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=e($r['id'])?>"><button class="btn danger" type="submit">Hapus</button></form></div>
</article>
<?php endforeach; ?>
<?php if (!$activeRows): ?><div class="gallery-empty-box">Belum ada <?= $tab==='images'?'gambar':'video' ?> di galeri ini.</div><?php endif; ?>
</div>
<?php if ($tab === 'images' && $legacy): ?><details class="legacy-gallery"><summary>Foto lama yang tersimpan di server (<?=count($legacy)?>)</summary><div class="gallerymini"><?php foreach ($legacy as $r): ?><figure><img loading="lazy" src="<?=e(url($r['image']))?>" alt="<?=e($r['title'])?>"><figcaption><?=e($r['title'])?></figcaption></figure><?php endforeach; ?></div></details><?php endif; ?>
</section>
</div>
<script>
(function(){
 const type=document.getElementById('mediaType'), url=document.getElementById('mediaUrl'), help=document.getElementById('mediaHelp');
 const picker=document.getElementById('libraryMediaPicker');
 if(picker){ picker.addEventListener('change',function(){
   const o=this.options[this.selectedIndex];
   if(!o.value) return;
   if(url) url.value=o.dataset.image||'';
   const thumb=document.querySelector('input[name=thumbnail_url]');
   if(thumb && o.dataset.thumb) thumb.value=o.dataset.thumb;
   const title=document.querySelector('input[name=title]');
   if(title && !title.value) title.value=o.dataset.title||'';
 }); }
 function update(){
  if(!type || !help) return;
  const t=type.value;
  const hints={youtube:'Tempel URL YouTube biasa, youtu.be, Shorts, atau embed.',facebook_reel:'Tempel URL Facebook Reels publik.',instagram_reel:'Tempel URL Instagram Reel publik.',tiktok:'Tempel URL TikTok publik.'};
  help.textContent=hints[t]||'Untuk foto, gunakan URL gambar publik atau pilih dari Media Library.';
 }
 if(type){type.addEventListener('change',update);update();}
})();
</script>
<?php require '_bottom.php'; ?>
