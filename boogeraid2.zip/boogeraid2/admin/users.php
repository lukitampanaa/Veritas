<?php
require '_top.php';
require_login(array('superadmin','admin'));

$me = auth();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = isset($_POST['action']) ? (string)$_POST['action'] : '';

    if ($action === 'approve' || $action === 'reject') {
        $id = (int)($_POST['id'] ?? 0);
        $targetQ = $pdo->prepare('SELECT id,username,role,status FROM users WHERE id=? LIMIT 1');
        $targetQ->execute(array($id));
        $target = $targetQ->fetch();
        if (!$target || !in_array($target['role'], array('member','contributor'), true)) {
            flash('Permintaan pendaftaran tidak ditemukan.');
        } elseif ($target['status'] !== 'pending') {
            flash('Permintaan pendaftaran tersebut sudah diproses.');
        } else {
            $newStatus = $action === 'approve' ? 'active' : 'rejected';
            $q = $pdo->prepare('UPDATE users SET status=? WHERE id=?');
            $q->execute(array($newStatus, $id));
            flash($action === 'approve' ? 'Pendaftaran disetujui.' : 'Pendaftaran ditolak.');
        }
        redirect('admin/users.php');
    }

    if ($action === 'create') {
        $name = trim((string)($_POST['name'] ?? ''));
        $username = trim((string)($_POST['username'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $role = (string)($_POST['role'] ?? 'member');

        if ($name === '' || $username === '' || $password === '') {
            flash('Nama, username, dan password wajib diisi.');
        } elseif (!in_array($role, array('member','contributor','admin','superadmin'), true)) {
            flash('Role pengguna tidak valid.');
        } elseif ($role === 'superadmin' && $me['role'] !== 'superadmin') {
            flash('Hanya Super Administrator yang dapat membuat Super Administrator.');
        } else {
            try {
                $q = $pdo->prepare('INSERT INTO users(name,username,email,phone,password_hash,role,status) VALUES(?,?,?,?,?,?,?)');
                $q->execute(array($name, $username, $email !== '' ? $email : null, $phone !== '' ? $phone : null, password_hash($password, PASSWORD_DEFAULT), $role, 'active'));
                flash('Pengguna berhasil ditambahkan.');
            } catch (PDOException $e) {
                flash($e->getCode() === '23000' ? 'Username sudah digunakan.' : 'Pengguna gagal ditambahkan.');
            }
        }
        redirect('admin/users.php');
    }

    if ($action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim((string)($_POST['name'] ?? ''));
        $username = trim((string)($_POST['username'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $role = (string)($_POST['role'] ?? 'member');
        $status = (string)($_POST['status'] ?? 'active');

        if ($id <= 0 || $name === '' || $username === '') {
            flash('Nama, username, dan data pengguna wajib valid.');
        } elseif (!in_array($role, array('member','contributor','admin','superadmin'), true) || !in_array($status, array('pending','active','inactive','rejected'), true)) {
            flash('Role atau status pengguna tidak valid.');
        } elseif ($role === 'superadmin' && $me['role'] !== 'superadmin') {
            flash('Hanya Super Administrator yang dapat menetapkan role Super Administrator.');
        } else {
            $targetQ = $pdo->prepare('SELECT * FROM users WHERE id=? LIMIT 1');
            $targetQ->execute(array($id));
            $target = $targetQ->fetch();
            if (!$target) {
                flash('Pengguna tidak ditemukan.');
            } elseif ($me['role'] !== 'superadmin' && $target['role'] === 'superadmin') {
                flash('Administrator tidak dapat mengubah Super Administrator.');
            } elseif ($id === (int)$me['id'] && $status !== 'active') {
                flash('Akun yang sedang digunakan tidak dapat dinonaktifkan.');
            } else {
                try {
                    if ($password !== '') {
                        $q = $pdo->prepare('UPDATE users SET name=?,username=?,email=?,phone=?,password_hash=?,role=?,status=? WHERE id=?');
                        $q->execute(array($name, $username, $email !== '' ? $email : null, $phone !== '' ? $phone : null, password_hash($password, PASSWORD_DEFAULT), $role, $status, $id));
                    } else {
                        $q = $pdo->prepare('UPDATE users SET name=?,username=?,email=?,phone=?,role=?,status=? WHERE id=?');
                        $q->execute(array($name, $username, $email !== '' ? $email : null, $phone !== '' ? $phone : null, $role, $status, $id));
                    }
                    flash('Data pengguna berhasil diperbarui.');
                } catch (PDOException $e) {
                    flash($e->getCode() === '23000' ? 'Username sudah digunakan oleh pengguna lain.' : 'Data pengguna gagal diperbarui.');
                }
            }
        }
        redirect('admin/users.php');
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            flash('Pengguna tidak valid.');
        } elseif ($id === (int)$me['id']) {
            flash('Akun yang sedang digunakan tidak dapat dihapus.');
        } else {
            $targetQ = $pdo->prepare('SELECT id,username,role FROM users WHERE id=? LIMIT 1');
            $targetQ->execute(array($id));
            $target = $targetQ->fetch();
            if (!$target) {
                flash('Pengguna tidak ditemukan.');
            } elseif ($target['role'] === 'superadmin' && $me['role'] !== 'superadmin') {
                flash('Administrator tidak dapat menghapus Super Administrator.');
            } else {
                if ($target['role'] === 'superadmin') {
                    $count = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='superadmin' AND status='active'")->fetchColumn();
                    if ($count <= 1) {
                        flash('Super Administrator aktif terakhir tidak dapat dihapus.');
                        redirect('admin/users.php');
                    }
                }
                $q = $pdo->prepare('DELETE FROM users WHERE id=?');
                $q->execute(array($id));
                flash('Pengguna berhasil dihapus.');
            }
        }
        redirect('admin/users.php');
    }
}

$rows = $pdo->query('SELECT id,name,username,email,phone,role,status,created_at FROM users ORDER BY created_at DESC')->fetchAll();
$roles = array('member','contributor','admin');
$roleLabels = array('member'=>'Anggota','contributor'=>'Penulis','admin'=>'Administrator','superadmin'=>'Super Administrator');
if ($me['role'] === 'superadmin') $roles[] = 'superadmin';
?>
<?php $pendingRows = $pdo->query("SELECT id,name,username,email,role,created_at FROM users WHERE status='pending' AND role IN ('member','contributor') ORDER BY created_at ASC")->fetchAll(); ?>
<?php if ($pendingRows): ?>
<section class="panel approval-panel"><h2>Persetujuan Pendaftaran</h2><p class="muted">Pilih <b>Setujui</b> untuk mengaktifkan akun atau <b>Tolak</b> untuk menolak pendaftaran.</p>
<?php foreach($pendingRows as $r): ?>
<div class="approval-row"><div><b><?=e($r['name'])?></b> · <?=e($r['username'])?> · <span class="pill"><?=e($roleLabels[$r['role']] ?? $r['role'])?></span><br><small><?=e($r['email'] ?? '')?> · <?=e($r['created_at'])?></small></div><div class="approval-actions">
<form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="approve"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn" type="submit">Setujui</button></form>
<form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="reject"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn danger" type="submit">Tolak</button></form>
</div></div>
<?php endforeach; ?></section>
<?php endif; ?>
<div class="twocol">
<section class="panel">
<h2>Tambah pengguna</h2>
<p class="muted">Nomor kontak bersifat opsional dan dapat digunakan untuk komunikasi redaksi.</p>
<form method="post">
<input type="hidden" name="_csrf" value="<?=e(csrf())?>">
<input type="hidden" name="action" value="create">
<input name="name" required placeholder="Nama">
<input name="username" required placeholder="Username">
<input name="email" type="email" placeholder="Email (opsional)">
<input name="phone" type="tel" inputmode="tel" placeholder="Nomor kontak (opsional)">
<input name="password" required minlength="10" type="password" placeholder="Password minimal 10 karakter">
<select name="role"><?php foreach($roles as $role):?><option value="<?=e($role)?>"><?=e($roleLabels[$role] ?? ucfirst($role))?></option><?php endforeach;?></select>
<button class="btn">Buat</button>
</form>
</section>

<section class="panel">
<h2>Daftar pengguna</h2>
<?php if (!$rows): ?><p class="muted">Belum ada pengguna.</p><?php endif; ?>
<?php foreach($rows as $r):
    $canManage = $me['role'] === 'superadmin' || $r['role'] !== 'superadmin';
?>
<div class="userrow userrow-editable">
<form method="post" class="user-edit-form">
<input type="hidden" name="_csrf" value="<?=e(csrf())?>">
<input type="hidden" name="action" value="update">
<input type="hidden" name="id" value="<?=$r['id']?>">
<div class="user-edit-grid">
<div><label>Nama</label><input name="name" value="<?=e($r['name'])?>" required></div>
<div><label>Username</label><input name="username" value="<?=e($r['username'])?>" required></div>
<div><label>Email</label><input name="email" type="email" value="<?=e($r['email'])?>" placeholder="Email opsional"></div>
<div><label>Nomor kontak</label><input name="phone" type="tel" inputmode="tel" value="<?=e($r['phone'])?>" placeholder="Nomor kontak opsional"></div>
<div><label>Password baru</label><input name="password" type="password" placeholder="Kosongkan jika tidak diubah"></div>
<div><label>Role</label><select name="role" <?=(!$canManage?'disabled':'')?> ><?php foreach($roles as $role):?><option value="<?=e($role)?>" <?=$role===$r['role']?'selected':''?>><?=e($roleLabels[$role] ?? ucfirst($role))?></option><?php endforeach;?></select></div>
<div><label>Status</label><select name="status" <?=(!$canManage?'disabled':'')?>><option value="pending" <?=$r['status']==='pending'?'selected':''?>>Menunggu Persetujuan</option><option value="active" <?=$r['status']==='active'?'selected':''?>>Aktif</option><option value="inactive" <?=$r['status']==='inactive'?'selected':''?>>Nonaktif</option><option value="rejected" <?=$r['status']==='rejected'?'selected':''?>>Ditolak</option></select></div>
</div>
<div class="user-meta"><b><?=e($r['name'])?></b> · <?=e($r['username'])?> · dibuat <?=e($r['created_at'])?></div>
<div class="user-actions">
<button type="submit" class="btn" <?=(!$canManage?'disabled':'')?>>Simpan Perubahan</button>
<?php if ((int)$r['id'] !== (int)$me['id'] && $canManage): ?>
<button type="submit" class="btn danger" name="action" value="delete" formnovalidate onclick="return confirm('Hapus pengguna <?=e(addslashes($r['username']))?>? Data pengguna akan dihapus dari sistem.');">Hapus</button>
<?php endif; ?>
</div>
</form>
</div>
<?php endforeach; ?>
</section>
</div>
<style>
.muted{color:#64748b;font-size:.9rem;margin-top:-8px}.userrow-editable{padding:18px 0}.user-edit-form{width:100%}.user-edit-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.user-edit-grid label{display:block;font-size:.78rem;color:#64748b;margin:0 0 4px}.user-edit-grid input,.user-edit-grid select{width:100%;box-sizing:border-box}.user-meta{font-size:.82rem;color:#64748b;margin:12px 0}.user-actions{display:flex;gap:8px;align-items:center}.btn.danger{background:#b91c1c}.btn:disabled{opacity:.5;cursor:not-allowed}@media(max-width:800px){.user-edit-grid{grid-template-columns:1fr}}
.approval-panel{margin-bottom:18px}.approval-row{display:flex;justify-content:space-between;gap:15px;padding:14px 0;border-top:1px solid #e2e8f0}.approval-actions{display:flex;gap:8px;align-items:center}.btn.danger{background:#b91c1c}@media(max-width:800px){.approval-row{flex-direction:column}.approval-actions{align-self:flex-start}}
</style>
<?php require '_bottom.php';
