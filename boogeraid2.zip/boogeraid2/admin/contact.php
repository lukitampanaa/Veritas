<?php require '_top.php';require_login(array('superadmin','admin'));
$defaults=[
 'contact_title'=>'Kontak Kami','contact_intro'=>'Hubungi tim redaksi untuk pertanyaan, saran, kerja sama, atau informasi lainnya.',
 'contact_address'=>'','contact_phone'=>'','contact_whatsapp'=>'','contact_email'=>'','contact_hours'=>'','contact_website'=>'',
 'contact_map_embed'=>'','contact_map_link'=>'','contact_notes'=>'','contact_team'=>'[]'
];
$val=function($k)use($defaults){return setting($k,$defaults[$k]??'');};
$decodeTeam=function($raw){$d=json_decode((string)$raw,true);if(!is_array($d))$d=[];$out=[];foreach(array_slice($d,0,12) as $m){if(!is_array($m))continue;$out[]=['active'=>($m['active']??1)?1:0,'name'=>trim((string)($m['name']??'')),'role'=>trim((string)($m['role']??'')),'photo'=>trim((string)($m['photo']??'')),'email'=>trim((string)($m['email']??'')),'phone'=>trim((string)($m['phone']??'')),'bio'=>trim((string)($m['bio']??''))];}return $out;};
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{check_csrf();$save=function($k,$v)use($pdo){$pdo->prepare('INSERT INTO settings(`key`,value) VALUES(?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)')->execute([$k,(string)$v]);};
  foreach(['contact_title','contact_intro','contact_address','contact_phone','contact_whatsapp','contact_email','contact_hours','contact_website','contact_map_embed','contact_map_link','contact_notes'] as $k){$save($k,trim((string)($_POST[$k]??'')));}
  $team=[];$names=$_POST['team_name']??[];$roles=$_POST['team_role']??[];$photos=$_POST['team_photo']??[];$emails=$_POST['team_email']??[];$phones=$_POST['team_phone']??[];$bios=$_POST['team_bio']??[];$actives=$_POST['team_active']??[];
  $n=max(count($names),count($roles),count($photos),count($emails),count($phones),count($bios));
  for($i=0;$i<$n&&$i<12;$i++){ $name=trim((string)($names[$i]??''));$role=trim((string)($roles[$i]??''));$photo=trim((string)($photos[$i]??''));$email=trim((string)($emails[$i]??''));$phone=trim((string)($phones[$i]??''));$bio=trim((string)($bios[$i]??''));$active=isset($actives[$i])&&in_array((string)$actives[$i],['1','on'],true)?1:0; if($name===''&&$role===''&&$photo===''&&$email===''&&$phone===''&&$bio==='')continue;$team[]=['active'=>$active,'name'=>$name,'role'=>$role,'photo'=>$photo,'email'=>$email,'phone'=>$phone,'bio'=>$bio];}
  $save('contact_team',json_encode($team,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));flash('Pengaturan halaman Kontak tersimpan.');header('Location: '.url('admin/contact.php'));exit;
 }catch(Throwable $e){flash('Gagal menyimpan Kontak: '.$e->getMessage());header('Location: '.url('admin/contact.php'));exit;}
}
$team=$decodeTeam($val('contact_team'));for($i=count($team);$i<6;$i++)$team[]=['active'=>1,'name'=>'','role'=>'','photo'=>'','email'=>'','phone'=>'','bio'=>''];
?><style>
.contact-admin-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.contact-admin-grid .full{grid-column:1/-1}.contact-team{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.team-card{border:1px solid #e5e7eb;border-radius:14px;padding:14px;background:#fff}.team-card h3{margin:0 0 10px}.team-card label{display:block;margin:8px 0}.team-card input,.team-card textarea,.contact-admin-grid input,.contact-admin-grid textarea{width:100%;box-sizing:border-box;padding:9px;border:1px solid #d7dce5;border-radius:8px}.team-card textarea,.contact-admin-grid textarea{min-height:80px}.checkline{display:flex!important;align-items:center;gap:8px}.checkline input{width:auto}.hint{font-size:12px;color:#64748b;margin-top:5px}.savebar{position:sticky;bottom:12px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:10px;text-align:right;box-shadow:0 8px 30px rgba(0,0,0,.08)}@media(max-width:800px){.contact-admin-grid,.contact-team{grid-template-columns:1fr}}
</style>
<h1>Kontak & Tim Redaksi</h1><p>Kelola halaman Kontak publik, daftar tim redaksi, alamat, jam layanan, dan peta Google Maps.</p>
<form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf())?>">
<section class="panel"><h2>Informasi Kontak</h2><div class="contact-admin-grid">
<label>Judul halaman<input name="contact_title" value="<?=e($val('contact_title'))?>"></label>
<label>Email<input type="email" name="contact_email" value="<?=e($val('contact_email'))?>"></label>
<label class="full">Deskripsi / pengantar<textarea name="contact_intro"><?=e($val('contact_intro'))?></textarea></label>
<label class="full">Alamat lengkap<textarea name="contact_address"><?=e($val('contact_address'))?></textarea></label>
<label>Telepon<input name="contact_phone" value="<?=e($val('contact_phone'))?>"></label>
<label>WhatsApp<input name="contact_whatsapp" value="<?=e($val('contact_whatsapp'))?>"></label>
<label>Jam layanan<input name="contact_hours" value="<?=e($val('contact_hours'))?>" placeholder="Senin–Jumat, 08.00–16.00"></label>
<label>Website<input type="url" name="contact_website" value="<?=e($val('contact_website'))?>"></label>
<label class="full">Google Maps Embed URL<textarea name="contact_map_embed" placeholder="Tempel URL src dari iframe Google Maps, bukan kode HTML lengkap."><?=e($val('contact_map_embed'))?></textarea><div class="hint">Di Google Maps pilih Bagikan → Sematkan peta → salin nilai URL pada atribut src.</div></label>
<label>Link Google Maps<input type="url" name="contact_map_link" value="<?=e($val('contact_map_link'))?>" placeholder="https://maps.google.com/..." /></label>
<label>Catatan tambahan<textarea name="contact_notes"><?=e($val('contact_notes'))?></textarea></label>
</div></section>
<section class="panel"><h2>Tim Redaksi</h2><p>Isi sampai 12 anggota tim. Nonaktifkan kartu yang tidak ingin ditampilkan.</p><div class="contact-team">
<?php foreach($team as $i=>$m): ?><div class="team-card"><h3>Tim #<?=$i+1?></h3><label class="checkline"><input type="checkbox" name="team_active[<?=$i?>]" value="1" <?=$m['active']?'checked':''?>> Tampilkan di halaman publik</label><label>Nama<input name="team_name[<?=$i?>]" value="<?=e($m['name'])?>"></label><label>Jabatan / Peran<input name="team_role[<?=$i?>]" value="<?=e($m['role'])?>" placeholder="Pemimpin Redaksi"></label><label>Foto URL<input name="team_photo[<?=$i?>]" value="<?=e($m['photo'])?>" placeholder="https://... atau path media"></label><label>Email<input type="email" name="team_email[<?=$i?>]" value="<?=e($m['email'])?>"></label><label>Telepon/WhatsApp<input name="team_phone[<?=$i?>]" value="<?=e($m['phone'])?>"></label><label>Bio singkat<textarea name="team_bio[<?=$i?>]"><?=e($m['bio'])?></textarea></label></div><?php endforeach; ?></div></section>
<div class="savebar"><button class="btn" type="submit">Simpan Pengaturan Kontak</button></div></form>
