<?php
require '_top.php';
require_login();

/* Delete article: Superadmin only, POST + CSRF. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_article'])) {
    if (!auth() || auth()['role'] !== 'superadmin') {
        http_response_code(403);
        exit('Forbidden');
    }
    check_csrf();
    $deleteId = (int)($_POST['delete_id'] ?? 0);
    if ($deleteId <= 0) {
        flash('ID artikel tidak valid.');
        redirect('admin/articles.php');
    }

    try {
        $q = $pdo->prepare('SELECT id,title,cover FROM articles WHERE id=? LIMIT 1');
        $q->execute([$deleteId]);
        $target = $q->fetch();
        if (!$target) {
            flash('Artikel tidak ditemukan.');
            redirect('admin/articles.php');
        }

        $pdo->beginTransaction();

        /* Optional legacy/non-FK favorites table: delete safely if present. */
        try {
            $hasFavorites = (bool)$pdo->query("SHOW TABLES LIKE 'article_favorites'")->fetchColumn();
            if ($hasFavorites) {
                $fq = $pdo->prepare('DELETE FROM article_favorites WHERE article_id=?');
                $fq->execute([$deleteId]);
            }
        } catch (Throwable $ignored) {}

        $dq = $pdo->prepare('DELETE FROM articles WHERE id=?');
        $dq->execute([$deleteId]);

        $pdo->prepare('INSERT INTO audit_logs(user_id,action,entity,entity_id,details) VALUES(?,?,?,?,?)')
            ->execute([auth()['id'], 'delete', 'article', $deleteId, 'Menghapus artikel: ' . $target['title']]);

        $pdo->commit();

        /* Remove local cover only when it is inside the application's public folder. */
        $cover = trim((string)($target['cover'] ?? ''));
        if ($cover !== '' && strpos($cover, '://') === false) {
            $cover = ltrim(str_replace('\\', '/', $cover), '/');
            if (strpos($cover, 'public/') === 0) $cover = substr($cover, 7);
            $candidate = realpath(__DIR__ . '/../public/' . $cover);
            $publicRoot = realpath(__DIR__ . '/../public');
            if ($candidate && $publicRoot && strpos($candidate, $publicRoot . DIRECTORY_SEPARATOR) === 0 && is_file($candidate)) {
                @unlink($candidate);
            }
        }

        flash('Artikel berhasil dihapus.');
        redirect('admin/articles.php');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('Artikel gagal dihapus: ' . $e->getMessage());
        redirect('admin/articles.php');
    }
}

$where='';
$params=[];
if(!is_admin()){$where='WHERE a.author_id=?';$params[] = auth()['id'];}
$q=$pdo->prepare("SELECT a.*,c.name category,u.name author FROM articles a LEFT JOIN categories c ON c.id=a.category_id LEFT JOIN users u ON u.id=a.author_id $where ORDER BY a.updated_at DESC");
$q->execute($params);
$rows=$q->fetchAll();
?>
<div class="titleline"><h1>Artikel</h1><a class="btn" href="article_edit.php">+ Artikel Baru</a></div>
<table>
<tr><th>Judul</th><th>Rubrik</th><th>Status</th><th>Views</th><th>Aksi</th></tr>
<?php foreach($rows as $r):?>
<tr>
<td><?=e($r['title'])?></td>
<td><?=e($r['category'])?></td>
<td><span class="status <?=e($r['status'])?>"><?=e($r['status'])?></span></td>
<td><?=$r['views']?></td>
<td class="article-actions">
<a href="article_edit.php?id=<?=$r['id']?>">Edit</a>
<?php if(is_admin()):?> · <a href="moderate.php?id=<?=$r['id']?>">Moderasi</a><?php endif;?>
<?php if(auth()['role'] === 'superadmin'):?>
 · <form method="post" class="inline-delete-form" onsubmit="return confirm('Hapus artikel ini secara permanen? Data artikel, komentar terkait, dan relasi artikel akan ikut terhapus.');">
<input type="hidden" name="_csrf" value="<?=csrf()?>">
<input type="hidden" name="delete_id" value="<?=$r['id']?>">
<button type="submit" name="delete_article" class="link-delete">Hapus</button>
</form>
<?php endif;?>
</td>
</tr>
<?php endforeach;?>
</table>
<style>
.article-actions{white-space:nowrap}
.inline-delete-form{display:inline;margin:0;padding:0}
.link-delete{border:0;background:none;padding:0;margin:0;font:inherit;text-decoration:underline;cursor:pointer;color:#b42318}
.link-delete:hover{opacity:.8}
</style>
<?php require '_bottom.php';
