# Majalah Sekolah Online — Production Hardened v16

Paket ini merupakan konsolidasi build hosting dari seluruh perbaikan fitur dan hardening yang telah dilakukan, termasuk patch login/CSRF terbaru.

## Struktur

- `public/` — halaman publik
- `admin/` — panel admin
- `app/bootstrap.php` — bootstrap, database, session, CSRF, helper keamanan
- `config/config.php` — konfigurasi database/aplikasi
- `database/schema.sql` — schema fresh install
- `database/schema_hosting.sql` — schema untuk database hosting yang sudah dibuat
- `database/create_admin.php` — pembuatan/reset Superadmin melalui CLI saja
- `create_admin.php` — launcher CLI dari root aplikasi
- `uploads/` — upload media dengan proteksi eksekusi script

## Instalasi hosting

1. Upload dan extract seluruh isi ZIP ke document root domain.
2. Edit `config/config.php` dan isi kredensial database hosting.
3. Untuk instalasi baru, import `database/schema_hosting.sql` melalui phpMyAdmin, atau buka website sekali agar bootstrap mencoba memasang schema secara otomatis ke database yang telah dipilih.
4. Pastikan PHP web yang digunakan hosting PHP 7.4+; PHP 8.1/8.2/8.3 lebih disarankan.
5. Aktifkan HTTPS.
6. Buat Superadmin dari Terminal/SSH, dari root aplikasi:
   `php create_admin.php`
   atau `php database/create_admin.php`
7. Jangan menjalankan script pembuatan Superadmin melalui browser. Script CLI menolak akses HTTP.
8. Hapus file diagnostik sementara jika pernah dibuat.

## Upgrade

Backup file dan database terlebih dahulu. Jangan mencampur file dari versi lama secara acak. Untuk database lama, bootstrap menyediakan beberapa migrasi kompatibilitas ringan; migration SQL di folder `database/` juga disediakan untuk upgrade terkontrol.

## Fitur yang dikonsolidasikan

- Login/logout Admin, Penulis, Anggota
- Pendaftaran Anggota/Penulis dengan persetujuan Admin
- Pembatasan role dan status akun
- Favorit/Artikel Disukai
- Rubrik dan tag aktif/nonaktif
- Menu navigasi aktif/nonaktif
- Galeri gambar dan video
- Media Library dan playlist berdasarkan jenis media
- Momen & Kreativitas berbasis playlist Galeri
- Kontak Kami, tim redaksi, alamat, Google Maps dan pengaturan footer
- Moderasi artikel/komentar
- Agenda, E-paper, RSS, sitemap dan analytics
- Hardening session, CSRF, upload, authentication throttling dan security headers

## Catatan keamanan

Paket ini telah melalui static application security review, PHP syntax lint, pemeriksaan konfigurasi/secret, pemeriksaan pola SQL berisiko, pemeriksaan upload dan struktur proteksi folder, serta verifikasi integritas ZIP. Pengujian jaringan/penetration test eksternal terhadap server hosting tidak dapat dilakukan dari paket ini dan harus dilakukan pada lingkungan produksi bila diperlukan.
##LUKI GANTENG BANGWET