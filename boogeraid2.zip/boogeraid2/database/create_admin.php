<?php
// Run from CLI only: php database/create_admin.php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/../app/bootstrap.php';
if (!$pdo instanceof PDO) exit("Database tidak tersedia.\n");
$name = trim((string)(readline('Nama admin: ') ?: 'Administrator'));
$username = trim((string)(readline('Username admin: ') ?: 'admin'));
$email = trim((string)(readline('Email admin (opsional): ') ?: ''));
if (!preg_match('/^[A-Za-z0-9._-]{4,40}$/', $username)) exit("Username tidak valid.\n");
if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) exit("Email tidak valid.\n");
$pass = readline('Password admin (min. 12 karakter): ');
if (!is_string($pass) || strlen($pass) < 12) exit("Password terlalu pendek.\n");
$hash=password_hash($pass,PASSWORD_DEFAULT);
$q=$pdo->prepare("INSERT INTO users(name,username,email,password_hash,role,status) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),email=VALUES(email),password_hash=VALUES(password_hash),role='superadmin',status='active'");
$q->execute([$name,$username,$email!==''?$email:null,$hash,'superadmin','active']);
echo "Superadmin siap. Simpan kredensial Anda secara aman.\n";
