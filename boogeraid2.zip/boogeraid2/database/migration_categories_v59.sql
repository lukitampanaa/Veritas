-- V5.9 Rubrik & Sub-rubrik migration
-- Jalankan pada database Majalah Sekolah Online yang sudah ada.
-- Idempotent: aman dijalankan kembali.

SET @db = DATABASE();
SET @has_parent = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA=@db AND TABLE_NAME='categories' AND COLUMN_NAME='parent_id'
);
SET @sql = IF(@has_parent=0,
  'ALTER TABLE categories ADD COLUMN parent_id INT UNSIGNED NULL AFTER id',
  'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @has_parent_index = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA=@db AND TABLE_NAME='categories' AND INDEX_NAME='idx_categories_parent'
);
SET @sql = IF(@has_parent_index=0,
  'ALTER TABLE categories ADD INDEX idx_categories_parent (parent_id)',
  'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @has_fk = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA=@db AND TABLE_NAME='categories' AND CONSTRAINT_NAME='fk_categories_parent'
);
SET @sql = IF(@has_fk=0,
  'ALTER TABLE categories ADD CONSTRAINT fk_categories_parent FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL ON UPDATE CASCADE',
  'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Existing categories remain main rubrics by default (parent_id = NULL).
