# Database Package

- `schema.sql` = **schema fresh-install terbaru Production v12**.
- `migration_production_v12.sql` = migrasi tambahan untuk instalasi lama.
- `create_admin.php` = pembuatan Superadmin via CLI tanpa password default.
- File repair/diagnostic yang pernah tersedia pada versi lama sengaja tidak disertakan pada paket produksi.

Backup database sebelum menjalankan migrasi pada instalasi lama.
