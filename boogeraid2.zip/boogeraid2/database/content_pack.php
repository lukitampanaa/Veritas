<?php
// Production V4/V5: starter content intentionally disabled.
// Add only original school reporting and student works from the admin panel.
return [];
