-- Visibility controls for Rubrik, Tag, and Menu Navigasi.
-- Safe for existing installations: all existing records remain active.
ALTER TABLE categories ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER sort_order;
ALTER TABLE tags ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER slug;
ALTER TABLE menus ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER sort_order;
