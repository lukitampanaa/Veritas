# Instalasi Database & Superadmin di Hosting / XAMPP

## 1. Pastikan berada di root aplikasi
Root aplikasi harus berisi folder `app`, `config`, `database`, `public`, dan file `create_admin.php`.

Cek dengan:

```bash
ls
```

## 2. Buat/isi database
Isi `config/config.php` dengan kredensial database hosting.

## 3. Install schema
Buka website sekali. Jika `settings` belum ada, aplikasi akan mencoba memasang `database/schema_hosting.sql` ke database yang sudah dikonfigurasi.
Jika auto-install diblokir hosting, import `database/schema_hosting.sql` melalui phpMyAdmin.

## 4. Buat Superadmin
Setelah berada di root aplikasi, jalankan salah satu:

```bash
php create_admin.php
```

atau:

```bash
php database/create_admin.php
```

Jika `php` tersedia tetapi perintah di atas menghasilkan `Could not open input file`, berarti Anda berada di folder yang salah atau file aplikasi belum di-upload/extract dengan benar. Gunakan:

```bash
pwd
ls
find . -maxdepth 2 -type f -name 'create_admin.php'
```

Jangan menggunakan `php82`/`php81` kecuali binary tersebut memang tersedia. Jika `php --version` berhasil, gunakan `php`.

## 5. Keamanan
`create_admin.php` hanya dapat dijalankan melalui CLI dan menolak akses HTTP. Jangan membuat salinan script reset admin yang dapat diakses browser.
