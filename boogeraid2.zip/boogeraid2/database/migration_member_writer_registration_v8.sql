-- V5.8 Member / Writer registration approval
ALTER TABLE users MODIFY status ENUM('pending','active','inactive','rejected') NOT NULL DEFAULT 'pending';
-- Existing staff accounts must remain active.
UPDATE users SET status='active' WHERE role IN ('superadmin','admin') AND status IN ('pending','inactive','rejected');
