-- Production v12 upgrade for existing installations.
-- Run once as a privileged database user, or let app/bootstrap.php perform compatible lazy migrations.
USE majalah_sekolah;

ALTER TABLE users MODIFY status ENUM('pending','active','inactive','rejected') NOT NULL DEFAULT 'pending';
ALTER TABLE users ADD UNIQUE KEY uq_users_email(email);

CREATE TABLE IF NOT EXISTS article_favorites (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,article_id BIGINT UNSIGNED NOT NULL,user_id INT UNSIGNED NOT NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uq_article_user(article_id,user_id),INDEX idx_fav_user_created(user_id,created_at),FOREIGN KEY(article_id) REFERENCES articles(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS auth_login_attempts (attempt_key CHAR(64) NOT NULL PRIMARY KEY,attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,window_started DATETIME NOT NULL,blocked_until DATETIME NULL,updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS gallery_playlists (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,title VARCHAR(180) NOT NULL,slug VARCHAR(200) NOT NULL UNIQUE,media_type ENUM('image','video') NOT NULL DEFAULT 'image',is_active TINYINT(1) NOT NULL DEFAULT 1,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX idx_playlist_type_active(media_type,is_active)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE gallery_items ADD COLUMN playlist_id BIGINT UNSIGNED NULL AFTER media_type;
ALTER TABLE gallery_items ADD INDEX idx_gallery_playlist(playlist_id,is_active,created_at);
