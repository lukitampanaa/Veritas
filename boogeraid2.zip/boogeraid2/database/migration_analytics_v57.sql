-- Safe migration for an existing V5.6 database. Do NOT re-import the full schema.sql.
CREATE TABLE IF NOT EXISTS analytics_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 event_time DATETIME NOT NULL,
 metric_date DATE NOT NULL,
 visitor_key CHAR(64) NOT NULL,
 path VARCHAR(500) NOT NULL,
 page_title VARCHAR(255) NULL,
 referrer VARCHAR(255) NULL,
 country_code CHAR(2) NOT NULL DEFAULT 'XX',
 country_name VARCHAR(120) NOT NULL DEFAULT 'Tidak diketahui',
 device VARCHAR(30) NOT NULL DEFAULT 'Desktop',
 browser VARCHAR(60) NOT NULL DEFAULT 'Lainnya',
 os VARCHAR(60) NOT NULL DEFAULT 'Lainnya',
 INDEX(event_time), INDEX(metric_date), INDEX(visitor_key), INDEX(country_code), INDEX(path(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS analytics_visitors_daily (
 metric_date DATE NOT NULL,
 visitor_key CHAR(64) NOT NULL,
 country_code CHAR(2) NOT NULL DEFAULT 'XX',
 PRIMARY KEY(metric_date,visitor_key),
 INDEX(country_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
