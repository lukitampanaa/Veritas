# Security Audit — Production Hardened v16

Tanggal build: 2026-09-28

## Scope

Audit ini mencakup source code dan database package pada build yang dikirim dalam ZIP. Tidak mencakup penetration test jaringan eksternal terhadap hosting produksi.

## Checks

- PHP syntax lint: PASS — 48 PHP files, 0 syntax errors.
- Dangerous PHP function scan (`eval`, `assert`, `system`, `shell_exec`, `passthru`, `proc_open`, `popen`): no matches found in PHP application files.
- Password handling: `password_hash()` / `password_verify()` used; no default Superadmin password is created.
- Authentication: session regeneration after successful login; account status checked; login throttling stored in `auth_login_attempts`.
- CSRF: random server-side token, session validation, independent HttpOnly/SameSite cookie fallback, `hash_equals()`, and token initialization before template output.
- Session: strict cookies, no trans-SID, HttpOnly, SameSite=Lax, Secure on HTTPS, cache disabled for session-bearing pages.
- HTTP hardening: `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`, and HSTS when HTTPS is active.
- Uploads: MIME/signature checks and generated filenames; upload directories contain rules denying PHP/script execution.
- Database access: PDO prepared statements with emulated prepares disabled.
- Source/config exposure: Apache rules deny sensitive source/config/database file types; directory listing disabled.
- Database package: `schema_hosting.sql` contains no `CREATE DATABASE` and no `USE` statement, so it can be imported into a hosting database selected by cPanel/phpMyAdmin.
- Database package contains 22 `CREATE TABLE IF NOT EXISTS` statements and default settings/categories/menu data.
- ZIP integrity: verified after creation.

## Login/CSRF incident fix

The final build includes the latest login CSRF patch. CSRF token/cookie initialization is performed from bootstrap before HTML templates emit output, and `public/login.php` captures the token before rendering the form.

The hosting investigation also confirmed that the user's PHP session itself was persistent: the same `PHPSESSID` was observed across refreshes. Therefore the final patch does not rely on changing hosting `session.save_path` or weakening CSRF validation.

## Limitations

A source-level audit cannot guarantee absence of all vulnerabilities. No live external network scan, WAF test, TLS scan, or authenticated penetration test against the production domain is represented by this package. Those tests require authorization and access to the actual hosting environment.
