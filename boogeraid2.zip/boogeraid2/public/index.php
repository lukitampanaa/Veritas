<?php
require __DIR__.'/../app/bootstrap.php';

$seoTitle=setting('site_name');
$seoDesc=setting('tagline');

$featured=$pdo->query("SELECT a.*,c.name category,u.name author FROM articles a LEFT JOIN categories c ON c.id=a.category_id LEFT JOIN users u ON u.id=a.author_id WHERE a.status='published' AND (c.id IS NULL OR c.is_active=1) ORDER BY a.is_featured DESC,a.published_at DESC LIMIT 1")->fetch();

$latest=$pdo->query("SELECT a.*,c.name category,u.name author FROM articles a LEFT JOIN categories c ON c.id=a.category_id LEFT JOIN users u ON u.id=a.author_id WHERE a.status='published' AND (c.id IS NULL OR c.is_active=1) ORDER BY a.published_at DESC LIMIT 10")->fetchAll();

$sections=array(
    'dunia-remaja'=>'Dunia Remaja',
    'info-pelajar'=>'Info Pelajar',
    'cerita'=>'Cerita',
    'sains-teknologi'=>'Sains & Teknologi'
);

$popular=array();
try {
    $popular=$pdo->query("SELECT a.*,c.name category FROM articles a LEFT JOIN categories c ON c.id=a.category_id WHERE a.status='published' AND (c.id IS NULL OR c.is_active=1) ORDER BY a.views DESC,a.published_at DESC LIMIT 5")->fetchAll();
} catch(Throwable $e) {}

$stats=array('articles'=>0,'views'=>0,'authors'=>0,'categories'=>0);
try {$stats['articles']=(int)$pdo->query("SELECT COUNT(*) FROM articles WHERE status='published'")->fetchColumn();} catch(Throwable $e) {}
try {$stats['views']=(int)$pdo->query("SELECT COALESCE(SUM(views),0) FROM articles WHERE status='published'")->fetchColumn();} catch(Throwable $e) {}
try {$stats['authors']=(int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();} catch(Throwable $e) {}
try {$stats['categories']=(int)$pdo->query("SELECT COUNT(*) FROM categories WHERE is_active=1")->fetchColumn();} catch(Throwable $e) {}

$rubrics=array();
try {$rubrics=$pdo->query("SELECT id,name,slug FROM categories WHERE is_active=1 ORDER BY sort_order ASC,id ASC LIMIT 4")->fetchAll();} catch(Throwable $e) {}
if(!$rubrics){
    foreach($sections as $slug=>$label){$rubrics[]=array('id'=>0,'name'=>$label,'slug'=>$slug);}
}


// Momen & Kreativitas — presentation-only homepage settings.
$creativeEnabled=setting('home_creative_enabled','1')==='1';
$creativeTitle=trim(setting('home_creative_title','MOMEN & KREATIVITAS'));
$creativeSubtitle=trim(setting('home_creative_subtitle','Kumpulan momen, album kegiatan, dan karya video warga sekolah.'));
$creativeBgStart=trim(setting('home_creative_bg_start','#8fd3ff'));
$creativeBgEnd=trim(setting('home_creative_bg_end','#fff09a'));
$quoteEnabled=setting('home_quote_enabled','1')==='1';
$quoteText=trim(setting('home_quote_text','Jangan biarkan hari kemarin merampas terlalu banyak hari ini.'));
$quoteAuthor=trim(setting('home_quote_author','WILL ROGERS'));
$creativeAlbums=[];
$creativeVideos=[];
$creativePlaylistMode=false;
try {
  if((bool)$pdo->query("SHOW TABLES LIKE 'gallery_playlists'")->fetchColumn()){
    for($i=0;$i<4;$i++){
      $pid=(int)setting('home_creative_image_playlist_'.$i,'0'); if($pid<=0) continue;
      $q=$pdo->prepare("SELECT p.id,p.title,(SELECT COALESCE(NULLIF(g.thumbnail_url,''),g.media_url) FROM gallery_items g WHERE g.playlist_id=p.id AND g.is_active=1 AND g.media_type='image' ORDER BY g.created_at DESC,g.id DESC LIMIT 1) item_image FROM gallery_playlists p WHERE p.id=? AND p.is_active=1 AND p.media_type='image' LIMIT 1"); $q->execute(array($pid)); $pl=$q->fetch();
      if($pl){ $img=trim((string)($pl['item_image']??'')); $creativeAlbums[]=array('label'=>'MOMEN','title'=>trim((string)$pl['title'])?:'Momen & Kreativitas','image'=>$img!==''?media_url($img):'','link'=>url('gallery.php?playlist='.(int)$pl['id'])); $creativePlaylistMode=true; }
    }
    for($i=0;$i<2;$i++){
      $pid=(int)setting('home_creative_video_playlist_'.$i,'0'); if($pid<=0) continue;
      $q=$pdo->prepare("SELECT p.id,p.title,(SELECT g.media_url FROM gallery_items g WHERE g.playlist_id=p.id AND g.is_active=1 AND g.media_type IN ('youtube','facebook_reel','instagram_reel','tiktok') ORDER BY g.created_at DESC,g.id DESC LIMIT 1) item_url,(SELECT g.thumbnail_url FROM gallery_items g WHERE g.playlist_id=p.id AND g.is_active=1 AND g.media_type IN ('youtube','facebook_reel','instagram_reel','tiktok') ORDER BY g.created_at DESC,g.id DESC LIMIT 1) item_thumb FROM gallery_playlists p WHERE p.id=? AND p.is_active=1 AND p.media_type='video' LIMIT 1"); $q->execute(array($pid)); $pl=$q->fetch();
      if($pl){ $thumb=trim((string)($pl['item_thumb']??'')); $creativeVideos[]=array('title'=>trim((string)$pl['title'])?:'Video Galeri','thumbnail'=>$thumb!==''?media_url($thumb):'','link'=>url('gallery.php?playlist='.(int)$pl['id'])); $creativePlaylistMode=true; }
    }
  }
} catch(Throwable $e) {}
if(!$creativePlaylistMode){
  for($i=0;$i<4;$i++) $creativeAlbums[]=array('label'=>trim(setting('home_creative_album_'.$i.'_label','ALBUM')),'title'=>trim(setting('home_creative_album_'.$i.'_title','')),'image'=>trim(setting('home_creative_album_'.$i.'_image','')),'link'=>trim(setting('home_creative_album_'.$i.'_link','')));
  for($i=0;$i<2;$i++) $creativeVideos[]=array('title'=>trim(setting('home_creative_video_'.$i.'_title','')),'thumbnail'=>trim(setting('home_creative_video_'.$i.'_thumbnail','')),'link'=>trim(setting('home_creative_video_'.$i.'_link','')));
}
$creativeHasContent=false; foreach($creativeAlbums as $ca){if($ca['title']!==''||$ca['image']!==''){$creativeHasContent=true;break;}} if(!$creativeHasContent){foreach($creativeVideos as $cv){if($cv['title']!==''||$cv['link']!==''){$creativeHasContent=true;break;}}}

$schema=array(
    '@context'=>'https://schema.org',
    '@type'=>'NewsMediaOrganization',
    'name'=>setting('site_name'),
    'description'=>setting('tagline')
);
require 'partials/head.php';
?>
<link rel="stylesheet" href="<?=e(url('assets/css/home-v6.css'))?>">
<link rel="stylesheet" href="<?=e(url('assets/css/running-ticker-v2.css'))?>">
<link rel="stylesheet" href="<?=e(url('assets/css/news-slider-v1.css'))?>">
<link rel="stylesheet" href="<?=e(url('assets/css/home-creative-v1.css'))?>">
<?php $tickerEnabled=setting('header_ticker_enabled','1')==='1'; $tickerLabel=trim(setting('header_ticker_label','TERKINI')); $tickerSpeed=max(10,min(120,(int)setting('header_ticker_speed','34'))); $tickerBg=setting('header_ticker_bg','#0b132b'); $tickerLabelBg=setting('header_ticker_label_bg','#f2c500'); $tickerText=setting('header_ticker_text','#ffffff'); $tickerHeight=max(32,min(70,(int)setting('header_ticker_height','46'))); $tickerDirection=setting('header_ticker_direction','left')==='right'?'right':'left'; $tickerPause=setting('header_ticker_pause','1')==='1'; $newsSliderEnabled=setting('home_news_slider_enabled','1')==='1'; $newsSliderAutoplay=setting('home_news_slider_autoplay','1')==='1'; $newsSliderInterval=max(2,min(15,(int)setting('home_news_slider_interval','5'))); $newsSliderCount=max(3,min(10,(int)setting('home_news_slider_count','6'))); $newsSliderTransition=setting('home_news_slider_transition','slide')==='fade'?'fade':'slide'; $newsSliderDuration=max(300,min(1500,(int)setting('home_news_slider_transition_duration','700'))); $newsSliderEasing=setting('home_news_slider_transition_easing','smooth'); $newsSliderThumbs=setting('home_news_slider_thumbnails','1')==='1'; $newsSliderExcerpt=setting('home_news_slider_show_excerpt','1')==='1'; $newsSliderDate=setting('home_news_slider_show_date','1')==='1'; $newsSlides=array_slice($latest,0,$newsSliderCount); ?>

<div class="mag-home-v6">
  <?php if($latest && $tickerEnabled): ?>
  <section class="mag-ticker <?=($tickerPause?'ticker-pause-enabled':'')?>" aria-label="<?=e($tickerLabel?:'Artikel terkini')?>" style="--ticker-bg:<?=e($tickerBg)?>;--ticker-label-bg:<?=e($tickerLabelBg)?>;--ticker-text:<?=e($tickerText)?>;--ticker-height:<?=$tickerHeight?>px;--ticker-duration:<?=$tickerSpeed?>s;--ticker-direction:<?=e($tickerDirection)?>;">
    <div class="mag-ticker-label"><?=e($tickerLabel?:'TERKINI')?></div>
    <div class="mag-ticker-track">
      <div class="mag-ticker-marquee">
        <div class="mag-ticker-group">
          <?php foreach($latest as $a): ?>
            <a href="article.php?slug=<?=e($a['slug'])?>"><?=e($a['title'])?></a>
          <?php endforeach; ?>
        </div>
        <div class="mag-ticker-group" aria-hidden="true">
          <?php foreach($latest as $a): ?>
            <a href="article.php?slug=<?=e($a['slug'])?>" tabindex="-1"><?=e($a['title'])?></a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <div class="mag-ticker-date"><?=date('D, d M Y · H:i')?></div>
  </section>
  <?php endif; ?>

  <?php if($featured): ?>
  <section class="mag-hero">
    <div class="mag-hero-main">
      <a class="mag-hero-image" href="article.php?slug=<?=e($featured['slug'])?>" aria-label="<?=e($featured['title'])?>">
        <?php if(!empty($featured['cover'])): ?><img src="<?=e(media_url($featured['cover']))?>" alt="<?=e($featured['title'])?>" loading="eager" decoding="async"><?php else: ?><span class="mag-image-placeholder">MAJALAH</span><?php endif; ?>
        <span class="mag-badge">LIPUTAN UTAMA</span>
      </a>
      <div class="mag-hero-copy">
        <span class="mag-pill"><?=e($featured['category']?:'Warta Sekolah')?></span>
        <h1><a href="article.php?slug=<?=e($featured['slug'])?>"><?=e($featured['title'])?></a></h1>
        <p><?=e(excerpt($featured['excerpt']?:$featured['content'],220))?></p>
        <a class="mag-button" href="article.php?slug=<?=e($featured['slug'])?>">Baca selengkapnya <span>→</span></a>
      </div>
    </div>
    <aside class="mag-hero-side">
      <div class="mag-side-title">ARTIKEL PILIHAN</div>
      <?php $heroSide=array_slice($latest,0,5); foreach($heroSide as $i=>$a): ?>
      <a class="mag-side-item" href="article.php?slug=<?=e($a['slug'])?>">
        <?php if(!empty($a['cover'])): ?><img src="<?=e(media_url($a['cover']))?>" alt="" loading="lazy" decoding="async"><?php else: ?><span class="mag-mini-placeholder"></span><?php endif; ?>
        <span><b><?=e($a['title'])?></b><small><?=e($a['category']?:'Warta Sekolah')?></small></span>
      </a>
      <?php endforeach; ?>
    </aside>
  </section>
  <?php endif; ?>

  <section class="mag-section mag-news-slider-section">
    <div class="mag-section-heading">
      <div><span class="mag-kicker">WARTA & KABAR TERKINI</span><h2>Berita terbaru dari warga sekolah</h2></div>
      <a href="articles.php">Lihat semua →</a>
    </div>
    <?php if($newsSliderEnabled && $newsSlides): ?>
    <div class="mag-news-slider" data-autoplay="<?=($newsSliderAutoplay?'1':'0')?>" data-interval="<?=$newsSliderInterval*1000?>" data-transition="<?=e($newsSliderTransition)?>" data-transition-duration="<?=$newsSliderDuration?>" data-transition-easing="<?=e($newsSliderEasing)?>">
      <div class="mag-news-slides" aria-live="polite">
        <?php foreach($newsSlides as $i=>$a): ?>
        <article class="mag-news-slide <?=($i===0?'is-active':'')?>" data-slide="<?=$i?>">
          <a class="mag-news-slide-media" href="article.php?slug=<?=e($a['slug'])?>" aria-label="<?=e($a['title'])?>">
            <?php if(!empty($a['cover'])): ?><img src="<?=e(media_url($a['cover']))?>" alt="<?=e($a['title'])?>" loading="<?=($i===0?'eager':'lazy')?>" decoding="async"><?php else: ?><span class="mag-image-placeholder">MAJALAH</span><?php endif; ?>
            <span class="mag-badge"><?=e($a['category']?:'WARTA SEKOLAH')?></span>
          </a>
          <div class="mag-news-slide-copy">
            <span class="mag-pill"><?=e($a['category']?:'WARTA SEKOLAH')?></span>
            <h3><a href="article.php?slug=<?=e($a['slug'])?>"><?=e($a['title'])?></a></h3>
            <?php if($newsSliderExcerpt): ?><p><?=e(excerpt($a['excerpt']?:$a['content'],190))?></p><?php endif; ?>
            <?php if($newsSliderDate): ?><small><?=date('d M Y',strtotime($a['published_at']?:$a['created_at']))?> · <?=e($a['author']?:'Redaksi')?></small><?php endif; ?>
            <a class="mag-outline-button" href="article.php?slug=<?=e($a['slug'])?>">Baca selengkapnya <span>→</span></a>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
      <div class="mag-news-slider-controls">
        <button type="button" class="mag-news-arrow mag-news-prev" aria-label="Artikel sebelumnya">‹</button>
        <div class="mag-news-dots" role="tablist" aria-label="Navigasi slide">
          <?php foreach($newsSlides as $i=>$a): ?><button type="button" class="mag-news-dot <?=($i===0?'is-active':'')?>" data-go="<?=$i?>" role="tab" aria-label="Slide <?=($i+1)?>"></button><?php endforeach; ?>
        </div>
        <button type="button" class="mag-news-arrow mag-news-next" aria-label="Artikel berikutnya">›</button>
      </div>
      <?php if($newsSliderThumbs): ?>
      <div class="mag-news-thumbs" role="tablist" aria-label="Thumbnail artikel">
        <?php foreach($newsSlides as $i=>$a): ?>
        <button type="button" class="mag-news-thumb <?=($i===0?'is-active':'')?>" data-go="<?=$i?>" role="tab" aria-label="Buka <?=e($a['title'])?>">
          <span class="mag-news-thumb-image"><?php if(!empty($a['cover'])): ?><img src="<?=e(media_url($a['cover']))?>" alt="" loading="lazy" decoding="async"><?php else: ?><span> M </span><?php endif; ?></span>
          <span class="mag-news-thumb-text"><small><?=e($a['category']?:'Warta Sekolah')?></small><b><?=e($a['title'])?></b></span>
        </button>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
    <?php elseif($latest): ?>
      <div class="mag-news-slider-disabled"><a class="mag-outline-button" href="articles.php">Lihat artikel terbaru →</a></div>
    <?php endif; ?>
  </section>

  <section class="mag-stats" aria-label="Statistik publikasi">
    <div><strong><?=number_format($stats['articles'],0,',','.')?></strong><span>ARTIKEL TERBIT</span></div>
    <div><strong><?=number_format($stats['views'],0,',','.')?></strong><span>TOTAL PEMBACA</span></div>
    <div><strong><?=number_format($stats['authors'],0,',','.')?></strong><span>AKUN TERDAFTAR</span></div>
    <div><strong><?=number_format($stats['categories'],0,',','.')?></strong><span>RUBRIK AKTIF</span></div>
  </section>

  <section class="mag-section mag-rubric-section">
    <div class="mag-section-heading"><div><span class="mag-kicker">JELAJAH RUBRIK</span><h2>Temukan cerita sesuai minatmu</h2></div></div>
    <div class="mag-rubric-tabs">
      <?php foreach($rubrics as $i=>$r): ?>
        <a class="mag-rubric-tab <?=($i===0?'active':'')?>" href="articles.php?category=<?=e($r['slug'])?>"><span><?=($i===0?'✦':($i===1?'✧':($i===2?'◌':'◈')))?></span><?=e($r['name'])?></a>
      <?php endforeach; ?>
    </div>
    <div class="mag-rubric-feature">
      <div class="mag-rubric-copy"><span class="mag-pill">PILIHAN RUBRIK</span><h3><?=e($rubrics[0]['name'])?></h3><p>Jelajahi artikel, karya, dan informasi terbaru yang telah dipublikasikan melalui rubrik ini.</p><a class="mag-button" href="articles.php?category=<?=e($rubrics[0]['slug'])?>">Lihat semua berita →</a></div>
      <div class="mag-rubric-mini">
        <?php $rslug=$rubrics[0]['slug']; $rq=$pdo->prepare("SELECT a.*,c.name category FROM articles a LEFT JOIN categories c ON c.id=a.category_id WHERE a.status='published' AND (c.id IS NULL OR c.is_active=1) AND c.slug=? ORDER BY a.published_at DESC LIMIT 3"); $rq->execute(array($rslug)); $rr=$rq->fetchAll(); foreach($rr as $a): ?>
          <a href="article.php?slug=<?=e($a['slug'])?>"><b><?=e($a['title'])?></b><small><?=date('d M Y',strtotime($a['published_at']?:$a['created_at']))?></small></a>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <?php
  // The Admin toggle is authoritative: the section must remain visible when enabled.
  // Content fallbacks above already populate albums/videos from published content/gallery
  // when manual Momen & Kreativitas entries are empty.
  if($creativeEnabled):
?>
  <section class="creative-home-section" style="--creative-bg-start:<?=e($creativeBgStart)?>;--creative-bg-end:<?=e($creativeBgEnd)?>" aria-label="<?=e($creativeTitle?:'Momen & Kreativitas')?>">
    <div class="creative-home-inner">
      <div class="creative-heading">
        <div><span class="creative-accent"></span><div><h2><?=e($creativeTitle?:'MOMEN & KREATIVITAS')?></h2><?php if($creativeSubtitle!==''): ?><p><?=e($creativeSubtitle)?></p><?php endif; ?></div></div>
      </div>
      <div class="creative-grid">
        <div class="creative-albums">
          <?php foreach($creativeAlbums as $card): if($card['title']==='' && $card['image']==='') continue; $link=$card['link']!==''?$card['link']:'#'; ?>
          <a class="creative-album-card" href="<?=e($link)?>" <?=($link!=='#'&&preg_match('~^https?://~i',$link)?'target="_blank" rel="noopener noreferrer"':'')?> >
            <?php if($card['image']!==''): ?><img src="<?=e($card['image'])?>" alt="<?=e($card['title'])?>" loading="lazy" decoding="async"><?php else: ?><span class="creative-album-placeholder">✦</span><?php endif; ?>
            <span class="creative-card-shade"></span><span class="creative-card-copy"><small><?=e($card['label']?:'ALBUM')?></small><b><?=e($card['title'])?></b></span>
          </a>
          <?php endforeach; ?>
        </div>
        <div class="creative-videos">
          <?php foreach($creativeVideos as $video): if($video['title']==='' && $video['link']==='') continue; $vlink=$video['link']!==''?$video['link']:'#'; ?>
          <a class="creative-video-card" href="<?=e($vlink)?>" <?=($vlink!=='#'&&preg_match('~^https?://~i',$vlink)?'target="_blank" rel="noopener noreferrer"':'')?> style="<?=($video['thumbnail']!==''?'--creative-video-bg:url(\''.e($video['thumbnail']).'\')':'')?>">
            <span class="creative-video-overlay"></span><span class="creative-play">▶</span><span class="creative-video-title"><?=e($video['title'])?></span>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </section>
  <?php if($quoteEnabled && ($quoteText!=='' || $quoteAuthor!=='')): ?>
  <section class="creative-quote" aria-label="Kutipan motivasi">
    <div class="creative-quote-mark">“</div><blockquote><?=e($quoteText)?></blockquote><?php if($quoteAuthor!==''): ?><div class="creative-quote-author">— &nbsp;<?=e($quoteAuthor)?>&nbsp; —</div><?php endif; ?>
  </section>
  <?php endif; ?>
  <?php endif; ?>


  <?php if($popular): ?>
  <section class="mag-section mag-latest-area">
    <div class="mag-section-heading"><div><span class="mag-kicker">ARTIKEL TERBARU</span><h2>Berita dan cerita pilihan</h2></div><a href="articles.php">Lihat semua →</a></div>
    <div class="mag-latest-grid">
      <div class="mag-latest-column">
        <?php foreach(array_slice($latest,0,5) as $a): ?>
        <article class="mag-horizontal-card">
          <a href="article.php?slug=<?=e($a['slug'])?>" class="mag-horizontal-image"><?php if(!empty($a['cover'])): ?><img src="<?=e(media_url($a['cover']))?>" alt="" loading="lazy" decoding="async"><?php else: ?><span class="mag-image-placeholder">M</span><?php endif; ?></a>
          <div><span class="mag-pill"><?=e($a['category']?:'Warta Sekolah')?></span><h3><a href="article.php?slug=<?=e($a['slug'])?>"><?=e($a['title'])?></a></h3><p><?=e(excerpt($a['excerpt']?:$a['content'],120))?></p><small><?=date('d M Y',strtotime($a['published_at']?:$a['created_at']))?> · <?=e($a['author']?:'Redaksi')?></small></div>
        </article>
        <?php endforeach; ?>
      </div>
      <aside class="mag-popular-card"><div class="mag-side-title">TERPOPULER</div><?php foreach($popular as $i=>$a): ?><a href="article.php?slug=<?=e($a['slug'])?>"><strong><?=str_pad((string)($i+1),2,'0',STR_PAD_LEFT)?></strong><span><small><?=e($a['category']?:'Artikel')?></small><b><?=e($a['title'])?></b></span></a><?php endforeach; ?></aside>
    </div>
  </section>
  <?php endif; ?>

  <?php foreach($sections as $slug=>$label): $q=$pdo->prepare("SELECT a.*,c.name category FROM articles a JOIN categories c ON c.id=a.category_id WHERE a.status='published' AND c.is_active=1 AND c.slug=? ORDER BY a.published_at DESC LIMIT 5");$q->execute(array($slug));$rows=$q->fetchAll();if(!$rows)continue; ?>
  <section class="mag-topic-section"><div class="mag-section-heading"><div><span class="mag-kicker">PILIHAN TOPIK</span><h2><?=e($label)?></h2></div><a href="articles.php?category=<?=e($slug)?>">Show all →</a></div><div class="mag-topic-row"><?php foreach($rows as $a): ?><article><a href="article.php?slug=<?=e($a['slug'])?>"><?php if(!empty($a['cover'])): ?><img src="<?=e(media_url($a['cover']))?>" alt="" loading="lazy" decoding="async"><?php else: ?><span class="mag-mini-placeholder"></span><?php endif; ?><span><small><?=e($a['category'])?></small><b><?=e($a['title'])?></b></span></a></article><?php endforeach; ?></div></section>
  <?php endforeach; ?>

  <section class="mag-collab"><div><span class="mag-kicker">PUNYA KARYA?</span><h2>Ruang kreatif untuk siswa dan warga sekolah.</h2><p><?=e(setting('tagline'))?> Kirim puisi, cerpen, opini, foto, video, atau karya digital melalui kanal publikasi sekolah.</p></div><?php if(auth() && in_array(auth()['role'],array('contributor','admin','superadmin'),true)):?><a class="mag-button" href="submit.php">Kirim karya sekarang →</a><?php else:?><a class="mag-button" href="register.php">Daftar sebagai Penulis →</a><?php endif;?></section>
</div>

<script src="<?=e(url('assets/js/news-slider-v1.js'))?>" defer></script>
<?php require 'partials/footer.php'; ?>
