<?php
require __DIR__ . '/../app/bootstrap.php';
if (auth()) { $current=auth(); if (in_array($current['role'], array('member','contributor'), true)) { redirect('member.php'); } else { redirect('admin/'); } }
$err='';
$loginCsrf = csrf();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf();
    $username=trim(isset($_POST['username'])?$_POST['username']:'');
    $password=isset($_POST['password'])?$_POST['password']:'';
    $rateKey=auth_rate_key($username);
    $rate=auth_rate_status($rateKey);
    if ($rate['blocked']) {
        $err='Terlalu banyak percobaan login. Silakan tunggu sekitar 15 menit lalu coba lagi.';
    } elseif ($username==='' || $password==='') {
        $err='Username dan password wajib diisi.';
    } else {
        $q=$pdo->prepare('SELECT * FROM users WHERE username=? LIMIT 1');
        $q->execute(array($username));
        $u=$q->fetch();
        if (!$u) {
            auth_rate_fail($rateKey);
            $err='Username atau password salah.';
        } elseif (isset($u['status']) && $u['status'] === 'pending') {
            $err='Pendaftaran Anda masih menunggu persetujuan administrator.';
        } elseif (isset($u['status']) && $u['status'] === 'rejected') {
            $err='Pendaftaran akun ditolak. Silakan hubungi administrator.';
        } elseif (isset($u['status']) && $u['status'] !== 'active') {
            $err='Akun tidak aktif. Hubungi administrator.';
        } elseif (!password_verify($password, $u['password_hash'])) {
            auth_rate_fail($rateKey);
            $err='Username atau password salah.';
        } else {
            if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
                $newHash=password_hash($password,PASSWORD_DEFAULT);
                $rq=$pdo->prepare('UPDATE users SET password_hash=? WHERE id=?');
                $rq->execute(array($newHash,$u['id']));
            }
            auth_rate_clear($rateKey);
            session_regenerate_id(true);
            unset($u['password_hash']);
            $_SESSION['user']=$u;
            flash('Login berhasil. Selamat datang, '.$u['name'].'.');
            session_write_close();
            if (in_array($u['role'], array('member','contributor'), true)) { redirect('member.php'); } else { redirect('admin/'); }
        }
    }
}
require 'partials/head.php';
?><div class="auth-shell"><div class="auth"><div class="auth-head"><span class="auth-mark" aria-hidden="true"><?php if(setting('logo')):?><img src="<?=e(app_file_url(setting('logo')))?>" alt=""><?php else:?>M<?php endif;?></span><span class="auth-kicker">AKSES REDAKSI</span><h1>Masuk Redaksi</h1><p class="auth-sub">Masuk untuk mengelola dan mengirim karya di <?=e($site)?>.</p></div><?php if($err):?><div class="alert" role="alert"><?=e($err)?></div><?php endif;?><form method="post" action="login.php" autocomplete="on"><input type="hidden" name="_csrf" value="<?=e($loginCsrf)?>"><label>Username<input name="username" required autocomplete="username" value="<?=e(isset($_POST['username'])?$_POST['username']:'')?>"></label><label>Password<input type="password" name="password" required autocomplete="current-password"></label><button class="btn" type="submit">Masuk</button></form><p class="auth-foot">Belum punya akun? <a href="register.php">Daftar Anggota / Penulis</a></p></div></div><?php require 'partials/footer.php';
