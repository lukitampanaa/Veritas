/* Scroll reveal v1 — see scroll-reveal-v1.css */
(function () {
  'use strict';
  if (!('IntersectionObserver' in window)) return;
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  /* What gets animated. Header, nav, dock, ticker, sliders and the WhatsApp
     button are deliberately NOT here. */
  var BIG = [
    'main > *:not(.mag-home-v6)',
    '.mag-hero', '.mag-section', '.mag-stats', '.mag-topic-section', '.mag-collab',
    '.creative-home-section', '.creative-quote',
    '.card', '.lead', '.formcard', '.auth', '.article-body', '.comments',
    '.site-footer'
  ];
  var SOFT = [
    '.mag-horizontal-card', '.mini-card', '.mag-topic-row > article',
    '.mag-rubric-section a', '.mag-stats > *', '.footer-grid > *',
    '.comments .comment', '.creative-home-section .card'
  ];
  var SKIP = '.lg-dock, .lg-panel, .lg-scrim, .floating-wa, header, nav, .mag-ticker, .mag-news-slider-section, .mag-news-slide, script, style';

  function init() {
    var root = document.documentElement;
    var vh = window.innerHeight || root.clientHeight;
    var seen = new Set();
    var list = [];

    function collect(sel, soft) {
      var nodes;
      try { nodes = document.querySelectorAll(sel); } catch (e) { return; }
      Array.prototype.forEach.call(nodes, function (el) {
        if (seen.has(el)) return;
        if (el.matches(SKIP) || el.closest(SKIP)) return;
        seen.add(el);
        list.push({ el: el, soft: soft });
      });
    }
    BIG.forEach(function (s) { collect(s, false); });
    SOFT.forEach(function (s) { collect(s, true); });

    /* Drop children whose ancestor is already animated (avoid double motion),
       except SOFT items, which stagger inside a revealed parent. */
    list = list.filter(function (o) {
      if (o.soft) return true;
      var p = o.el.parentElement;
      while (p) { if (seen.has(p) && !isSoft(p)) return false; p = p.parentElement; }
      return true;
    });
    function isSoft(node) { return list.some(function (o) { return o.el === node && o.soft; }); }

    /* Only hide what is currently below the fold. */
    var targets = list.filter(function (o) {
      var r = o.el.getBoundingClientRect();
      return r.top > vh * 0.92 && r.height > 0;
    });
    if (!targets.length) return;

    /* Stagger siblings that enter together */
    var idx = new Map();
    targets.forEach(function (o) {
      var p = o.el.parentElement;
      var n = idx.get(p) || 0;
      idx.set(p, n + 1);
      o.el.style.setProperty('--sr-d', Math.min(n, 5) * 80 + 'ms');
    });

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        var el = en.target;
        if (en.isIntersecting) {
          io.unobserve(el);
          /* Small rAF gap so the browser registers the hidden state first */
          requestAnimationFrame(function () { el.classList.add('sr-in'); });
          /* Release transform/will-change afterwards so hover effects work */
          window.setTimeout(function () {
            el.classList.remove('sr', 'sr-soft', 'sr-in');
            el.style.removeProperty('--sr-d');
          }, 1500 + parseInt(el.style.getPropertyValue('--sr-d') || '0', 10));
        } else if (en.boundingClientRect.top < 0) {
          /* Already scrolled past (fast scroll / anchor jump): show instantly */
          io.unobserve(el);
          el.style.transition = 'none';
          el.classList.add('sr-in');
          window.setTimeout(function () {
            el.classList.remove('sr', 'sr-soft', 'sr-in');
            el.style.removeProperty('transition');
            el.style.removeProperty('--sr-d');
          }, 60);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -6% 0px' });

    root.classList.add('sr-on');
    targets.forEach(function (o) {
      o.el.classList.add('sr');
      if (o.soft) o.el.classList.add('sr-soft');
      io.observe(o.el);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
