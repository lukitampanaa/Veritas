(function(){
  'use strict';
  function init(){
    var panel=document.getElementById('mobile-dock-menu-panel');
    var dock=document.querySelector('.mobile-macos-dock');
    var dockToggles=document.querySelectorAll('.mobile-dock-menu');
    /* V5.25.2: move the fixed dock outside header/transforming ancestors.
       This guarantees bottom-of-viewport placement on Android/iOS. */
    function portalDock(){
      if(!dock) return;
      if(dock.parentNode!==document.body) document.body.appendChild(dock);
      if(panel && panel.parentNode!==document.body) document.body.appendChild(panel);
    }
    portalDock();
    var legacyToggle=document.querySelector('.mobile-nav-toggle');
    if(!panel && !dockToggles.length)return;
    function isMobile(){return window.innerWidth<=768;}
    function setOpen(open){
      if(!isMobile()) open=false;
      dockToggles.forEach(function(btn){
        btn.setAttribute('aria-expanded',open?'true':'false');
        btn.classList.toggle('is-open',open);
      });
      if(panel){
        panel.classList.toggle('is-open',open);
        panel.setAttribute('aria-hidden',open?'false':'true');
      }
      document.body.classList.toggle('mobile-menu-open',open);
    }
    dockToggles.forEach(function(btn){
      btn.addEventListener('click',function(e){
        if(!isMobile())return;
        e.preventDefault();e.stopPropagation();
        setOpen(!document.body.classList.contains('mobile-menu-open'));
      });
    });
    if(legacyToggle){legacyToggle.addEventListener('click',function(e){e.preventDefault();});}
    if(panel){
      panel.addEventListener('click',function(e){
        var target=e.target;
        while(target&&target!==panel&&target.tagName!=='A')target=target.parentNode;
        if(target&&target.tagName==='A')setOpen(false);
      });
    }
    document.addEventListener('click',function(e){
      if(!document.body.classList.contains('mobile-menu-open'))return;
      if((dock&&dock.contains(e.target))||(panel&&panel.contains(e.target)))return;
      setOpen(false);
    });
    document.addEventListener('keydown',function(e){if(e.key==='Escape')setOpen(false);});
    window.addEventListener('resize',function(){portalDock();if(!isMobile())setOpen(false);});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
