(function(){'use strict';
function initSlider(root){
 var slides=[].slice.call(root.querySelectorAll('.mag-news-slide')); if(!slides.length)return;
 var dots=[].slice.call(root.querySelectorAll('.mag-news-dot')); var thumbs=[].slice.call(root.querySelectorAll('.mag-news-thumb')); var prev=root.querySelector('.mag-news-prev'), next=root.querySelector('.mag-news-next');
 var index=0,timer=null,interval=Math.max(2000,parseInt(root.getAttribute('data-interval')||'5000',10)),autoplay=root.getAttribute('data-autoplay')==='1';
 var reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 function show(n){index=(n+slides.length)%slides.length;slides.forEach(function(x,i){var active=i===index;x.classList.toggle('is-active',active);x.setAttribute('aria-hidden',active?'false':'true')});dots.forEach(function(x,i){x.classList.toggle('is-active',i===index);x.setAttribute('aria-selected',i===index?'true':'false')});thumbs.forEach(function(x,i){x.classList.toggle('is-active',i===index);x.setAttribute('aria-selected',i===index?'true':'false')});}
 function stop(){if(timer){clearInterval(timer);timer=null}}
 function start(){stop();if(!autoplay||reduced||slides.length<2)return;timer=setInterval(function(){show(index+1)},interval)}
 dots.concat(thumbs).forEach(function(btn){btn.addEventListener('click',function(){show(parseInt(btn.getAttribute('data-go')||'0',10));start()})});
 if(prev)prev.addEventListener('click',function(){show(index-1);start()});
 if(next)next.addEventListener('click',function(){show(index+1);start()});
 root.addEventListener('mouseenter',stop);root.addEventListener('mouseleave',start);root.addEventListener('focusin',stop);root.addEventListener('focusout',function(){setTimeout(function(){if(!root.contains(document.activeElement))start()},0)});
 var sx=0;root.addEventListener('touchstart',function(e){if(e.touches&&e.touches[0])sx=e.touches[0].clientX},{passive:true});root.addEventListener('touchend',function(e){if(!sx||!e.changedTouches||!e.changedTouches[0])return;var dx=e.changedTouches[0].clientX-sx;if(Math.abs(dx)>45){show(dx<0?index+1:index-1);start()}sx=0},{passive:true});
 show(0);start();
}
document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('.mag-news-slider').forEach(initSlider)});
})();
