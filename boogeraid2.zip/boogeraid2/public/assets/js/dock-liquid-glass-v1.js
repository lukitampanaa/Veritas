/* Liquid Glass bottom dock controller (v1).
   Scope: #lg-dock, #lg-panel, #lg-scrim only. */
(function () {
  'use strict';

  function init() {
    var dock = document.getElementById('lg-dock');
    var panel = document.getElementById('lg-panel');
    var scrim = document.getElementById('lg-scrim');
    if (!dock || !panel) return;

    var body = document.body;
    var bar = dock.querySelector('.lg-bar');
    var glow = dock.querySelector('.lg-glow');
    var toggle = dock.querySelector('.lg-menu');
    var mq = window.matchMedia ? window.matchMedia('(max-width:768px)') : null;

    function isMobile() { return mq ? mq.matches : window.innerWidth <= 768; }

    /* Fixed elements must live directly under <body> (ancestors with
       transform/backdrop-filter would break position:fixed). */
    [dock, panel, scrim].forEach(function (n) {
      if (n && n.parentNode !== body) body.appendChild(n);
    });

    /* ---------- Menu sheet ---------- */
    function setOpen(open) {
      if (open && !isMobile()) open = false;
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      toggle.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
      toggle.classList.toggle('is-open', open);
      panel.classList.toggle('is-open', open);
      panel.setAttribute('aria-hidden', open ? 'false' : 'true');
      body.classList.toggle('mobile-menu-open', open);
      if (open) {
        dock.classList.remove('is-compact');
        panel.scrollTop = 0;
      }
    }
    function isOpen() { return panel.classList.contains('is-open'); }

    toggle.addEventListener('click', function (e) {
      e.preventDefault();
      setOpen(!isOpen());
    });
    if (scrim) scrim.addEventListener('click', function () { setOpen(false); });

    panel.addEventListener('click', function (e) {
      var t = e.target;
      var a = t && t.closest ? t.closest('a') : null;
      if (a && panel.contains(a)) setOpen(false);
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && isOpen()) {
        setOpen(false);
        try { toggle.focus(); } catch (err) { /* noop */ }
      }
    });

    /* Reset when leaving mobile layout or restoring from bfcache */
    function onLayout() { if (!isMobile()) setOpen(false); }
    if (mq && mq.addEventListener) mq.addEventListener('change', onLayout);
    else window.addEventListener('resize', onLayout);
    window.addEventListener('orientationchange', function () { setOpen(false); });
    window.addEventListener('pageshow', function (e) { if (e.persisted) setOpen(false); });

    /* ---------- Scroll: compact while scrolling down, expand on scroll up ---------- */
    var lastY = window.pageYOffset || 0;
    var ticking = false;
    var acc = 0;

    function onScrollFrame() {
      ticking = false;
      if (isOpen()) { lastY = window.pageYOffset || 0; return; }
      var y = Math.max(0, window.pageYOffset || 0);
      var dy = y - lastY;
      lastY = y;
      var doc = document.documentElement;
      var nearEnd = y + window.innerHeight >= doc.scrollHeight - 8;

      if (y < 48 || nearEnd) { acc = 0; dock.classList.remove('is-compact'); return; }
      if ((dy > 0 && acc < 0) || (dy < 0 && acc > 0)) acc = 0;
      acc += dy;
      if (acc > 14) dock.classList.add('is-compact');
      else if (acc < -8) dock.classList.remove('is-compact');
    }
    window.addEventListener('scroll', function () {
      if (!ticking) { ticking = true; window.requestAnimationFrame(onScrollFrame); }
    }, { passive: true });

    /* Tapping the compact dock brings it back */
    bar.addEventListener('pointerdown', function () { dock.classList.remove('is-compact'); acc = 0; }, { passive: true });

    /* ---------- Touch-following light on the glass ---------- */
    if (glow) {
      var rect = null;
      var raf = 0;
      var px = 0;
      var paint = function () { raf = 0; glow.style.transform = 'translate3d(' + px + 'px,0,0)'; };
      bar.addEventListener('pointerdown', function (e) {
        rect = bar.getBoundingClientRect();
        px = e.clientX - rect.left;
        bar.classList.add('is-touch');
        if (!raf) raf = window.requestAnimationFrame(paint);
      }, { passive: true });
      bar.addEventListener('pointermove', function (e) {
        if (!rect || !bar.classList.contains('is-touch')) return;
        px = e.clientX - rect.left;
        if (!raf) raf = window.requestAnimationFrame(paint);
      }, { passive: true });
      var end = function () { bar.classList.remove('is-touch'); rect = null; };
      bar.addEventListener('pointerup', end, { passive: true });
      bar.addEventListener('pointercancel', end, { passive: true });
      bar.addEventListener('pointerleave', end, { passive: true });
    }

    /* ---------- Hide the dock while a text field is focused (on-screen keyboard) ---------- */
    function isField(el) {
      if (!el || !el.tagName) return false;
      var tag = el.tagName;
      if (tag === 'TEXTAREA' || tag === 'SELECT') return true;
      if (tag === 'INPUT') {
        var type = (el.getAttribute('type') || 'text').toLowerCase();
        return ['button', 'submit', 'reset', 'checkbox', 'radio', 'range', 'file', 'image', 'color'].indexOf(type) === -1;
      }
      return !!el.isContentEditable;
    }
    document.addEventListener('focusin', function (e) {
      if (isField(e.target) && isMobile()) dock.classList.add('is-kb');
    });
    document.addEventListener('focusout', function () {
      window.setTimeout(function () {
        if (!isField(document.activeElement)) dock.classList.remove('is-kb');
      }, 60);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
