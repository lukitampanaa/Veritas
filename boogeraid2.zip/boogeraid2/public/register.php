<?php
require __DIR__.'/../app/bootstrap.php';
$err='';
if (auth()) { redirect('member.php'); }
if ($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf();
    try {
        $name=trim((string)($_POST['name']??''));
        $username=trim((string)($_POST['username']??''));
        $email=trim((string)($_POST['email']??''));
        $password=(string)($_POST['password']??'');
        $accountType=(string)($_POST['account_type']??'member');
        if ($name==='' || !preg_match('/^[A-Za-z0-9._-]{4,40}$/',$username) || strlen($password)<10) throw new RuntimeException('Nama wajib diisi, username harus 4–40 karakter (huruf, angka, titik, garis bawah, atau minus), dan password minimal 10 karakter.');
        if ($email!=='' && !filter_var($email,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Format email tidak valid.');
        if (!in_array($accountType,array('member','contributor'),true)) throw new RuntimeException('Jenis pendaftaran tidak valid.');
        $q=$pdo->prepare('INSERT INTO users(name,username,email,password_hash,role,status) VALUES(?,?,?,?,?,?)');
        $q->execute([$name,$username,$email!==''?$email:null,password_hash($password,PASSWORD_DEFAULT),$accountType,'pending']);
        flash($accountType==='contributor' ? 'Pendaftaran Penulis berhasil dikirim. Akun harus disetujui admin sebelum dapat digunakan.' : 'Pendaftaran Anggota berhasil dikirim. Akun harus disetujui admin sebelum dapat digunakan.');
        redirect('login.php');
    } catch (Throwable $e) { $err=$e instanceof RuntimeException ? $e->getMessage() : 'Username atau email mungkin sudah digunakan.'; }
}
require 'partials/head.php';
?>
<div class="auth"><h1>Daftar Akun</h1>
<p>Pilih jenis akun. Semua pendaftaran harus disetujui admin terlebih dahulu.</p>
<?php if($err):?><div class="alert"><?=e($err)?></div><?php endif;?>
<form method="post"><input type="hidden" name="_csrf" value="<?=e(csrf())?>">
<label>Jenis akun<select name="account_type" id="accountType"><option value="member">Anggota</option><option value="contributor">Penulis</option></select></label>
<div class="card pad" id="roleInfo"><b>Anggota</b><p>Fitur: membaca artikel, menyukai artikel, berkomentar, dan mengelola aktivitas akun.</p><p>Anggota tidak dapat mengirim naskah.</p></div>
<label>Nama lengkap<input name="name" required placeholder="Nama lengkap"></label>
<label>Username<input name="username" required placeholder="Username" autocomplete="username"></label>
<label>Email<input type="email" name="email" placeholder="Email"></label>
<label>Password<input type="password" name="password" required minlength="8" placeholder="Minimal 8 karakter" autocomplete="new-password"></label>
<button class="btn">Ajukan Pendaftaran</button></form></div>
<script>const t=document.getElementById('accountType'),i=document.getElementById('roleInfo');function roleInfo(){i.innerHTML=t.value==='contributor'?'<b>Penulis</b><p>Fitur: semua fitur Anggota, plus mengirim naskah/artikel ke redaksi untuk diperiksa.</p><p>Penulis tidak dapat menerbitkan, menghapus, atau mengubah artikel pengguna lain.</p>':'<b>Anggota</b><p>Fitur: membaca artikel, menyukai artikel, berkomentar, dan mengelola aktivitas akun.</p><p>Anggota tidak dapat mengirim naskah.</p>'}t.addEventListener('change',roleInfo);</script>
<?php require 'partials/footer.php';
