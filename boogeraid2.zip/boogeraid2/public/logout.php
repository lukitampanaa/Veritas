<?php
require __DIR__ . '/../app/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('member.php');
}

check_csrf();

// Hanya endpoint logout publik untuk akun Anggota/Penulis.
$current = auth();
if ($current && in_array($current['role'], array('member','contributor'), true)) {
    $_SESSION = array();
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'],
            $params['secure'], $params['httponly']
        );
    }
    session_destroy();
}

header('Location: ' . url('login.php'));
exit;
