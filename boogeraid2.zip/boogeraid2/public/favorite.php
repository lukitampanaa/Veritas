<?php
require __DIR__ . '/../app/bootstrap.php';
require_login(array('superadmin','admin','contributor','member'));

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('index.php');
check_csrf();

$articleId = (int)(isset($_POST['article_id']) ? $_POST['article_id'] : 0);
$back = trim((string)(isset($_POST['back']) ? $_POST['back'] : ''));

if ($articleId <= 0) {
    flash('Artikel tidak valid.');
    redirect('index.php');
}

$st = $pdo->prepare("SELECT id, slug, status FROM articles WHERE id=? LIMIT 1");
$st->execute(array($articleId));
$article = $st->fetch();
if (!$article || $article['status'] !== 'published') {
    flash('Artikel tidak tersedia.');
    redirect('index.php');
}

/* Keep legacy databases usable when the V5.12 favorites migration has not been run. */
try {
    $ready = (bool)$pdo->query("SHOW TABLES LIKE 'article_favorites'")->fetchColumn();
} catch (Throwable $e) {
    $ready = false;
}

if (!$ready) {
    flash('Fitur Suka Artikel belum diaktifkan pada database ini. Artikel tetap dapat dibaca.');
    if ($back !== '' && preg_match('/^article\.php\?slug=[a-zA-Z0-9_%\-]+$/', $back)) redirect($back);
    redirect('article.php?slug=' . urlencode($article['slug']));
}

$userId = (int)auth()['id'];
$check = $pdo->prepare('SELECT id FROM article_favorites WHERE article_id=? AND user_id=? LIMIT 1');
$check->execute(array($articleId, $userId));
$existing = $check->fetchColumn();

if ($existing) {
    $pdo->prepare('DELETE FROM article_favorites WHERE id=?')->execute(array((int)$existing));
    flash('Artikel dihapus dari Artikel Disukai.');
} else {
    $pdo->prepare('INSERT INTO article_favorites(article_id,user_id) VALUES(?,?)')->execute(array($articleId, $userId));
    flash('Artikel ditambahkan ke Artikel Disukai.');
}

if ($back !== '' && preg_match('/^article\.php\?slug=[a-zA-Z0-9_%\-]+$/', $back)) redirect($back);
redirect('article.php?slug=' . urlencode($article['slug']));
