<?php
// Majalah Sekolah Online - V5.17 Visitor Counter
// Anonymous real-time presence + historical unique visitor counter.
// Compatible with PHP 7.4+; no IP address or personal identity is stored.
require __DIR__ . '/../app/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS realtime_visitors (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        visitor_key CHAR(64) NOT NULL,
        last_seen DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_realtime_visitor (visitor_key),
        KEY idx_realtime_last_seen (last_seen)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Permanent anonymous registry used for the historical unique-visitor total.
    // It stores only a random cookie hash, first_seen and last_seen.
    $pdo->exec("CREATE TABLE IF NOT EXISTS visitor_registry (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        visitor_key CHAR(64) NOT NULL,
        first_seen DATETIME NOT NULL,
        last_seen DATETIME NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uq_visitor_registry_key (visitor_key),
        KEY idx_visitor_registry_last_seen (last_seen)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $cookieName = 'MSO_REALTIME_VISITOR';
    $visitorKey = isset($_COOKIE[$cookieName]) ? preg_replace('/[^a-f0-9]/i', '', (string)$_COOKIE[$cookieName]) : '';
    if (strlen($visitorKey) !== 64) {
        try {
            $visitorKey = hash('sha256', random_bytes(32));
        } catch (Exception $e) {
            $visitorKey = hash('sha256', uniqid('', true) . mt_rand());
        }
        $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        setcookie($cookieName, $visitorKey, array(
            'expires' => 0,
            'path' => '/',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax'
        ));
    }

    // Register this anonymous visitor permanently for historical unique count.
    $registry = $pdo->prepare("INSERT INTO visitor_registry(visitor_key,first_seen,last_seen)
        VALUES(?,NOW(),NOW())
        ON DUPLICATE KEY UPDATE last_seen=NOW()");
    $registry->execute(array($visitorKey));

    // Update the short-lived real-time presence record.
    $upsert = $pdo->prepare("INSERT INTO realtime_visitors(visitor_key,last_seen) VALUES(?,NOW())
        ON DUPLICATE KEY UPDATE last_seen=NOW()");
    $upsert->execute(array($visitorKey));

    // Keep the presence table small without affecting historical data.
    $pdo->exec("DELETE FROM realtime_visitors WHERE last_seen < DATE_SUB(NOW(), INTERVAL 1 DAY)");

    $online = (int)$pdo->query("SELECT COUNT(*) FROM realtime_visitors WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)")->fetchColumn();
    $totalVisitors = (int)$pdo->query("SELECT COUNT(*) FROM visitor_registry")->fetchColumn();

    echo json_encode(array(
        'ok' => true,
        'online' => $online,
        'total_visitors' => $totalVisitors,
        'window_seconds' => 120
    ), JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(200);
    echo json_encode(array('ok'=>false,'online'=>0,'total_visitors'=>0));
}
