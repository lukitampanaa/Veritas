<?php
require __DIR__ . '/../app/bootstrap.php';
require_login(array('superadmin','admin','contributor','member'));

$userId = (int)auth()['id'];
$rows = array();
$favoritesReady = false;
try {
    $favoritesReady = (bool)$pdo->query("SHOW TABLES LIKE 'article_favorites'")->fetchColumn();
    if ($favoritesReady) {
        $st = $pdo->prepare("SELECT a.id,a.title,a.slug,a.cover,a.excerpt,a.published_at,a.views,c.name category,f.created_at favorite_at
            FROM article_favorites f
            JOIN articles a ON a.id=f.article_id
            LEFT JOIN categories c ON c.id=a.category_id
            WHERE f.user_id=? AND a.status='published'
            ORDER BY f.created_at DESC");
        $st->execute(array($userId));
        $rows = $st->fetchAll();
    }
} catch (Throwable $e) {
    $favoritesReady = false;
}
require 'partials/head.php';
?>
<div class="pagehead">
    <h1>Artikel Disukai</h1>
    <p>Daftar artikel yang Anda simpan untuk dibaca kembali.</p>
</div>
<?php if (!$favoritesReady): ?>
    <section class="formcard"><p>Fitur Artikel Disukai belum tersedia pada database ini. Silakan hubungi administrator untuk menjalankan migrasi database.</p><a class="btn" href="articles.php">Jelajahi Artikel</a></section>
<?php elseif (!$rows): ?>
    <section class="formcard"><p>Belum ada artikel yang disukai. Buka artikel dan tekan tombol <b>♡ Suka Artikel</b>.</p><a class="btn" href="articles.php">Jelajahi Artikel</a></section>
<?php else: ?>
<section class="grid">
<?php foreach ($rows as $a): ?>
<article class="card">
    <?php if (!empty($a['cover'])): ?><img loading="lazy" class="thumb" src="<?=e($a['cover'])?>" alt="<?=e($a['title'])?>"><?php else: ?><div class="thumb" style="display:grid;place-items:center;background:#eef2ff;color:#173b8f;font-weight:800">MAJALAH</div><?php endif; ?>
    <div class="pad">
        <span class="pill"><?=e($a['category'] ?: 'Artikel')?></span>
        <h3><a href="article.php?slug=<?=e($a['slug'])?>"><?=e($a['title'])?></a></h3>
        <small><?=date('d M Y', strtotime($a['published_at'] ?: $a['favorite_at']))?> · <?=number_format((int)$a['views'])?> views</small>
        <p><?=e(excerpt($a['excerpt'] ?: '', 150))?></p>
        <a class="btn" href="article.php?slug=<?=e($a['slug'])?>">Baca Artikel</a>
    </div>
</article>
<?php endforeach; ?>
</section>
<?php endif; ?>
<?php require 'partials/footer.php';
