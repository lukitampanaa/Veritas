<?php
/**
 * Public Gallery — reads the same gallery_items records created by
 * Admin > Galeri > Galeri Media, with Media Library and legacy galleries
 * as compatible fallbacks.
 */
require __DIR__.'/../app/bootstrap.php';

$items = [];

/* 1) Current Gallery Media records. This must be the primary source. */
try {
    $st = $pdo->query("SELECT id,title,description,media_type,playlist_id,media_url,thumbnail_url,source_url,created_at
                       FROM gallery_items
                       WHERE is_active=1
                       ORDER BY created_at DESC,id DESC");
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $url = trim((string)($row['media_url'] ?? ''));
        if ($url === '') continue;
        $items[] = [
            'id' => (int)$row['id'],
            'title' => trim((string)($row['title'] ?? '')) ?: 'Media Galeri',
            'description' => trim((string)($row['description'] ?? '')),
            'media_type' => trim((string)($row['media_type'] ?? 'image')) ?: 'image',
            'playlist_id' => (int)($row['playlist_id'] ?? 0),
            'media_url' => $url,
            'thumbnail_url' => trim((string)($row['thumbnail_url'] ?? '')),
            'source_url' => trim((string)($row['source_url'] ?? '')),
            'created_at' => $row['created_at'] ?? '',
            'source' => 'gallery_items',
        ];
    }
} catch (Throwable $e) {
    /* Older installations may not have gallery_items yet. */
}

/* 2) Media Library uploads not yet added to Gallery. */
try {
    $st = $pdo->query("SELECT id,title,image,thumb,mime,created_at
                       FROM media_library
                       ORDER BY created_at DESC,id DESC LIMIT 100");
    $galleryMediaIds = [];
    foreach ($items as $it) {
        $galleryMediaIds[trim((string)$it['media_url'])] = true;
    }
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $path = trim((string)($row['image'] ?? ''));
        if ($path === '' || isset($galleryMediaIds[$path])) continue;
        $items[] = [
            'id' => 'library-' . (int)$row['id'],
            'title' => trim((string)($row['title'] ?? '')) ?: 'Media Galeri',
            'description' => '',
            'media_type' => 'image',
            'media_url' => $path,
            'thumbnail_url' => trim((string)($row['thumb'] ?? '')),
            'source_url' => $path,
            'created_at' => $row['created_at'] ?? '',
            'source' => 'media_library',
        ];
    }
} catch (Throwable $e) {}

/* 3) Legacy galleries table, kept for older content. */
try {
    $st = $pdo->query("SELECT id,title,description,image,created_at
                       FROM galleries ORDER BY created_at DESC,id DESC");
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $path = trim((string)($row['image'] ?? ''));
        if ($path === '') continue;
        $items[] = [
            'id' => 'legacy-' . (int)$row['id'],
            'title' => trim((string)($row['title'] ?? '')) ?: 'Media Galeri',
            'description' => trim((string)($row['description'] ?? '')),
            'media_type' => 'image',
            'media_url' => $path,
            'thumbnail_url' => '',
            'source_url' => $path,
            'created_at' => $row['created_at'] ?? '',
            'source' => 'galleries',
        ];
    }
} catch (Throwable $e) {}

function public_gallery_url($path) {
    $path = trim((string)$path);
    if ($path === '') return '';
    return app_file_url($path);
}

function public_gallery_image_url($item) {
    $thumb = trim((string)($item['thumbnail_url'] ?? ''));
    $url = trim((string)($item['media_url'] ?? ''));
    $type = trim((string)($item['media_type'] ?? 'image'));
    if ($thumb !== '') return public_gallery_url($thumb);
    if ($type === 'image') return public_gallery_url($url);
    if ($type === 'youtube') {
        $p = parse_url($url);
        $host = strtolower((string)($p['host'] ?? ''));
        $path = (string)($p['path'] ?? '');
        $id = '';
        if ($host === 'youtu.be') $id = trim($path, '/');
        else { parse_str((string)($p['query'] ?? ''), $q); $id = (string)($q['v'] ?? ''); if (!$id && preg_match('~/(?:shorts|embed)/([A-Za-z0-9_-]{6,})~',$path,$m)) $id=$m[1]; }
        if ($id !== '') return 'https://i.ytimg.com/vi/'.rawurlencode($id).'/hqdefault.jpg';
    }
    return '';
}

$images = array_values(array_filter($items, function($item){ return ($item['media_type'] ?? 'image') === 'image'; }));
$videos = array_values(array_filter($items, function($item){ return ($item['media_type'] ?? 'image') !== 'image'; }));
$selectedPlaylistId=(int)($_GET['playlist']??0); $selectedPlaylist=null;
if($selectedPlaylistId>0){ try { $pq=$pdo->prepare('SELECT id,title,media_type FROM gallery_playlists WHERE id=? AND is_active=1 LIMIT 1'); $pq->execute(array($selectedPlaylistId)); $selectedPlaylist=$pq->fetch(); if($selectedPlaylist){ $items=array_values(array_filter($items,function($item)use($selectedPlaylistId){return (int)($item['playlist_id']??0)===$selectedPlaylistId;})); $images=array_values(array_filter($items,function($item){return ($item['media_type']??'image')==='image';})); $videos=array_values(array_filter($items,function($item){return ($item['media_type']??'image')!=='image';})); } } catch(Throwable $e) {} }
$seoTitle = $selectedPlaylist ? ('Playlist: '.$selectedPlaylist['title']) : 'Galeri';
require __DIR__.'/partials/head.php';
?>
<style>
.gallery-page{padding:20px 0 50px}.gallery-page .gallery-head{margin-bottom:24px}.gallery-page .gallery-head h1{margin:0 0 8px}.gallery-page .gallery-tabs{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 24px}.gallery-page .gallery-tab{display:inline-flex;align-items:center;gap:7px;padding:10px 15px;border:1px solid var(--border,rgba(15,23,42,.12));border-radius:999px;text-decoration:none;color:inherit;background:var(--surface,#fff);font-weight:700}.gallery-page .gallery-tab.active{background:var(--primary,#1e40af);color:#fff;border-color:var(--primary,#1e40af)}.gallery-page .gallery-section{margin:0 0 34px}.gallery-page .gallery-section-head{display:flex;align-items:end;justify-content:space-between;gap:12px;margin-bottom:14px}.gallery-page .gallery-section-head h2{margin:0}.gallery-page .gallery-section-count{font-size:12px;color:var(--muted,#64748b)}.gallery-page .gallery-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}.gallery-page .gallery-card{background:var(--surface,rgba(255,255,255,.78));border:1px solid var(--border,rgba(15,23,42,.10));border-radius:18px;overflow:hidden;box-shadow:0 8px 28px rgba(15,23,42,.07)}.gallery-page .gallery-card a{display:block;color:inherit;text-decoration:none}.gallery-page .gallery-media{aspect-ratio:16/9;background:linear-gradient(135deg,rgba(59,130,246,.10),rgba(139,92,246,.12));display:flex;align-items:center;justify-content:center;overflow:hidden}.gallery-page .gallery-media img{width:100%;height:100%;object-fit:cover;display:block}.gallery-page .gallery-placeholder{font-size:42px;opacity:.65}.gallery-page .gallery-info{padding:15px 16px}.gallery-page .gallery-title{font-weight:700;margin-bottom:5px}.gallery-page .gallery-type{font-size:12px;color:var(--muted,#64748b)}.gallery-page .gallery-empty{padding:30px;border:1px dashed var(--border,rgba(15,23,42,.15));border-radius:16px;color:var(--muted,#64748b)}.gallery-page .gallery-empty.small{padding:22px}.gallery-page .gallery-video-badge{position:absolute;left:12px;bottom:12px;padding:6px 9px;border-radius:999px;background:rgba(15,23,42,.78);color:#fff;font-size:12px;font-weight:700}.gallery-page .gallery-media{position:relative}
@media(max-width:900px){.gallery-page .gallery-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:600px){.gallery-page .gallery-grid{grid-template-columns:1fr}}
</style>

<main class="wrap gallery-page">
  <div class="gallery-head">
    <span class="pill">MEDIA GALLERY</span>
    <h1>Galeri</h1>
    <p>Galeri gambar dan galeri video warga sekolah dipisahkan agar lebih mudah dijelajahi.</p>
  </div>

  <div class="gallery-tabs">
    <a class="gallery-tab active" href="#galeri-gambar">🖼️ Galeri Gambar <span>(<?=count($images)?>)</span></a>
    <a class="gallery-tab" href="#galeri-video">▶️ Galeri Video <span>(<?=count($videos)?>)</span></a>
  </div>

  <section class="gallery-section" id="galeri-gambar">
    <div class="gallery-section-head"><h2>Galeri Gambar</h2><span class="gallery-section-count"><?=count($images)?> gambar</span></div>
    <?php if (!$images): ?>
      <div class="gallery-empty">Belum ada gambar yang dapat ditampilkan.</div>
    <?php else: ?>
      <div class="gallery-grid">
      <?php foreach ($images as $item):
          $thumbUrl = public_gallery_image_url($item);
          $sourceUrl = trim((string)($item['source_url'] ?? ''));
          $linkUrl = $sourceUrl !== '' ? public_gallery_url($sourceUrl) : public_gallery_url($item['media_url']);
          $title = trim((string)$item['title']) ?: 'Gambar Galeri';
      ?>
        <article class="gallery-card"><a href="<?=e($linkUrl ?: '#')?>" target="_blank" rel="noopener noreferrer"><div class="gallery-media"><?php if ($thumbUrl): ?><img loading="lazy" decoding="async" src="<?=e($thumbUrl)?>" alt="<?=e($title)?>"><?php else: ?><div class="gallery-placeholder">🖼️</div><?php endif; ?></div><div class="gallery-info"><div class="gallery-title"><?=e($title)?></div><div class="gallery-type">Foto / Gambar</div></div></a></article>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  <section class="gallery-section" id="galeri-video">
    <div class="gallery-section-head"><h2>Galeri Video</h2><span class="gallery-section-count"><?=count($videos)?> video</span></div>
    <?php if (!$videos): ?>
      <div class="gallery-empty">Belum ada video yang dapat ditampilkan.</div>
    <?php else: ?>
      <div class="gallery-grid">
      <?php foreach ($videos as $item):
          $rawUrl = trim((string)$item['media_url']);
          $thumbUrl = public_gallery_image_url($item);
          $sourceUrl = trim((string)($item['source_url'] ?? ''));
          $linkUrl = $sourceUrl !== '' ? public_gallery_url($sourceUrl) : $rawUrl;
          $title = trim((string)$item['title']) ?: 'Video Galeri';
          $type = trim((string)$item['media_type']);
          $typeLabel = array('youtube'=>'YouTube','facebook_reel'=>'Facebook Reels','instagram_reel'=>'Instagram Reels','tiktok'=>'TikTok');
      ?>
        <article class="gallery-card"><a href="<?=e($linkUrl ?: '#')?>" target="_blank" rel="noopener noreferrer"><div class="gallery-media"><?php if ($thumbUrl): ?><img loading="lazy" decoding="async" src="<?=e($thumbUrl)?>" alt="<?=e($title)?>"><?php else: ?><div class="gallery-placeholder">▶</div><?php endif; ?><span class="gallery-video-badge">▶ <?=e($typeLabel[$type] ?? 'Video')?></span></div><div class="gallery-info"><div class="gallery-title"><?=e($title)?></div><div class="gallery-type"><?=e($typeLabel[$type] ?? 'Video')?></div></div></a></article>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
</main>
<?php require __DIR__.'/partials/footer.php'; ?>
