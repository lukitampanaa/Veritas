<?php
require __DIR__ . '/../app/bootstrap.php';
require_login(array('member','contributor','admin','superadmin'));
if (auth()['status'] !== 'active') { http_response_code(403); exit('Akun belum aktif.'); }

$u = auth();
$favoriteCount = 0;
$commentCount = 0;
$submissionCount = 0;
try {
    $q = $pdo->prepare('SELECT COUNT(*) FROM article_favorites WHERE user_id=?');
    $q->execute(array((int)$u['id']));
    $favoriteCount = (int)$q->fetchColumn();
    $q = $pdo->prepare('SELECT COUNT(*) FROM comments WHERE user_id=?');
    $q->execute(array((int)$u['id']));
    $commentCount = (int)$q->fetchColumn();
    $q = $pdo->prepare('SELECT COUNT(*) FROM articles WHERE author_id=?');
    $q->execute(array((int)$u['id']));
    $submissionCount = (int)$q->fetchColumn();
} catch (Throwable $e) {}
require 'partials/head.php';
?>
<div class="pagehead">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap">
        <div><h1>Akun Saya</h1><p>Selamat datang, <?=e($u['name'])?>.</p></div>
        <form method="post" action="logout.php" style="margin:0">
            <input type="hidden" name="_csrf" value="<?=e(csrf())?>">
            <button class="btn" type="submit">Keluar</button>
        </form>
    </div>
</div>
<div class="grid">
    <section class="card pad"><span class="pill">Artikel Disukai</span><h2><?=number_format($favoriteCount)?></h2><a class="btn" href="favorites.php">Lihat Artikel Disukai</a></section>
    <section class="card pad"><span class="pill">Komentar</span><h2><?=number_format($commentCount)?></h2><p>Komentar yang pernah Anda kirim.</p></section>
    <section class="card pad"><span class="pill">Karya/Naskah</span><h2><?=number_format($submissionCount)?></h2><?php if(in_array($u['role'],array('contributor','admin','superadmin'),true)):?><a class="btn" href="submit.php">Kirim Karya</a><?php else:?><p>Fitur kirim karya tersedia untuk Penulis.</p><?php endif;?></section>
</div>
<section class="formcard" style="margin-top:20px"><h2>Aktivitas Anggota</h2><p>Anda dapat menyukai artikel dan memberikan komentar. <?php if(in_array($u['role'],array('contributor','admin','superadmin'),true)):?>Sebagai Penulis, Anda juga dapat mengirim karya kepada redaksi. <?php endif;?>Komentar tetap melalui moderasi redaksi.</p><a class="btn" href="articles.php">Jelajahi Artikel</a></section>
<?php require 'partials/footer.php';
