<?php
require __DIR__.'/../app/bootstrap.php';
require_login(array('superadmin','admin','contributor','member'));
if($_SERVER['REQUEST_METHOD']!=='POST') redirect('index.php');
check_csrf();
$articleId=(int)($_POST['article_id']??0);
$content=trim((string)($_POST['content']??''));
if($articleId<=0 || $content==='') { flash('Artikel dan komentar wajib diisi.'); redirect('index.php'); }
if(mb_strlen($content) > 5000) { flash('Komentar maksimal 5000 karakter.'); redirect('index.php'); }
$a=$pdo->prepare("SELECT id,slug FROM articles WHERE id=? AND status='published' LIMIT 1");
$a->execute(array($articleId));
$article=$a->fetch();
if(!$article){ flash('Artikel tidak ditemukan atau belum dipublikasikan.'); redirect('index.php'); }
$u=auth();
$q=$pdo->prepare('INSERT INTO comments(article_id,user_id,name,email,content,status) VALUES(?,?,?,?,?,?)');
$q->execute(array($articleId,(int)$u['id'],$u['name'],$u['email']??null,$content,'pending'));
flash('Komentar berhasil dikirim dan menunggu persetujuan Admin/Superadmin.');
redirect('article.php?slug='.urlencode($article['slug']));
