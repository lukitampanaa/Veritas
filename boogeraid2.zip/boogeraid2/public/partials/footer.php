<?php
$siteName = setting('site_name','Majalah Sekolah Online');
$schoolName = setting('school_name','SMA/SMK/SMP Sekolah Anda');
$about = setting('about_text','Media digital sekolah untuk berita, karya, prestasi, dan kreativitas warga sekolah.');
$address = setting('school_address','');
$email = setting('editorial_email','');
$whatsapp = setting('whatsapp','');

$footerCategories=[];
try{$footerCategories=$pdo->query("SELECT id,name,slug,parent_id FROM categories WHERE is_active=1 ORDER BY name")->fetchAll();}catch(Throwable $e){try{$footerCategories=$pdo->query("SELECT id,name,slug FROM categories ORDER BY name")->fetchAll();}catch(Throwable $ignore){}}
$footerMenus=[];
try{$footerMenus=$pdo->query("SELECT id,label,url,target FROM menus WHERE is_active=1 ORDER BY sort_order,id")->fetchAll();}catch(Throwable $e){}
$categoryById=[];foreach($footerCategories as $fc){$categoryById[(string)$fc['id']]=$fc;}
$menuById=[];foreach($footerMenus as $fm){$menuById[(string)$fm['id']]=$fm;}
$decodeFooterConfig=function($raw){$data=json_decode((string)$raw,true);if(!is_array($data))return [];return array_slice(array_values(array_filter($data,function($x){return is_array($x)&&in_array(($x['type']??''),['category','external','menu'],true);})),0,10);};
$categoryItems=$decodeFooterConfig(setting('footer_category_items','[]'));
$collabItems=$decodeFooterConfig(setting('footer_collab_items','[]'));
$categoryCount=max(1,min(10,(int)setting('footer_category_count',count($categoryItems)?count($categoryItems):8)));
$collabCount=max(1,min(10,(int)setting('footer_collab_count',count($collabItems)?count($collabItems):6)));
$buildFooterLink=function($item)use($categoryById,$menuById){
  $type=$item['type']??'';$label=trim((string)($item['label']??''));$target=($item['target']??'_self')==='_blank'?'_blank':'_self';$url='';$isExternal=false;
  if($type==='category'){
    $cat=$categoryById[(string)($item['id']??'')]??null;if(!$cat)return null;
    $url=url('articles.php?category='.rawurlencode($cat['slug']));if($label==='')$label=$cat['name'];$target='_self';
  }elseif($type==='menu'){
    $menu=$menuById[(string)($item['id']??'')]??null;if(!$menu)return null;
    $url=(string)$menu['url'];if($label==='')$label=$menu['label'];if(($item['target']??'')!=='_blank' && !empty($menu['target']))$target=$menu['target']==='_blank'?'_blank':'_self';
    if(preg_match('#^(https?://|mailto:|tel:)#i',$url))$isExternal=true;else $url=url(ltrim($url,'/'));
  }elseif($type==='external'){
    $url=trim((string)($item['url']??''));if($label===''||$url==='')return null;if(!preg_match('#^(https?://|mailto:|tel:)#i',$url))return null;$isExternal=true;
  }
  if($label===''||$url==='')return null;return ['label'=>$label,'url'=>$url,'target'=>$target,'external'=>$isExternal];
};
$categoryLinks=[];foreach(array_slice($categoryItems,0,$categoryCount) as $item){$link=$buildFooterLink($item);if($link)$categoryLinks[]=$link;}
$collabLinks=[];foreach(array_slice($collabItems,0,$collabCount) as $item){$link=$buildFooterLink($item);if($link)$collabLinks[]=$link;}
if(!$categoryItems){foreach(array_slice($footerCategories,0,8) as $cat){$categoryLinks[]=['label'=>$cat['name'],'url'=>url('articles.php?category='.rawurlencode($cat['slug'])),'target'=>'_self','external'=>false];}}
if(!$collabItems){
  $collabLabels=['Kirim Karya','Kolaborasi','Open Contribution','Program Magang','Media Partner','Kontak Kami'];$legacy=[];
  foreach($footerMenus as $fm){foreach($collabLabels as $needle){if(stripos((string)$fm['label'],$needle)!==false){$legacy[]=$fm;break;}}}
  if(!$legacy)$legacy=[['label'=>((auth() && in_array(auth()['role'],array('contributor','admin','superadmin'),true))?'Kirim Karya':'Daftar Penulis'),'url'=>((auth() && in_array(auth()['role'],array('contributor','admin','superadmin'),true))?'submit.php':'register.php'),'target'=>'_self'],['label'=>'Galeri','url'=>'gallery.php','target'=>'_self'],['label'=>'Agenda','url'=>'agenda.php','target'=>'_self'],['label'=>'Hubungi Redaksi','url'=>'contact.php','target'=>'_self']];
  foreach(array_slice($legacy,0,$collabCount) as $cm){$u=(string)$cm['url'];$ext=preg_match('#^(https?://|mailto:|tel:)#i',$u);$collabLinks[]=['label'=>$cm['label'],'url'=>$ext?$u:url(ltrim($u,'/')),'target'=>($cm['target']??'_self')==='_blank'?'_blank':'_self','external'=>(bool)$ext];
  }
}
$waDigits=preg_replace('/\D+/','',(string)$whatsapp);if($waDigits!==''&&substr($waDigits,0,1)==='0')$waDigits='62'.substr($waDigits,1);
$replaceTokens=function($text)use($siteName,$schoolName){return strtr((string)$text,['{year}'=>date('Y'),'{school_name}'=>$schoolName,'{site_name}'=>$siteName]);};
$showAbout=setting('footer_show_about','1')==='1';$showCategories=setting('footer_show_categories','1')==='1';$showCollab=setting('footer_show_collab','1')==='1';$showContact=setting('footer_show_contact','1')==='1';$showSocial=setting('footer_show_social','1')==='1';$showWhatsapp=setting('footer_show_whatsapp','1')==='1';
$footerSections=(int)$showAbout+(int)$showCategories+(int)$showCollab+(int)$showContact;if($footerSections<1)$footerSections=1;
?>
<link rel="stylesheet" href="<?=e(url('assets/css/live-visitors.css'))?>">
<footer class="site-footer" style="--hf-footer-visible:<?=$footerSections?>">
  <div class="wrap footer-grid">
    <?php if($showAbout): ?><section class="footer-brand"><a class="footer-brandmark" href="<?=e(url('index.php'))?>"><?php if(setting('logo')):?><img src="<?=e(app_file_url(setting('logo')))?>" alt="<?=e($siteName)?>"><?php else:?><span class="footer-logo">M</span><?php endif;?></a><h2><?=e(setting('footer_about_title','Tentang Kami'))?></h2><p><?=e($about)?></p><?php if($showSocial):?><div class="footer-social" aria-label="Media sosial">
<?php
$socials=[
  'x'=>array('X','x'),
  'tiktok'=>array('TikTok','tiktok'),
  'youtube'=>array('YouTube','youtube'),
  'instagram'=>array('Instagram','instagram'),
  'facebook'=>array('Facebook','facebook')
];
foreach($socials as $key=>$meta):
  $href=trim((string)setting($key,''));
  if($href==='') continue;
?>
<a class="social-bubble social-<?=e($key)?>" href="<?=e($href)?>" target="_blank" rel="noopener noreferrer" aria-label="<?=e($meta[0])?>" title="<?=e($meta[0])?>">
  <?php if($key==='x'): ?><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.9 2H22l-6.77 7.74L23.2 22h-6.24l-4.89-6.39L6.48 22H3.36l7.24-8.28L2.8 2h6.4l4.42 5.83L18.9 2Zm-1.1 17.65h1.73L8.28 4.24H6.43L17.8 19.65Z"/></svg>
  <?php elseif($key==='tiktok'): ?><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M16.6 3c.4 2.2 1.7 3.8 4.1 4.1v3.2c-1.6-.1-3-.6-4.1-1.4v6.7c0 4.2-3.1 6.8-6.9 6.8-3.6 0-6.2-2.5-6.2-5.8 0-3.5 2.9-6.2 6.6-6.2.4 0 .8 0 1.2.1v3.3c-.4-.1-.8-.2-1.2-.2-1.7 0-3 .9-3 2.7 0 1.5 1.1 2.8 2.8 2.8 1.9 0 3.4-1.2 3.4-3.7V3h3.3Z"/></svg>
  <?php elseif($key==='youtube'): ?><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 0 0 .5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1c.5-1.9.5-5.8.5-5.8s0-3.9-.5-5.8ZM9.6 15.9V8.1l6.5 3.9-6.5 3.9Z"/></svg>
  <?php elseif($key==='instagram'): ?><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm0 3a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H7Zm5 3.2A3.8 3.8 0 1 1 8.2 12 3.8 3.8 0 0 1 12 8.2Zm0 2A1.8 1.8 0 1 0 13.8 12 1.8 1.8 0 0 0 12 10.2ZM17.4 6.6a1.1 1.1 0 1 1-1.1 1.1 1.1 1.1 0 0 1 1.1-1.1Z"/></svg>
  <?php else: ?><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.9.3-1.5 1.6-1.5h1.7V3.9c-.3 0-1.2-.1-2.3-.1-2.3 0-3.9 1.4-3.9 4v2.2H8v3h2.6v8h2.9Z"/></svg><?php endif; ?>
</a>
<?php endforeach; ?></div><?php endif;?></section><?php endif; ?>
    <?php if($showCategories): ?><section class="footer-column"><h2><?=e(setting('footer_categories_title','Kategori'))?></h2><ul><?php foreach($categoryLinks as $link):?><li><a href="<?=e($link['url'])?>" target="<?=e($link['target'])?>"<?=($link['target']==='_blank'?' rel="noopener noreferrer"':'')?>><?=e($link['label'])?></a></li><?php endforeach;?><?php if(!$categoryLinks):?><li><span>Belum ada rubrik</span></li><?php endif;?></ul></section><?php endif; ?>
    <?php if($showCollab): ?><section class="footer-column"><h2><?=e(setting('footer_collab_title','Kolaborasi, Yuk!'))?></h2><ul><?php foreach($collabLinks as $link):?><li><a href="<?=e($link['url'])?>" target="<?=e($link['target'])?>"<?=($link['target']==='_blank'?' rel="noopener noreferrer"':'')?>><?=e($link['label'])?></a></li><?php endforeach;?></ul></section><?php endif; ?>
    <?php if($showContact): ?><section class="footer-column footer-contact"><h2><a href="<?=e(url('contact.php'))?>"><?=e(setting('footer_contact_title','Kontak Kami'))?></a></h2><?php if($whatsapp):?><p><a href="https://wa.me/<?=e($waDigits)?>" target="_blank" rel="noopener noreferrer"><?=e($whatsapp)?></a></p><?php endif;?><?php if($email):?><p><a href="mailto:<?=e($email)?>"><?=e($email)?></a></p><?php endif;?><?php if($address):?><p><?=nl2br(e($address))?></p><?php endif;?><?php if(!$whatsapp&&!$email&&!$address):?><p>Informasi kontak redaksi dapat diatur melalui panel Admin → Pengaturan.</p><?php endif;?><p><a href="<?=e(url('contact.php'))?>">Lihat halaman Kontak & Tim Redaksi →</a></p>
      <div class="footer-live-visitors" aria-live="polite" aria-label="Jumlah pengunjung website saat ini">
        <div class="footer-live-title"><span class="footer-live-dot" aria-hidden="true"></span><span>Pengunjung Website</span></div>
        <div class="footer-live-count"><strong id="footerLiveVisitorCount">0</strong> <span>online</span></div>
        <div class="footer-live-total"><span id="footerTotalVisitorCount">0</span> total pengunjung tercatat</div>
        <div class="footer-live-note">Real-time · aktif dalam 2 menit terakhir</div>
      </div>
    </section><?php endif; ?>
  </div>
  <div class="wrap footer-bottom"><div><?=e($replaceTokens(setting('footer_bottom_left','© {year} {school_name}')))?></div><div><?=e($replaceTokens(setting('footer_bottom_right','{site_name} · Media literasi, kreativitas, dan informasi sekolah')))?></div></div>
</footer>
<?php if($waDigits&&$showWhatsapp):?><a class="floating-wa" href="https://wa.me/<?=e($waDigits)?>" target="_blank" rel="noopener noreferrer" aria-label="Hubungi WhatsApp">WA</a><?php endif; ?>
<script>
(function(){
  var el=document.getElementById('footerLiveVisitorCount');
  var totalEl=document.getElementById('footerTotalVisitorCount');
  if(!el || !window.fetch) return;
  var endpoint=<?=json_encode(url('realtime-visitors.php'))?>;
  function update(){
    fetch(endpoint,{credentials:'same-origin',cache:'no-store'})
      .then(function(r){return r.ok?r.json():null;})
      .then(function(data){
        if(data && typeof data.online !== 'undefined') el.textContent=String(data.online);
        if(data && typeof data.total_visitors !== 'undefined' && totalEl) totalEl.textContent=String(data.total_visitors);
      })
      .catch(function(){});
  }
  update();
  window.setInterval(update,15000);
})();
if("serviceWorker" in navigator){navigator.serviceWorker.register("<?=url('sw.js')?>").catch(()=>{});}
</script>
</body></html>