<?php
$site=setting('site_name','Majalah Sekolah Online');
$seoTitle=$seoTitle??$site;
$seoDesc=$seoDesc??setting('tagline','Portal sekolah');
$canonical=$canonical??url(ltrim(parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/', '/'));
$__hex=function($v,$d){return preg_match('/^#[0-9a-fA-F]{6}$/',(string)$v)?(string)$v:$d;};
$headerBg=$__hex(setting('header_bg','#ffffff'),'#ffffff');
$headerText=$__hex(setting('header_text','#172033'),'#172033');
$headerNavBg=$__hex(setting('header_nav_bg','#ffffff'),'#ffffff');
$headerNavText=$__hex(setting('header_nav_text','#172033'),'#172033');
$headerNavHover=$__hex(setting('header_nav_hover','#1e40af'),'#1e40af');
$headerBorder=$__hex(setting('header_border','#f0f2f5'),'#f0f2f5');
$headerHeight=max(60,min(120,(int)setting('header_height','78')));
$headerLogoWidth=max(32,min(100,(int)setting('header_logo_width','48')));
$headerNavPadding=max(6,min(22,(int)setting('header_nav_padding','14')));
$headerSticky=setting('header_sticky','1')==='1';
$headerSearch=setting('header_show_search','1')==='1';
$headerTagline=setting('header_show_tagline','1')==='1';
$__bodyClasses=array(theme_class());
if(!$headerSticky)$__bodyClasses[]='header-static';
if(!$headerSearch)$__bodyClasses[]='header-search-off';
if(!$headerTagline)$__bodyClasses[]='header-tagline-off';
$footerBg=$__hex(setting('footer_bg','#ffffff'),'#ffffff');
$footerText=$__hex(setting('footer_text_color','#374151'),'#374151');
$footerHeading=$__hex(setting('footer_heading_color','#080808'),'#080808');
$footerBorder=$__hex(setting('footer_border_color','#173b8f'),'#173b8f');
$footerBorderWidth=max(0,min(10,(int)setting('footer_border_width','2')));
$footerTopPadding=max(0,min(120,(int)setting('footer_top_padding','28')));
$footerGap=max(10,min(80,(int)setting('footer_column_gap','30')));
$footerCols=max(2,min(4,(int)setting('footer_columns','4')));
$mobileDockEnabled=setting('home_mobile_dock_enabled','1')==='1';
$mobileDockBg=$__hex(setting('home_mobile_dock_bg','#ffffff'),'#ffffff');
$mobileDockActive=$__hex(setting('home_mobile_dock_active','#2455b8'),'#2455b8');
$mobileDockBlur=max(0,min(30,(int)setting('home_mobile_dock_blur','22')));
$mobileDockOpacity=max(70,min(100,(int)setting('home_mobile_dock_opacity','92')))/100;
$mobileDockRadius=max(18,min(40,(int)setting('home_mobile_dock_radius','27')));
$mobileDockBottom=max(4,min(40,(int)setting('home_mobile_dock_bottom','12')));
$mobileDockItems=max(2,min(4,(int)setting('home_mobile_dock_items','4')));
$mobileDockPosition=in_array(setting('home_mobile_dock_position','center'),['left','center','right'],true)?setting('home_mobile_dock_position','center'):'center';
$__style=':root{--hf-header-bg:'.$headerBg.';--hf-header-text:'.$headerText.';--hf-nav-bg:'.$headerNavBg.';--hf-nav-text:'.$headerNavText.';--hf-nav-hover:'.$headerNavHover.';--hf-header-border:'.$headerBorder.';--hf-header-height:'.$headerHeight.'px;--hf-logo-width:'.$headerLogoWidth.'px;--hf-nav-pad:'.$headerNavPadding.'px;--hf-footer-bg:'.$footerBg.';--hf-footer-text:'.$footerText.';--hf-footer-heading:'.$footerHeading.';--hf-footer-border:'.$footerBorder.';--hf-footer-border-width:'.$footerBorderWidth.'px;--hf-footer-pad:'.$footerTopPadding.'px;--hf-footer-gap:'.$footerGap.'px;--hf-footer-cols:'.$footerCols.';--macos-dock-bg:'.$mobileDockBg.';--macos-dock-active:'.$mobileDockActive.';--macos-dock-blur:'.$mobileDockBlur.'px;--macos-dock-opacity:'.$mobileDockOpacity.';--macos-dock-radius:'.$mobileDockRadius.'px;--macos-dock-bottom:'.$mobileDockBottom.'px;--macos-dock-position:'.$mobileDockPosition.';}';
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($seoTitle)?></title><meta name="description" content="<?=e($seoDesc)?>"><meta name="keywords" content="<?=e(setting('seo_keywords','majalah sekolah, berita sekolah, karya siswa'))?>"><link rel="canonical" href="<?=e($canonical)?>"><meta property="og:title" content="<?=e($seoTitle)?>"><meta property="og:description" content="<?=e($seoDesc)?>"><?php if(setting('logo')):?><meta property="og:image" content="<?=e(app_file_url(setting('logo')))?>"><?php endif;?><link rel="stylesheet" href="<?=e(url('assets/css/style.css'))?>"><link rel="stylesheet" href="<?=e(url('assets/css/header-footer-customizer.css'))?>"><link rel="stylesheet" href="<?=e(url('assets/css/responsive-v7.css'))?>"><link rel="stylesheet" href="<?=e(url('assets/css/dock-liquid-glass-v1.css'))?>"><link rel="stylesheet" href="<?=e(url('assets/css/scroll-reveal-v1.css'))?>"><link rel="stylesheet" href="<?=e(url('assets/css/stats-login-polish-v1.css'))?>"><style><?=e($__style)?></style><script defer src="<?=e(url('assets/js/app.js'))?>"></script><script defer src="<?=e(url('assets/js/mobile-nav-v1.js'))?>"></script><script defer src="<?=e(url('assets/js/dock-liquid-glass-v1.js'))?>"></script><script defer src="<?=e(url('assets/js/scroll-reveal-v1.js'))?>"></script><link rel="manifest" href="<?=url('manifest.webmanifest')?>"><meta name="theme-color" content="<?=e(setting('primary_color','#1e40af'))?>"><?php if(setting('favicon')):?><link rel="icon" href="<?=e(app_file_url(setting('favicon')))?>"><?php endif;?><?php if(isset($schema)): ?><script type="application/ld+json"><?=json_encode($schema,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)?></script><?php endif;?></head><body class="<?=e(implode(' ',$__bodyClasses))?>"><header class="top"><div class="wrap brand"><a href="index.php"><?php if(setting('logo')):?><img class="brand-logo" src="<?=e(app_file_url(setting('logo')))?>" alt="Logo"><?php else:?><span class="logo">M</span><?php endif;?><span><b><?=e($site)?></b><small><?=e(setting('tagline'))?></small></span></a><form action="articles.php" method="get"><input name="q" placeholder="Cari berita, karya, prestasi..."><button>🔎</button></form></div><?php $menus=$pdo->query('SELECT * FROM menus WHERE is_active=1 ORDER BY sort_order,id')->fetchAll(); ?>
<nav><div class="wrap navinner"><button type="button" class="mobile-nav-toggle" aria-expanded="false" aria-controls="mobile-public-menu"><span class="mobile-nav-icon" aria-hidden="true"><i></i><i></i><i></i></span><span class="mobile-nav-label">Menu</span></button><div class="links" id="mobile-public-menu"><?php foreach($menus as $m):?><a href="<?=e($m['url'])?>" target="<?=e($m['target'])?>"><?=e($m['label'])?></a><?php endforeach;?></div><?php if(auth()): ?>
<div class="auth-nav-actions">
  <a class="login" href="member.php">Dashboard</a>
  <?php if(in_array(auth()['role'], array('member','contributor'), true)): ?>
  <form method="post" action="logout.php" class="logout-nav-form">
    <input type="hidden" name="_csrf" value="<?=e(csrf())?>">
    <button type="submit" class="logout-nav-btn">Keluar</button>
  </form>
  <?php endif; ?>
</div>
<?php else: ?>
<a class="login" href="login.php">Login</a>
<?php endif; ?></div></nav>
<?php if($mobileDockEnabled):
  $dockItems=array_slice($menus,0,$mobileDockItems);
  $leftCount=(int)ceil(count($dockItems)/2);
  $dockLeft=array_slice($dockItems,0,$leftCount);
  $dockRight=array_slice($dockItems,$leftCount);
  /* Inline line icons (24x24, stroke=currentColor). Static markup, safe to echo. */
  $lgIcon=function($label,$url,$idx){
    $l=strtolower(trim((string)$label));
    $t=$l.' '.strtolower((string)$url);
    $p='';
    if(strpos($l,'beranda')!==false||strpos($l,'home')!==false||strpos($l,'utama')!==false){
      $p='<path d="M3.5 10.8 12 3.5l8.5 7.3V19a1.5 1.5 0 0 1-1.5 1.5h-3.6v-5.6H8.6v5.6H5A1.5 1.5 0 0 1 3.5 19z"/>';
    }elseif(strpos($t,'kirim')!==false||strpos($t,'submit')!==false){
      $p='<path d="M20.5 3.5 10.6 13.4M20.5 3.5l-6.3 17-3.6-7.1-7.1-3.6z"/>';
    }elseif(strpos($t,'warta')!==false||strpos($t,'berita')!==false||strpos($t,'news')!==false){
      $p='<path d="M5 4.5h11.5A1.5 1.5 0 0 1 18 6v13.5H6.5A1.5 1.5 0 0 1 5 18z"/><path d="M18 9h1.5a1.5 1.5 0 0 1 1.5 1.5V18a1.5 1.5 0 0 1-3 0"/><path d="M8.5 8.5h6M8.5 12h6M8.5 15.5H12"/>';
    }elseif(strpos($t,'kegiatan')!==false||strpos($t,'agenda')!==false){
      $p='<rect x="3.5" y="5" width="17" height="15.5" rx="3.5"/><path d="M3.5 10h17M8 3v3.5M16 3v3.5"/>';
    }elseif(strpos($t,'prestasi')!==false){
      $p='<path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 16.9l-5.2 2.8 1-5.9L3.5 9.7l5.9-.8z"/>';
    }elseif(strpos($t,'cerita')!==false||strpos($t,'kreas')!==false||strpos($t,'karya')!==false){
      $p='<path d="M4 20l1-4.2L16.6 4.2a2 2 0 0 1 2.8 0l.4.4a2 2 0 0 1 0 2.8L8.2 19z"/><path d="m14.5 6.5 3 3"/>';
    }elseif(strpos($t,'galeri')!==false||strpos($t,'gallery')!==false){
      $p='<rect x="3.5" y="4.5" width="17" height="15" rx="3.5"/><circle cx="9" cy="10" r="1.7"/><path d="m4 17 5-4.5 3.5 3 2.5-2 5 3.5"/>';
    }elseif(strpos($t,'edisi')!==false||strpos($t,'epaper')!==false){
      $p='<path d="M12 6.5C10 5 7 4.6 4 5v13c3-.4 6 0 8 1.5 2-1.5 5-1.9 8-1.5V5c-3-.4-6 0-8 1.5zM12 6.5v13"/>';
    }elseif(strpos($t,'dunia')!==false||strpos($t,'remaja')!==false){
      $p='<circle cx="12" cy="12" r="8.5"/><path d="M8.5 14c1 1.5 2.2 2.2 3.5 2.2s2.5-.7 3.5-2.2M9 9.6h.01M15 9.6h.01"/>';
    }elseif(strpos($t,'info')!==false){
      $p='<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8h.01"/>';
    }else{
      $p=($idx%2===0)?'<rect x="4" y="4" width="16" height="16" rx="5"/><path d="M9 12h6"/>':'<circle cx="12" cy="12" r="8.5"/><path d="M8.5 12h7M12.5 9l3 3-3 3"/>';
    }
    return '<svg class="lg-ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'.$p.'</svg>';
  };
  /* Active item: same file + every query param of the menu URL must match current request. */
  $lgBase=function($path){
    $b=basename((string)$path);
    return ($b===''||strpos($b,'.')===false)?'index.php':$b;
  };
  $lgCur=$lgBase(parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/');
  $lgCurQ=array();
  parse_str((string)($_SERVER['QUERY_STRING']??''),$lgCurQ);
  $lgActive=-1;$lgBest=0;
  foreach($menus as $lgi=>$lgm){
    $lgu=trim((string)$lgm['url']);
    if($lgu===''||$lgu[0]==='#'||preg_match('#^([a-z][a-z0-9+.\-]*:|//)#i',$lgu))continue;
    $lgp=parse_url($lgu);
    if($lgp===false||$lgBase($lgp['path']??'')!==$lgCur)continue;
    $lgq=array();
    parse_str((string)($lgp['query']??''),$lgq);
    $lgok=true;
    foreach($lgq as $lgk=>$lgv){
      if(!isset($lgCurQ[$lgk])||(string)$lgCurQ[$lgk]!==(string)$lgv){$lgok=false;break;}
    }
    if($lgok&&count($lgq)+1>$lgBest){$lgBest=count($lgq)+1;$lgActive=$lgi;}
  }
  $lgRel=function($m){return ((string)$m['target']==='_blank')?' rel="noopener noreferrer"':'';};
?>
<div class="lg-dock pos-<?=e($mobileDockPosition)?>" id="lg-dock" role="navigation" aria-label="Navigasi utama">
  <div class="lg-bar">
    <span class="lg-glass" aria-hidden="true"><span class="lg-glow"></span></span>
    <div class="lg-side lg-side-l">
      <?php foreach($dockLeft as $i=>$m): $on=($i===$lgActive); ?><a class="lg-item<?=$on?' is-active':''?>" href="<?=e($m['url'])?>" target="<?=e($m['target'])?>"<?=$lgRel($m)?><?=$on?' aria-current="page"':''?>><?=$lgIcon($m['label'],$m['url'],$i)?><span class="lg-txt"><?=e($m['label'])?></span></a><?php endforeach; ?>
    </div>
    <button type="button" class="lg-menu" aria-expanded="false" aria-controls="lg-panel" aria-label="Buka menu"><span class="lg-orb" aria-hidden="true"><span class="lg-burger"><i></i><i></i><i></i></span></span><span class="lg-txt">Menu</span></button>
    <div class="lg-side lg-side-r">
      <?php foreach($dockRight as $j=>$m): $ix=$j+$leftCount; $on=($ix===$lgActive); ?><a class="lg-item<?=$on?' is-active':''?>" href="<?=e($m['url'])?>" target="<?=e($m['target'])?>"<?=$lgRel($m)?><?=$on?' aria-current="page"':''?>><?=$lgIcon($m['label'],$m['url'],$ix)?><span class="lg-txt"><?=e($m['label'])?></span></a><?php endforeach; ?>
    </div>
  </div>
</div>
<div class="lg-panel pos-<?=e($mobileDockPosition)?>" id="lg-panel" aria-hidden="true" aria-label="Semua menu">
  <?php foreach($menus as $i=>$m): $on=($i===$lgActive); ?><a class="<?=$on?'is-active':''?>" style="--i:<?=(int)$i?>" href="<?=e($m['url'])?>" target="<?=e($m['target'])?>"<?=$lgRel($m)?><?=$on?' aria-current="page"':''?>><span class="lg-chip"><?=$lgIcon($m['label'],$m['url'],$i)?></span><span class="lg-txt"><?=e($m['label'])?></span></a><?php endforeach; ?>
</div>
<div class="lg-scrim" id="lg-scrim" aria-hidden="true"></div>
<script>(function(){var b=document.body;['lg-dock','lg-panel','lg-scrim'].forEach(function(i){var n=document.getElementById(i);if(n&&n.parentNode!==b)b.appendChild(n);});})();</script>
<?php endif; ?>
</header><main class="wrap">